# Trail Atlas

Offline field-mapping web app (PWA): GeoPDF / GeoTIFF / KMZ / MBTiles maps, GPS track recording, waypoints with photos and custom fields, navigation, route planning, and GPX / KML / GeoJSON / CSV / Shapefile / GeoPackage import and export. All data stays on the device.

Open `index.html` over HTTPS (e.g. GitHub Pages) and use "Add to Home Screen" on the phone.

`tools/shrink_geopdf.py` shrinks GeoPDFs whose embedded images are too large for a phone (needs PyMuPDF).
