# Trail Atlas: panduan hos tetap (untuk Encik Shaiful)

Tujuan: aplikasi duduk di alamat **kekal** (tidak bertukar bila terowong dimulakan semula), percuma, dan sandaran awan terus ke pelayan sendiri.

Ada dua bahagian dan keduanya perlu stabil:

| Bahagian | Fungsi | Penyelesaian percuma |
|---|---|---|
| **A. Aplikasi** (fail statik, 3 MB) | Halaman yang dibuka di telefon | Cloudflare Pages atau GitHub Pages: alamat kekal |
| **B. API** (sandaran awan, titik panas api) | `trailatlas_serve.py` di VM | Tailscale Funnel: alamat `…ts.net` kekal |

Jika hanya A dibuat, aplikasi stabil tetapi alamat sandaran masih bertukar bila terowong Cloudflare bertukar. Jika hanya B dibuat, alamat sandaran stabil tetapi aplikasi masih di alamat lama. Buat kedua-duanya.

## Langkah A: hos aplikasi (Cloudflare Pages, kira-kira 5 minit)
1. Muat turun `trail-atlas-dist.zip` (dalam pek semakan) dan nyahzip.
2. Log masuk https://dash.cloudflare.com → Workers & Pages → Create → Pages → **Upload assets**.
3. Beri nama projek (contoh `trail-atlas`), seret folder yang dinyahzip, tekan Deploy.
4. Anda dapat alamat `https://trail-atlas.pages.dev`. Itu alamat kekal aplikasi.
5. Setiap kali kod berubah, jalankan `python3 tools/build_dist.py --zip trail-atlas-dist.zip` (Mat boleh lakukan) dan muat naik semula. Versi cache dikemas kini sendiri.

Pilihan GitHub Pages: letak kandungan `dist/` dalam repositori, hidupkan Pages. Fail `.nojekyll` sudah disertakan.

## Langkah B: alamat kekal untuk API (Tailscale Funnel)
VM `mat-awan` sudah dalam rangkaian Tailscale Encik. Funnel belum dihidupkan (`No serve config`). Yang perlu Encik buat sekali di https://login.tailscale.com/admin :
1. **DNS** → hidupkan *HTTPS Certificates*.
2. **Access controls** → tambah atribut `funnel` untuk peranti/pengguna Encik mengikut dokumentasi Tailscale tentang Funnel (saya belum sahkan rupa antara muka konsol semasa).
3. Beritahu Mat. Mat jalankan di VM: `tailscale funnel --bg 8740`, dan alamat `https://mat-awan.<nama-tailnet>.ts.net` jadi alamat API kekal.

## Langkah C: sambungkan A dan B
1. Pelayan versi 2 **sudah hidup** (dipasang 24 Nov melalui drop-in `/etc/systemd/system/trailatlas-web.service.d/override.conf`). Tambah satu baris `Environment=TA_ORIGINS=https://trail-atlas.pages.dev` dalam fail itu (asal yang dibenarkan memanggil API), kemudian `systemctl daemon-reload && systemctl restart trailatlas-web`. Tanpa baris ini tiada CORS, sama seperti sebelum ini.
2. Pautan persediaan telefon (yang Mat hantar melalui Telegram) mendapat satu bahagian tambahan: `https://trail-atlas.pages.dev/#k=<kunci>&s=https://mat-awan.<tailnet>.ts.net`. Membuka pautan itu sekali menyimpan kunci dan alamat API pada telefon.
3. Data aplikasi di telefon terikat pada alamat aplikasi. Pengguna yang sudah pasang daripada alamat terowong lama perlu membuka alamat baharu sekali dan guna **Restore** daripada sandaran awan (tawaran restore sudah ada dalam aplikasi).

## Pulihkan / batalkan
- Tiada apa-apa dihidupkan lagi. Aplikasi yang hidup sekarang tidak diubah.
- Untuk membatalkan: padam projek Pages. Pautan terowong lama kekal berfungsi selagi VM berjalan.
- Sandaran penuh sebelum kerja ini: `/workspace/mat/trailatlas-upgrade-backup-20261124/` (salinan folder + `repo.bundle`).

## Kekangan jujur
- Syarat khidmat percuma boleh berubah. Cloudflare Pages dan GitHub Pages percuma untuk fail statik; Tailscale Funnel: sila semak syarat dan had pelan Encik di Tailscale sebelum bergantung padanya.
- Sandaran awan menghantar foto dan peta ke VM melalui internet. Ia dilindungi kunci, tetapi saiz sandaran peta boleh besar (had pelayan 150 MB sekali muat naik).

## Peta jalan vektor dari pelayan sendiri: kemas kini jubin
Fail jubin: `/workspace/mat/trailatlas-tiles/malaysia-z15.pmtiles` (460 MB, Malaysia, zum 0-15, data OpenStreetMap melalui binaan Protomaps 23 Nov 2026). Ia gambaran pada satu tarikh dan tidak dikemas kini sendiri. Untuk menyegarkan (kira-kira 10 minit, percuma):
1. Cari binaan terkini: `https://build.protomaps.com/YYYYMMDD.pmtiles` (tarikh semalam atau hari ini).
2. `/workspace/mat/pmtiles-work/bin/pmtiles extract <URL binaan> /workspace/mat/trailatlas-tiles/baru.pmtiles --bbox=99.6,0.8,119.3,7.4 --maxzoom=15`
3. Semak dengan `pmtiles show baru.pmtiles`, kemudian gantikan fail lama dan `systemctl restart trailatlas-web`.
Atribusi wajib dipaparkan dalam peta ("OpenStreetMap contributors, Protomaps"); data OSM berlesen ODbL. Pustaka lukisan `protomaps-leaflet` berlesen BSD-3-Clause (`lib/protomaps-leaflet.js`).

## Ujian dan kebolehpercayaan (25 Nov 2026)
- `tools/uji_semua.sh` menjalankan semua ujian (parser, storan, log ralat, bertindih, asap, fungsi, vektor, CSP, label, kemas kini SW; ~2 minit). `tools/uji_semua.sh cepat` = subset ~40 saat; ia juga dijalankan sebelum setiap `git commit` (hook pre-commit).
- `core.js` memegang storan IndexedDB (tulis gagal tidak lagi senyap: amaran + butang Save backup; penulisan dikunci bila data tidak dapat dibaca atau datang dari versi lebih baharu), log ralat 30 terakhir (More → Copy error report), versi skema data (`SCHEMA_VERSION`, `MIGRATIONS`; migrasi menyimpan salinan `bak:v<N>:tracks|wpts` dahulu).
- `sw.js` tidak lagi `skipWaiting` sendiri: versi baharu menunggu sehingga pengguna setuju muat semula, jadi halaman tidak bercampur fail versi lama dan baharu.
- `index.html` ada Content-Security-Policy melalui meta (`script-src 'self'` + hash skrip tema + `wasm-unsafe-eval`). Jika menambah skrip sebaris atau pustaka yang guna eval, kemas kini polisi dan jalankan `tests/csp.js`.
- Belum dibuat: tiada CI di GitHub (kod sumber tidak berada di repositori awam); tulisan masih menulis semula keseluruhan senarai trek/titik pada setiap simpanan.
