// =====================================================================
// Trail Atlas — field pack: work status, beacons, accuracy (RMS),
// project handover (share/merge), auto snapshot, install
// Loaded after app.js/extras.js. Uses their globals.
// =====================================================================
const STATUS = {
  pending: { n: 'Pending', c: '#C9820A', t: 'Not started' },
  progress: { n: 'In progress', c: '#1D6FB8', t: 'Being worked on' },
  resolved: { n: 'Resolved', c: '#2F6B40', t: 'Finished' }
};
const ST_KEYS = Object.keys(STATUS);
let stFilter = 'all';          // waypoint list filter
let bpDeferred = null;         // install prompt

const stChip = st => st && STATUS[st]
  ? el('span', { class: 'stchip', style: `--sc:${STATUS[st].c}` }, STATUS[st].n) : null;
function setStatus(f, st) {
  f.st = st || undefined; f.tu = Date.now();
  if (f.lat != null) { save.wpts(); drawWpts(); } else { save.tracks(); drawTracks(); }
  render(); return f.st;
}
function statusUI(f, after) { // small chooser, used from popups and menus
  const row = el('div', { class: 'segs' });
  ['', ...ST_KEYS].forEach(k => row.append(el('button', {
    class: (f.st || '') === k ? 'on' : '',
    onclick: () => { setStatus(f, k); closeModal(); after && after(); }
  }, k ? STATUS[k].n : 'None')));
  modal('Work status', el('p', { class: 'mut' }, 'Mark where this point is in the job. Filter by status in the Points list.'),
    row, el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: closeModal }, 'Cancel')));
}

// ---------- numbered beacons along a route (FO Maps call-point routes) ----------
function beaconCode(name) {
  const w = String(name).toUpperCase().replace(/[^A-Z0-9 ]/g, ' ').split(/\s+/).filter(Boolean);
  return ((w[0] || 'R').slice(0, 2) + (w[1] || '').slice(0, 2)) || 'R';
}
function countBeacons(t, step) {
  const d = pathLen(t.pts); return step > 0 ? Math.floor(d / step) + 1 : 0;
}
function makeBeacons(t, step, code, doReplace = true) {
  const P = t.pts, total = pathLen(P);
  if (doReplace) S.wpts = S.wpts.filter(w => !(w.bk && w.bk.track === t.id));
  let made = 0, acc = 0, next = 0, i = 0;
  const place = (d) => {
    made++;
    S.wpts.push({
      id: uid(), name: `${code}-${made}`, note: `Beacon ${made} · ${fmtD(d)} from the start`, lat: nextLat, lon: nextLon,
      color: t.color, icon: '📍', folder: 'Beacons — ' + t.name, attrs: { Chainage: fmtD(d), Route: code },
      photos: [], t: Date.now(), bk: { track: t.id, at: d, code }
    });
  };
  let nextLat = P[0][0], nextLon = P[0][1];
  place(0);
  for (i = 0; i < P.length - 1; i++) {
    const seg = hav(P[i], P[i + 1]); if (!seg) continue;
    let done = 0;
    while (acc + (seg - done) >= (made) * step - 1e-9 && made * step <= total) {
      const need = made * step - (acc + done); if (need > seg - done) break;
      const u = (done + need) / seg;
      nextLat = P[i][0] + u * (P[i + 1][0] - P[i][0]); nextLon = P[i][1] + u * (P[i + 1][1] - P[i][1]);
      if (made * step > total) break;
      place(made * step); done += need;
    }
    acc += seg;
  }
  save.wpts(); drawWpts(); render();
  return made;
}
function beaconUI(t) {
  const d = pathLen(t.pts);
  const step = el('input', { type: 'number', min: 10, max: 5000, step: 10, value: 250 });
  const code = el('input', { type: 'text', value: beaconCode(t.name), maxlength: 8 });
  const info = el('p', { class: 'mut' });
  const upd = () => {
    const s = +step.value || 0, n = s > 0 ? countBeacons(t, s) : 0;
    info.textContent = `Route is ${fmtD(d)} long → ${n} beacons every ${fmtD(s)}` + (n > 500 ? ' (too many, increase the spacing)' : '');
  };
  step.oninput = upd; upd();
  const existing = S.wpts.filter(w => w.bk && w.bk.track === t.id).length;
  modal('Beacons on “' + t.name + '”',
    el('p', { class: 'mut' }, 'Splits the route into numbered points so the crew can report positions by radio: “truck at ' + (code.value || 'R') + '-6”. Beacons are normal waypoints — exportable, shareable, and usable offline.'),
    el('label', {}, 'Distance between beacons (metres)'), step, el('label', {}, 'Route code'), code, info,
    existing ? el('p', { class: 'mut' }, `This route already has ${existing} beacons — they will be replaced.`) : '',
    el('div', { class: 'row act' },
      el('button', {
        class: 'btn pri', onclick: () => {
          const s = +step.value, n = countBeacons(t, s);
          if (!(s > 0)) return toast('Enter the spacing');
          if (n > 500) return toast('Choose a larger spacing (max 500 points)');
          const made = makeBeacons(t, s, (code.value.trim() || 'R').toUpperCase());
          closeModal(); toast(`${made} beacons added to “${t.name}”`, 3500); setTab('wpts');
        }
      }, 'Create beacons'),
      el('button', {
        class: 'btn dng', onclick: () => {
          if (!existing) return toast('No beacons on this route');
          S.wpts = S.wpts.filter(w => !(w.bk && w.bk.track === t.id)); save.wpts(); drawWpts(); closeModal(); render(); toast('Beacons removed');
        }
      }, existing ? 'Remove beacons' : ''),
      el('button', { class: 'btn', onclick: closeModal }, 'Cancel')));
}

// ---------- accuracy points: least-squares align + RMS (NomadTracks style) ----------
function solve3(A, b) { // 3x3 normal equations, Gaussian elimination
  const M = A.map((r, i) => [...r, b[i]]);
  for (let i = 0; i < 3; i++) {
    let p = i; for (let k = i + 1; k < 3; k++) if (Math.abs(M[k][i]) > Math.abs(M[p][i])) p = k;
    if (Math.abs(M[p][i]) < 1e-12) return null;
    [M[i], M[p]] = [M[p], M[i]];
    for (let k = i + 1; k < 3; k++) { const f = M[k][i] / M[i][i]; for (let j = i; j < 4; j++) M[k][j] -= f * M[i][j]; }
  }
  const x = [0, 0, 0];
  for (let i = 2; i >= 0; i--) { let s = M[i][3]; for (let j = i + 1; j < 3; j++) s -= M[i][j] * x[j]; x[i] = s / M[i][i]; }
  return x;
}
function fitFromCP(cp) {
  if (!cp || cp.length < 3) return null;
  const N = [[0, 0, 0], [0, 0, 0], [0, 0, 0]], bl = [0, 0, 0], bo = [0, 0, 0];
  for (const p of cp) {
    const r = [p.u, p.v, 1];
    for (let i = 0; i < 3; i++) {
      for (let j = 0; j < 3; j++) N[i][j] += r[i] * r[j];
      bl[i] += r[i] * p.lat; bo[i] += r[i] * p.lon;
    }
  }
  const a = solve3(N.map(r => [...r]), [...bl]), o = solve3(N.map(r => [...r]), [...bo]);
  if (!a || !o) return null;
  const at = (u, v) => [a[0] * u + a[1] * v + a[2], o[0] * u + o[1] * v + o[2]];
  let sum = 0, mx = 0;
  for (const p of cp) {
    const q = at(p.u, p.v), k = Math.cos(rad(p.lat));
    const dy = (q[0] - p.lat) * 111320, dx = (q[1] - p.lon) * 111320 * k;
    const d = Math.hypot(dx, dy); p.res = d; sum += d * d; mx = Math.max(mx, d);
  }
  return { corners: [at(0, 0), at(1, 0), at(0, 1)], rms: Math.sqrt(sum / cp.length), max: mx };
}
function applyCP(o) {
  const fit = fitFromCP(o.cp);
  if (!fit) return toast('Add at least 3 accuracy points');
  o.corners = fit.corners; o.rms = Math.round(fit.rms * 10) / 10; o.cp = o.cp; save.overlays();
  if (ovLayers[o.id]) ovLayers[o.id].setCorners(o.corners);
  if (editOv === o) startEditOv(o); else showMap(o);
  return fit;
}
function addCrosshairPoint(o, back) {
  const c = map.getCenter(), uv = toUV(o.corners, [c.lat, c.lng]);
  const lat = el('input', { type: 'number', step: 'any', value: c.lat.toFixed(6) }), lon = el('input', { type: 'number', step: 'any', value: c.lng.toFixed(6) });
  modal('Accuracy point',
    el('p', { class: 'mut' }, 'Pan the map so the crosshair sits on a feature you know (a road junction, a corner post, a bridge). Then type its true coordinates — or stand on it and press “Use my GPS”.'),
    el('div', { class: 'row', style: 'flex-wrap:nowrap' }, el('label', {}, 'Latitude'), lat), el('div', { class: 'row', style: 'flex-wrap:nowrap' }, el('label', {}, 'Longitude'), lon),
    el('div', { class: 'row' },
      el('button', {
        class: 'btn', onclick: () => {
          if (!last) return toast('No GPS fix yet');
          lat.value = last.lat.toFixed(6); lon.value = last.lon.toFixed(6); toast('Filled from GPS');
        }
      }, 'Use my GPS')),
    el('p', { class: 'mut', style: 'font-size:12.5px' }, 'Image position: u=' + uv[0].toFixed(3) + ', v=' + uv[1].toFixed(3)),
    el('div', { class: 'row act' },
      el('button', {
        class: 'btn pri', onclick: () => {
          const la = +lat.value, lo = +lon.value;
          if (!isFinite(la) || !isFinite(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) return toast('Enter a valid position');
          o.cp = (o.cp || []).concat([{ u: uv[0], v: uv[1], lat: la, lon: lo }]);
          save.overlays(); closeModal(); (back || (() => accUI(o)))();
        }
      }, 'Save point'),
      el('button', { class: 'btn', onclick: () => { closeModal(); (back || (() => accUI(o)))(); } }, 'Cancel')));
}
function accUI(o) {
  const cp = o.cp || [], fit = fitFromCP(cp);
  const tbl = el('div');
  cp.forEach((p, i) => tbl.append(el('div', { class: 'item', style: 'padding:8px 0' },
    el('b', {}, 'Point ' + (i + 1)), el('div', { class: 'mut' }, `${p.lat.toFixed(6)}, ${p.lon.toFixed(6)}`),
    el('div', { class: 'mut' }, p.res != null ? 'off by ' + fmtD(p.res) : '—'),
    el('button', { class: 'btn sm dng', onclick: () => { o.cp.splice(i, 1); save.overlays(); closeModal(); accUI(o); } }, 'Remove'))));
  modal('Accuracy of “' + o.name + '”',
    el('p', { class: 'mut' }, 'Three points give an exact fit with no error estimate. Add a fourth and the app reports the real error (RMS) in metres — that is what tells you whether the map can be trusted.'),
    fit ? el('div', { class: 'pill', style: 'margin:8px 0;border-left:4px solid ' + (fit.rms < 5 ? 'var(--frond)' : fit.rms < 15 ? 'var(--contour)' : 'var(--danger)') },
      el('div', {}, el('b', {}, '± ' + fit.rms.toFixed(1) + ' m RMS'), ' from ' + cp.length + ' points'),
      el('div', { class: 'mut' }, 'worst point off by ' + fmtD(fit.max))) : el('p', { class: 'mut' }, cp.length + ' point(s) so far — at least 3 needed, 4+ for an error estimate.'),
    tbl,
    el('div', { class: 'row', style: 'flex-wrap:wrap' },
      cp.length ? el('button', { class: 'btn sm dng', onclick: () => { o.cp = []; save.overlays(); closeModal(); accUI(o); } }, 'Clear points') : '',
      el('button', { class: 'btn sm', onclick: () => { closeModal(); if (editOv !== o) startEditOv(o); } }, 'Back to aligning')),
    el('div', { class: 'row act' },
      el('button', { class: 'btn pri', onclick: () => { closeModal(); addCrosshairPoint(o, () => accUI(o)); } }, '+ Point'),
      fit ? el('button', {
        class: 'btn go', onclick: () => {
          const f = applyCP(o); closeModal(); toast('Map aligned · ± ' + f.rms.toFixed(1) + ' m RMS', 4000);
        }
      }, 'Apply fit') : '',
      el('button', { class: 'btn', onclick: closeModal }, 'Close')));
}

// ---------- project handover: one file out, merge back ----------
function bundle(scopeFolder, withPhotos = false) {
  const pick = x => !scopeFolder || x.folder === scopeFolder;
  const j = {
    v: 3, app: 'trail-atlas', exported: new Date().toISOString(), scope: scopeFolder || 'all',
    tracks: S.tracks.filter(pick), wpts: S.wpts.filter(pick), schemas: S.schemas
  };
  if (withPhotos) j.photos = {};
  return j;
}
async function shareProjectUI() {
  const fs = folders();
  const sel = el('select');
  sel.append(el('option', { value: '' }, 'Everything'));
  fs.forEach(f => sel.append(el('option', { value: f }, 'Layer: ' + f)));
  const ph = el('input', { type: 'checkbox' });
  modal('Give the project to the crew',
    el('p', { class: 'mut' }, 'Creates one file with the layers, points, statuses, fields and beacons. Send it on WhatsApp; the other phone opens Trail Atlas → More → “Receive project file”. Points you both edited are merged, not overwritten.'),
    el('label', {}, 'What to include'), sel,
    el('label', { class: 'mut', style: 'display:block;margin-top:8px' }, ph, ' Include photos (big file)'),
    el('div', { class: 'row act' },
      el('button', {
        class: 'btn pri', onclick: async () => {
          toast('Preparing the project file…');
          const j = bundle(sel.value, ph.checked);
          if (ph.checked) {
            j.photos = {};
            for (const id of [...j.tracks, ...j.wpts].flatMap(x => x.photos || [])) {
              const b = await kvGet('ph:' + id); if (b) j.photos[id] = await blobToURL(b);
            }
          }
          closeModal();
          await shareFile('project-' + (sel.value ? fname(sel.value) : 'trail-atlas') + '-' + new Date().toISOString().slice(0, 10) + '.json', JSON.stringify(j), 'application/json');
        }
      }, 'Create & send'),
      el('button', { class: 'btn', onclick: closeModal }, 'Cancel')));
}
async function mergeProject(f) {
  let j;
  try { j = JSON.parse(await f.text()); } catch (e) { return toast('That is not a Trail Atlas project file'); }
  if (!j || !(j.v >= 2) || !(j.tracks || j.wpts)) return toast('That is not a Trail Atlas project file');
  let added = 0, updated = 0, same = 0;
  const mergeInto = (list, incoming, saveFn, drawFn) => {
    for (const inc of incoming || []) {
      const cur = list.find(x => x.id === inc.id);
      if (!cur) { list.push(inc); added++; continue; }
      const a = cur.tu || cur.t || 0, b = inc.tu || inc.t || 0;
      if (b > a) { Object.assign(cur, inc); updated++; } else same++;
    }
  };
  mergeInto(S.tracks, j.tracks); mergeInto(S.wpts, j.wpts);
  if (j.schemas) for (const [k, v] of Object.entries(j.schemas)) if (!S.schemas[k] || !S.schemas[k].length) S.schemas[k] = v;
  for (const [id, u] of Object.entries(j.photos || {})) { if (!(await kvGet('ph:' + id))) await kvSet('ph:' + id, await (await fetch(u)).blob()); }
  await save.tracks(); await save.wpts(); await save.schemas(); drawTracks(); drawWpts(); render();
  toast(`${added} new, ${updated} updated, ${same} already the same`, 5000);
  return { added, updated, same };
}

// ---------- automatic snapshot (protects against a wrong tap / bad import) ----------
async function autoSnap(force) {
  try {
    const lastAt = S.set.snapAt || 0;
    if (!force && Date.now() - lastAt < 864e5) return;
    const ks = (await kvGet('snapKeys')) || [];
    const key = 'snap:' + Date.now();
    const body = { v: 3, snap: true, when: Date.now(), tracks: S.tracks, wpts: S.wpts, schemas: S.schemas, set: S.set };
    await kvSet(key, JSON.stringify(body));
    const next = [...ks, key].slice(-3);
    for (const old of ks.filter(k => !next.includes(k))) await kvDel(old);
    await kvSet('snapKeys', next);
    S.set.snapAt = Date.now(); save.set();
  } catch (e) { }
}
async function snapUI() {
  const ks = ((await kvGet('snapKeys')) || []).slice().reverse();
  const rows = [];
  for (const k of ks) {
    const raw = await kvGet(k); if (!raw) continue;
    let j = {}; try { j = JSON.parse(raw); } catch (e) { continue; }
    rows.push(el('div', { class: 'item' },
      el('b', {}, new Date(j.when || 0).toLocaleString('en-GB')),
      el('div', { class: 'mut' }, `${(j.tracks || []).length} tracks · ${(j.wpts || []).length} points`),
      el('button', {
        class: 'btn sm', onclick: async () => {
          if (!confirm('Replace what is on this phone with this snapshot?')) return;
          S.tracks = j.tracks || []; S.wpts = j.wpts || []; if (j.schemas) S.schemas = j.schemas;
          await save.tracks(); await save.wpts(); await save.schemas(); drawTracks(); drawWpts(); closeModal(); render();
          toast('Snapshot restored');
        }
      }, 'Restore this one')));
  }
  modal('Automatic snapshots', el('p', { class: 'mut' }, 'A copy is kept on this phone once a day (last three). It saves you from a wrong tap — it does not survive losing the phone, so keep the file backup too.'),
    rows.length ? rows : el('p', { class: 'mut' }, 'No snapshot yet.'),
    el('div', { class: 'row act' },
      el('button', { class: 'btn', onclick: async () => { await autoSnap(true); closeModal(); snapUI(); toast('Snapshot saved'); } }, 'Take one now'),
      el('button', { class: 'btn', onclick: closeModal }, 'Close')));
}

// ---------- install as an app ----------
addEventListener('beforeinstallprompt', e => { e.preventDefault(); bpDeferred = e; });
async function installApp() {
  if (bpDeferred) { bpDeferred.prompt(); const r = await bpDeferred.userChoice.catch(() => ({})); bpDeferred = null; toast(r.outcome === 'accepted' ? 'Installing…' : 'You can install later from the browser menu'); return; }
  const ua = navigator.userAgent;
  modal('Install Trail Atlas',
    el('p', {}, 'Trail Atlas runs as an app with its own icon and opens full screen, offline.'),
    el('ol', { style: 'padding-left:20px' },
      el('li', {}, ua.match(/iPhone|iPad/) ? 'Safari: tap the Share button, then “Add to Home Screen”.' : 'Chrome: menu ⋮ → “Install app” (or “Add to Home screen”).'),
      el('li', {}, 'Open it once with internet so the app files are saved.'),
      el('li', {}, 'After that, downloaded maps and areas work with no signal.')),
    el('p', { class: 'mut' }, 'Keep the screen on while recording: browsers slow down in the background (unlike a native app).'),
    el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: closeModal }, 'Close')));
}

window.TApack = { STATUS, beaconUI, makeBeacons, accUI, addCrosshairPoint, fitFromCP, applyCP, shareProjectUI, mergeProject, autoSnap, snapUI, installApp, setStatus, statusUI };
setTimeout(() => autoSnap(false), 4000);

// =====================================================================
// status dashboard — what the whole job looks like at a glance
// =====================================================================
const ST_COL = { pending: STATUS.pending.c, progress: STATUS.progress.c, resolved: STATUS.resolved.c, none: '#9AA79D' };
function statsOf(list) {
  const mk = () => ({ n: 0, pending: 0, progress: 0, resolved: 0, none: 0 });
  const all = mk(), layers = new Map(), crew = new Map();
  list.forEach(w => {
    const k = w.st && STATUS[w.st] ? w.st : 'none';
    all.n++; all[k]++;
    const L = w.folder || 'No layer';
    if (!layers.has(L)) layers.set(L, mk()); const l = layers.get(L); l.n++; l[k]++;
    const c = (w.by || '').trim();
    if (c) { if (!crew.has(c)) crew.set(c, mk()); const x = crew.get(c); x.n++; x[k]++; }
  });
  return { all, layers: [...layers.entries()], crew: [...crew.entries()], total: all.n, done: all.resolved };
}
const pctDone = st => st.total ? Math.round(st.done / st.total * 100) : 0;
function ring(pct, size = 108) {
  const c = 2 * Math.PI * 44, on = c * Math.max(0, Math.min(100, pct)) / 100;
  const wrap = el('div', { class: 'ring' + (size < 70 ? ' sm' : ''), style: `width:${size}px;height:${size}px` });
  wrap.innerHTML = `<svg viewBox="0 0 104 104" width="${size}" height="${size}" aria-hidden="true">
<circle cx="52" cy="52" r="44" fill="none" stroke="rgba(0,0,0,.09)" stroke-width="11"/>
<circle cx="52" cy="52" r="44" fill="none" stroke="${pct >= 100 ? '#2F6B40' : '#1D6FB8'}" stroke-width="11" stroke-linecap="round"
 stroke-dasharray="${on} ${c - on}" transform="rotate(-90 52 52)"/></svg>
<div class="ringt"><b>${pct}%</b><span>done</span></div>`;
  return wrap;
}
function sbar(o, h = 12) {
  const total = o.n || 1, bar = el('div', { class: 'sbar', style: `height:${h}px` });
  ['resolved', 'progress', 'pending', 'none'].forEach(k => {
    if (!o[k]) return;
    bar.append(el('i', { style: `width:${o[k] / total * 100}%;background:${ST_COL[k]}` }));
  });
  return bar;
}
const ageDays = w => Math.max(0, Math.floor((Date.now() - (w.t || Date.now())) / 864e5));
function flyToWpt(w) {
  closeModal();
  map.flyTo([w.lat, w.lon], Math.max(map.getZoom(), 17), { duration: .6 });
  setTimeout(() => { const l = wptLayers && wptLayers[w.id]; if (l && l.openPopup) l.openPopup(); else wptPopup(w); }, 800);
}
function dashUI() {
  const list = S.wpts.filter(w => !w.hidden), st = statsOf(list), pct = pctDone(st);
  const tile = (k, label) => el('div', { class: 'stat', style: 'flex:1 1 0;min-width:0' },
    el('div', { class: 'mut', style: `font-size:12px;color:${ST_COL[k]}` }, label),
    el('div', { style: 'font:700 22px Archivo;line-height:1.15' }, String(st.all[k])));
  const box = el('div', { class: 'dash' },
    el('div', { class: 'dashhero' }, ring(pct),
      el('div', { style: 'flex:1 1 0;min-width:0' },
        el('div', { style: 'display:flex;gap:7px;margin-bottom:7px' }, tile('resolved', 'Resolved'), tile('progress', 'In progress')),
        el('div', { style: 'display:flex;gap:7px' }, tile('pending', 'Pending'), tile('none', 'No status')))),
    list.length ? sbar(st.all, 14) : '',
    el('div', { class: 'mut', style: 'margin:7px 0 2px;font-size:12.5px' },
      list.length ? `${st.done} of ${st.total} points finished · ${st.all.pending} still waiting` : 'No points yet. Add points, then mark each one Pending / In progress / Resolved.'));
  if (st.layers.length > 1) box.append(el('h4', { class: 'dh' }, 'By layer'));
  st.layers.slice().sort((a, b) => (a[1].resolved / (a[1].n || 1)) - (b[1].resolved / (b[1].n || 1))).forEach(([name, o]) => {
    if (st.layers.length < 2) return;
    box.append(el('div', { class: 'lrow', onclick: () => { closeModal(); document.querySelector('nav button[data-tab="wpts"]').click(); } },
      el('div', { class: 'lrow-h' }, el('b', {}, name), el('span', { class: 'mut' }, `${o.resolved}/${o.n} done`)), sbar(o, 9)));
  });
  if (st.crew.length) {
    box.append(el('h4', { class: 'dh' }, 'By crew'));
    st.crew.forEach(([name, o]) => box.append(el('div', { class: 'lrow' },
      el('div', { class: 'lrow-h' }, el('b', {}, name), el('span', { class: 'mut' }, `${o.resolved}/${o.n} done`)), sbar(o, 9))));
  }
  const att = list.filter(w => w.st !== 'resolved').sort((a, b) => (b.t || 0) - (a.t || 0)).slice(0, 6);
  if (att.length) {
    box.append(el('h4', { class: 'dh' }, 'Still open'));
    att.forEach(w => box.append(el('div', { class: 'att', onclick: () => flyToWpt(w) },
      el('span', { class: 'sbdot', style: `background:${ST_COL[w.st || 'none']}` }),
      el('div', { class: 'n' }, el('b', {}, w.name || 'Point'),
        el('div', { class: 'mut' }, `${w.folder || 'No layer'} · ${ageDays(w)}d old${w.by ? ' · ' + w.by : ''}`)),
      el('button', { class: 'btn sm', onclick: e => { e.stopPropagation(); statusUI(w, dashUI); } }, 'Set status'))));
  }
  modal('Status dashboard',
    el('p', { class: 'mut', style: 'margin-top:-4px' }, 'Grouped by layer and crew. Tap an open point to jump to it, or change its status without leaving this screen.'),
    box,
    el('div', { class: 'row act' },
      el('button', { class: 'btn', onclick: statusReport }, 'PDF report'),
      el('button', { class: 'btn', onclick: closeModal }, 'Close')));
}
async function statusReport() {
  const list = S.wpts.filter(w => !w.hidden), st = statsOf(list), pct = pctDone(st);
  if (!list.length) { toast('No points to report'); return; }
  const b = L.latLngBounds(list.map(w => [w.lat, w.lon]));
  if (b.getNorthEast().equals(b.getSouthWest())) b.extend([b.getCenter().lat + .002, b.getCenter().lng + .002]);
  toast('Building report…');
  try {
    // paint the map by status so the printed dots match the printed key, then restore
    const oldCols = list.map(w => w.color);
    list.forEach(w => w.color = ST_COL[w.st || 'none']); drawWpts();
    let snap;
    try { snap = await withView(b, () => snapshotMap(null, 1), 1100, 560); }
    finally { list.forEach((w, i) => w.color = oldCols[i]); drawWpts(); }
    const { cv, mapRect } = statusPage(st, list, snap, pct);
    await shareFile('status-' + new Date().toISOString().slice(0, 10) + '.pdf', await geoPdf(cv, mapRect, snap.corners, 'Work status'), 'application/pdf');
  } catch (e) { console.error(e); toast('Report failed: ' + e.message); }
}
function statusPage(st, list, snap, pct) { // A4 portrait, 150 dpi
  const W = 1240, H = 1754, M = 70, mw = W - 2 * M;
  const cv = el('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d');
  g.fillStyle = PAPER; g.fillRect(0, 0, W, H);
  // header
  g.fillStyle = INK; g.fillRect(0, 0, W, 150); g.fillStyle = FLAG; g.fillRect(0, 150, W, 7);
  g.fillStyle = '#F1F5EF'; g.font = '680 44px Archivo, sans-serif'; if ('fontStretch' in g) g.fontStretch = 'semi-expanded';
  g.fillText('Work status', M, 78);
  if ('fontStretch' in g) g.fontStretch = 'normal';
  g.font = '500 21px Archivo, sans-serif'; g.fillStyle = 'rgba(241,245,239,.82)';
  const sub = `${st.done} of ${st.total} points finished · ${st.layers.length} layer${st.layers.length > 1 ? 's' : ''}` +
    (st.crew.length ? ` · ${st.crew.length} crew` : '') + ` · ${new Date().toLocaleString('en-GB')}`;
  g.fillText(sub, M, 118);
  g.textAlign = 'right'; g.font = '700 44px Archivo, sans-serif'; g.fillStyle = '#F1F5EF'; g.fillText(pct + '%', W - M, 82);
  g.font = '560 15px Archivo, sans-serif'; g.fillStyle = 'rgba(241,245,239,.7)'; g.fillText('DONE', W - M, 108); g.textAlign = 'left';
  // map
  let y = 200; const maxH = 660, ar = snap.cv.height / snap.cv.width;
  let dw = mw, dh = mw * ar; if (dh > maxH) { dh = maxH; dw = dh / ar; }
  const dx = M + (mw - dw) / 2;
  g.drawImage(snap.cv, dx, y, dw, dh);
  try { scaleNorth(g, dx, y, dw, dh, snap.mpp / (dw / snap.cv.width), 1.6); } catch (e) { }
  g.strokeStyle = INK; g.lineWidth = 2; g.strokeRect(dx, y, dw, dh);
  const mapRect = [dx, y, dw, dh]; y += dh + 34;
  // four status tiles
  const tw = (mw - 3 * 14) / 4;
  [['resolved', 'Resolved'], ['progress', 'In progress'], ['pending', 'Pending'], ['none', 'No status']].forEach(([k, label], i) => {
    const x = M + i * (tw + 14);
    g.fillStyle = 'rgba(0,0,0,.045)'; g.beginPath(); g.roundRect ? g.roundRect(x, y, tw, 82, 12) : g.rect(x, y, tw, 82); g.fill();
    g.fillStyle = ST_COL[k]; g.fillRect(x, y, 5, 82);
    g.fillStyle = ST_COL[k]; g.font = '620 17px Archivo, sans-serif'; g.fillText(label, x + 18, y + 30);
    g.fillStyle = INK; g.font = '700 34px Archivo, sans-serif'; g.fillText(String(st.all[k]), x + 18, y + 68);
  });
  y += 82 + 26;
  // progress bar
  const barH = 15; let bx = M;
  ['resolved', 'progress', 'pending', 'none'].forEach(k => { const w = st.all[k] / (st.total || 1) * mw; if (!w) return; g.fillStyle = ST_COL[k]; g.fillRect(bx, y, w, barH); bx += w; });
  g.strokeStyle = 'rgba(0,0,0,.12)'; g.lineWidth = 1; g.strokeRect(M, y, mw, barH);
  y += barH + 26;
  // by layer / by crew, two columns
  const colW = (mw - 40) / 2, top = y;
  const block = (title, entries, x) => {
    let cy = top;
    g.fillStyle = INK2; g.font = '650 14px Archivo, sans-serif'; g.fillText(title.toUpperCase(), x, cy); cy += 22;
    entries.slice(0, 5).forEach(([n, o]) => {
      g.fillStyle = INK; g.font = '600 19px Archivo, sans-serif';
      let t = n; while (g.measureText(t).width > colW - 90 && t.length > 4) t = t.slice(0, -2) + '…'; g.fillText(t, x, cy + 16);
      g.textAlign = 'right'; g.fillStyle = INK2; g.font = '560 17px Archivo, sans-serif'; g.fillText(`${o.resolved}/${o.n}`, x + colW, cy + 16); g.textAlign = 'left';
      let px = x; const py = cy + 24;
      ['resolved', 'progress', 'pending', 'none'].forEach(k => { const w = o[k] / (o.n || 1) * (colW - 90); if (!w) return; g.fillStyle = ST_COL[k]; g.fillRect(px, py, w, 6); px += w; });
      cy += 48;
    });
    return cy;
  };
  const endA = block('By layer', st.layers.slice().sort((a, c) => (a[1].resolved / (a[1].n || 1)) - (c[1].resolved / (c[1].n || 1))), M);
  const endB = st.crew.length ? block('By crew', st.crew, M + colW + 40) : top;
  y = Math.max(endA, endB) + 18;
  // point list — the legend, two columns
  g.strokeStyle = RULE; g.lineWidth = 1.5; g.beginPath(); g.moveTo(M, y); g.lineTo(M + mw, y); g.stroke(); y += 26;
  g.fillStyle = INK2; g.font = '650 14px Archivo, sans-serif'; g.fillText('ON THIS MAP', M, y); y += 16;
  const avail = H - 96 - y;
  const rows = Math.min(11, Math.ceil(list.length / 2), Math.max(1, Math.floor(avail / 40)));
  const step = Math.max(38, Math.min(58, avail / Math.max(rows, 1)));
  const sorted = list.slice().sort((a, c) => (a.st === 'resolved') - (c.st === 'resolved'));
  sorted.slice(0, rows * 2).forEach((w, i) => {
    const cx = M + Math.floor(i / rows) * (colW + 40), cy = y + (i % rows) * step + 22;
    g.fillStyle = ST_COL[w.st || 'none']; g.beginPath(); g.arc(cx + 7, cy - 6, 7, 0, 7); g.fill();
    g.fillStyle = INK; g.font = '600 17px Archivo, sans-serif';
    let t = w.name || 'Point'; const room = colW - 108;
    while (g.measureText(t).width > room && t.length > 4) t = t.slice(0, -2) + '…';
    g.fillText(t, cx + 24, cy);
    g.fillStyle = INK2; g.font = '540 15px Archivo, sans-serif';
    g.fillText((STATUS[w.st] ? STATUS[w.st].n : 'No status') + (w.by ? ' · ' + w.by : ''), cx + 24, cy + 18);
  });
  // footer
  g.fillStyle = RULE; g.fillRect(M, H - 74, mw, 1.5);
  g.fillStyle = INK2; g.font = '500 16px Archivo, sans-serif';
  g.fillText(`Trail Atlas · WGS 84 · ${st.total} points · ` + (sorted.length > rows * 2 ? `${sorted.length - rows * 2} more on screen` : 'all points listed'), M, H - 44);
  return { cv, mapRect };
}
