const SHELL = 'trailatlas-shell-0ac1d8e950', TILES = 'tiles-v1', OFF = 'offline-v1', MBT = 'mbtiles-v1';
const FILES = ['./', 'index.html', 'core.js', 'app.js', 'extras.js', 'features.js', 'lib/leaflet-rotate.js', 'lib/proj4.js', 'manifest.json', 'icon.svg', 'icon-192.png', 'icon-512.png', 'lib/leaflet.js', 'lib/pdf.min.js', 'lib/pdf.worker.min.js', 'lib/geotiff.js', 'lib/sql-wasm.js', 'lib/sql-wasm.wasm', 'lib/leaflet.css', 'lib/fonts/archivo.woff2', 'lib/images/layers.png', 'lib/images/layers-2x.png', 'lib/images/marker-icon.png', 'lib/images/marker-shadow.png'];
const TILE_HOSTS = ['tile.openstreetmap.org', 'a.tile.opentopomap.org', 'server.arcgisonline.com', 'a.tile.openstreetmap.fr', 'a.tile-cyclosm.openstreetmap.fr', 'a.basemaps.cartocdn.com', 'tiles.maps.eox.at', 'gibs.earthdata.nasa.gov', 'wayback.maptiles.arcgis.com', 'api.maptiler.com', 'tile.thunderforest.com', 'tiles.stadiamaps.com'];
const MAX_AUTO = 3500; // keep the browse cache near ~100 MB; explicit offline areas live in their own cache and are never trimmed
let trimming = false;
async function trim(c) {
  if (trimming) return; trimming = true;
  try { const ks = await c.keys(); if (ks.length > MAX_AUTO) for (const k of ks.slice(0, ks.length - MAX_AUTO + 200)) await c.delete(k); } catch (e) { }
  trimming = false;
}

self.addEventListener('install', e => { e.waitUntil(caches.open(SHELL).then(c => c.addAll(FILES))); });
self.addEventListener('message', e => { if (e.data && e.data.type === 'skip-waiting') self.skipWaiting(); });
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== SHELL && k !== TILES && k !== OFF && k !== MBT).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  const tile = TILE_HOSTS.includes(u.hostname) || /\/api\/tiles\/\d+\/\d+\/\d+\.mvt$/.test(u.pathname) || (u.hostname === 'planetarycomputer.microsoft.com' && u.pathname.includes('/tiles/'));
  if (tile) {
    e.respondWith((async () => {
      try {
        const off = await caches.open(OFF), pinned = await off.match(u.href);
        if (pinned) return pinned;                       // downloaded for offline use: always first
        const auto = await caches.open(TILES), hit = await auto.match(u.href);
        if (hit) return hit;
        const r = await fetch(u.href, { mode: 'cors' });
        if (r.ok) { auto.put(u.href, r.clone()).then(() => trim(auto)).catch(() => { }); }
        return r;
      } catch (err) { return new Response('', { status: 504 }); }
    })());
  } else if (u.origin === location.origin) {
    e.respondWith(caches.match(e.request, { ignoreSearch: true }).then(hit => {
      const net = fetch(e.request).then(r => { if (r.ok) caches.open(SHELL).then(c => c.put(e.request, r.clone())); return r; }).catch(() => hit);
      return hit || net;
    }));
  }
});
