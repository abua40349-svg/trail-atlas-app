// core.js — lapisan teras (dimuat sebelum app.js): log ralat, storan IndexedDB yang selamat, versi skema.
// Skrip biasa: semua nama di bawah ialah global yang dipakai app.js / extras.js / features.js.

// ---------- log ralat (30 terakhir, disimpan di peranti sahaja; tiada data dihantar ke mana-mana) ----------
const taErrLog = {
  KEY: 'taErr', MAX: 30,
  get() { try { return JSON.parse(localStorage.getItem(this.KEY) || '[]'); } catch (e) { return []; } },
  add(kind, msg, src) {
    try {
      const a = this.get(); a.push({ t: new Date().toISOString(), kind, msg: String(msg).slice(0, 300), src: src ? String(src).slice(0, 120) : '' });
      localStorage.setItem(this.KEY, JSON.stringify(a.slice(-this.MAX)));
    } catch (e) { /* storan penuh: ralat log tidak boleh mencetuskan ralat lain */ }
  },
  clear() { try { localStorage.removeItem(this.KEY); } catch (e) { } },
  report() {
    return JSON.stringify({ app: 'Trail Atlas', at: new Date().toISOString(), ua: navigator.userAgent, schema: typeof SCHEMA_VERSION === 'number' ? SCHEMA_VERSION : null, store: storeState, errors: this.get() }, null, 1);
  }
};
let _lastErrToast = 0;
function _errToast() {
  const now = Date.now(); if (now - _lastErrToast < 60000) return; _lastErrToast = now;
  try { toast('Something went wrong — details saved. More → Copy error report', 5000); } catch (e) { }
}
addEventListener('error', e => {
  if (/ResizeObserver loop/.test(e.message || '')) return;
  taErrLog.add('error', e.message || 'error', (e.filename || '').split('/').pop() + ':' + (e.lineno || 0)); _errToast();
});
addEventListener('unhandledrejection', e => {
  const r = e.reason; taErrLog.add('promise', (r && (r.stack || r.message)) || r || 'rejection'); _errToast();
});

// ---------- keadaan storan + amaran ----------
const storeState = { fail: 0, locked: false, why: '' };
function _banner(text) {
  let b = document.getElementById('storeWarn');
  if (!b) {
    b = document.createElement('div'); b.id = 'storeWarn'; b.setAttribute('role', 'alert');
    b.style.cssText = 'position:fixed;left:8px;right:8px;top:calc(8px + env(safe-area-inset-top));z-index:3000;background:#7a1f1f;color:#fff;padding:10px 12px;border-radius:12px;font:600 13.5px/1.35 Archivo,sans-serif;display:flex;gap:10px;align-items:center;box-shadow:0 6px 24px rgba(0,0,0,.45)';
    const t = document.createElement('span'); t.style.flex = '1'; t.className = 'sw-t';
    const s = document.createElement('button'); s.textContent = 'Save backup'; s.style.cssText = 'border:0;border-radius:8px;padding:7px 10px;font:inherit;cursor:pointer'; s.onclick = () => { try { backup(false); } catch (e) { } };
    const x = document.createElement('button'); x.textContent = '✕'; x.setAttribute('aria-label', 'Dismiss'); x.style.cssText = 'border:0;background:transparent;color:#fff;font-size:16px;cursor:pointer'; x.onclick = () => b.remove();
    b.append(t, s, x); document.body.append(b);
  }
  b.querySelector('.sw-t').textContent = text;
}
function storeFail(op, key, err, lock) {
  storeState.fail++; const why = (err && (err.name || err.message)) || String(err || 'unknown');
  taErrLog.add('storage', `${op} ${key}: ${why}`);
  if (lock) { storeState.locked = true; storeState.why = why; }
  const msg = lock
    ? 'Saved data could not be read safely, so saving is paused to protect it. Reload the app; if this repeats, save a backup.'
    : 'Could not save your latest changes (storage full or blocked). Save a backup file now, then free some space.';
  const go = () => _banner(msg); if (document.body) go(); else addEventListener('DOMContentLoaded', go);
}

// ---------- storan IndexedDB ----------
const db = new Promise(res => {
  let r; try { r = indexedDB.open('jejak', 1); } catch (e) { storeFail('open', '-', e, true); return res(null); }
  r.onupgradeneeded = () => r.result.createObjectStore('kv');
  r.onsuccess = () => res(r.result);
  r.onerror = r.onblocked = () => { storeFail('open', '-', r.error, true); res(null); };
});
const kvGet = async k => {
  const d = await db; if (!d) return undefined;
  return new Promise(r => {
    let q; try { q = d.transaction('kv').objectStore('kv').get(k); } catch (e) { storeFail('get', k, e, true); return r(undefined); }
    q.onsuccess = () => r(q.result);
    q.onerror = () => { storeFail('get', k, q.error, true); r(undefined); };
  });
};
// Pulangkan true bila berjaya, false bila gagal (tidak pernah tergantung, tidak pernah membuang ralat).
const kvSet = async (k, v) => {
  const d = await db; if (!d || storeState.locked) return false;
  return new Promise(r => {
    let t, done = false; const end = ok => { if (!done) { done = true; r(ok); } };
    try { t = d.transaction('kv', 'readwrite'); t.objectStore('kv').put(v, k); } catch (e) { storeFail('set', k, e); return end(false); }
    t.oncomplete = () => end(true);
    t.onerror = t.onabort = () => { if (!done) storeFail('set', k, t.error); end(false); };
  });
};
const kvDel = async k => {
  const d = await db; if (!d || storeState.locked) return false;
  return new Promise(r => {
    let t, done = false; const end = ok => { if (!done) { done = true; r(ok); } };
    try { t = d.transaction('kv', 'readwrite'); t.objectStore('kv').delete(k); } catch (e) { storeFail('del', k, e); return end(false); }
    t.oncomplete = () => end(true);
    t.onerror = t.onabort = () => { if (!done) storeFail('del', k, t.error); end(false); };
  });
};

// ---------- versi skema data (di aras kv, bukan versi IndexedDB) ----------
// Setiap migrasi mesti idempotent. Sebelum migrasi, salinan trek/titik disimpan sebagai 'bak:v<N>:<kunci>'.
const SCHEMA_VERSION = 2;
const MIGRATIONS = {
  2: async () => { /* v1 -> v2: tiada perubahan bentuk data; hanya menanda versi supaya migrasi akan datang ada titik mula */ }
};
async function migrateStore() {
  const d = await db; if (!d) return;
  const v = (await kvGet('schemaV')) || 1;
  if (v > SCHEMA_VERSION) { storeFail('schema', 'schemaV', 'data dari versi lebih baharu (' + v + ' > ' + SCHEMA_VERSION + ')', true); return; }
  if (v === SCHEMA_VERSION) return;
  for (const k of ['tracks', 'wpts']) { const x = await kvGet(k); if (x !== undefined && !(await kvSet(`bak:v${v}:${k}`, x))) return; }
  for (let n = v + 1; n <= SCHEMA_VERSION; n++) { await MIGRATIONS[n](); if (!(await kvSet('schemaV', n))) return; }
}

// ---------- aksesibiliti: beri nama kepada kawalan borang yang dibina secara dinamik ----------
// Banyak kawalan (pilihan, nombor, fail) dibina dengan teks di sebelahnya tetapi tanpa label berkaitan, jadi pembaca skrin tidak tahu fungsinya.
// Pas ini menerbitkan nama daripada placeholder / teks bersebelahan dan menetapkan aria-label (tidak menyentuh kawalan yang sudah bernama).
function taControlName(i) {
  if (i.placeholder) return i.placeholder;
  const txt = n => (n && !/^(SCRIPT|STYLE)$/.test(n.nodeName) ? (n.textContent || '').trim() : '');
  if (i.type === 'file') { const b = i.closest('button,label,.btn'); const t = (b && txt(b)) || txt(i.nextElementSibling) || txt(i.previousElementSibling) || ''; return (t || 'Choose file').slice(0, 60); }
  for (let n = i.previousSibling; n; n = n.previousSibling) { const t = txt(n); if (t) return t.slice(0, 60); }
  const p = i.parentElement, t = p && [...p.childNodes].filter(c => c !== i && !(c.nodeType === 1 && /^(INPUT|SELECT|TEXTAREA|BUTTON)$/.test(c.tagName))).map(c => (c.textContent || '').trim()).find(Boolean);
  return (t || i.title || i.name || i.type || 'field').slice(0, 60);
}
function taLabelControls(root) {
  (root || document).querySelectorAll('input,select,textarea').forEach(i => {
    if (i.type === 'hidden' || i.getAttribute('aria-label') || i.getAttribute('aria-labelledby') || i.title || (i.id && document.querySelector(`label[for="${i.id}"]`)) || i.closest('label')) return;
    i.setAttribute('aria-label', taControlName(i));
  });
}
{ let q = 0; const run = () => { q = 0; try { taLabelControls(document.body); } catch (e) { } };
  addEventListener('DOMContentLoaded', () => { run(); new MutationObserver(() => { if (!q) q = requestAnimationFrame(run); }).observe(document.body, { childList: true, subtree: true }); }); }
