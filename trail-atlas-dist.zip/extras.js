'use strict';
// Trail Atlas extras: the remaining features found in Avenza Maps, NomadTracks and FO Maps.
// Loaded after app.js; reuses its globals and wraps a few of its functions.

Object.assign(S.set, Object.assign({ units: 'metric', angle: 'deg', posStyle: 'wedge', recMode: 'dist', recSec: 5, stamp: false, speedColour: false, footprints: true, autoBase: false, hideTools: [], hillshade: false, freeRotate: false, fires: false, customIcons: [] }, S.set));
S.geofences = []; S.bin = []; S.custom = []; S.offAreas = [];
const saveX = { geofences: () => kvSet('geofences', S.geofences), bin: () => kvSet('bin', S.bin), custom: () => kvSet('custom', S.custom), offAreas: () => kvSet('offAreas', S.offAreas) };

// ---------- projections (Malaysia RSO / Cassini and anything in WKT) ----------
const EPSG = {
  3375: '+proj=omerc +lat_0=4 +lonc=102.25 +alpha=323.0257964666666 +k=0.99984 +x_0=804671 +y_0=0 +no_uoff +gamma=323.1301023611111 +ellps=GRS80 +units=m +no_defs',
  3376: '+proj=omerc +lat_0=4 +lonc=115 +alpha=53.31580995 +k=0.99984 +x_0=0 +y_0=0 +no_uoff +gamma=53.13010236111111 +ellps=GRS80 +units=m +no_defs',
  3168: '+proj=omerc +lat_0=4 +lonc=102.25 +alpha=323.0257905 +k=0.99984 +x_0=804670.24 +y_0=0 +no_uoff +gamma=323.1301023611111 +a=6377304.063 +rf=300.8017 +towgs84=-11,851,5,0,0,0,0 +units=m +no_defs',
  4742: '+proj=longlat +ellps=GRS80 +no_defs', 4326: '+proj=longlat +datum=WGS84 +no_defs', 3857: '+proj=merc +a=6378137 +b=6378137 +lat_ts=0 +lon_0=0 +x_0=0 +y_0=0 +k=1 +units=m +nadgrids=@null +no_defs',
  // GDM2000 state Cassini grids (Peninsular Malaysia)
  3377: '+proj=cass +lat_0=2.12167974444444 +lon_0=103.427936236111 +x_0=-14810.562 +y_0=8758.32 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Johor Grid
  3378: '+proj=cass +lat_0=2.68234763611111 +lon_0=101.974905041667 +x_0=3673.785 +y_0=-4240.573 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Sembilan and Melaka Grid
  3379: '+proj=cass +lat_0=3.76938808888889 +lon_0=102.368298983333 +x_0=-7368.228 +y_0=6485.858 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Pahang Grid
  3380: '+proj=cass +lat_0=3.68464905 +lon_0=101.389107913889 +x_0=-34836.161 +y_0=56464.049 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Selangor Grid
  3381: '+proj=cass +lat_0=4.9762852 +lon_0=103.070275625 +x_0=19594.245 +y_0=3371.895 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Terengganu Grid
  3382: '+proj=cass +lat_0=5.42151754166667 +lon_0=100.344376963889 +x_0=-23.414 +y_0=62.283 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Pinang Grid
  3383: '+proj=cass +lat_0=5.96467271388889 +lon_0=100.636371111111 +x_0=0 +y_0=0 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Kedah and Perlis Grid
  3384: '+proj=cass +lat_0=4.85906302222222 +lon_0=100.815410586111 +x_0=-1.769 +y_0=133454.779 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Perak Grid
  3385: '+proj=cass +lat_0=5.97254365833333 +lon_0=102.295241669444 +x_0=13227.851 +y_0=8739.894 +ellps=GRS80 +units=m +no_defs', // GDM2000 / Kelantan Grid
};
async function projFn(code, wkt) { // -> (x,y) => [lat, lon]
  await loadScript('lib/proj4.js');
  let def = code && EPSG[code];
  if (!def && code >= 32601 && code <= 32760) def = `+proj=utm +zone=${code % 100} ${code > 32700 ? '+south ' : ''}+datum=WGS84 +units=m +no_defs`;
  if (!def && wkt) def = wkt;
  if (!def) throw Error(`coordinate system EPSG:${code} unknown — paste its proj4/WKT text in More → Coordinate systems`);
  const pr = proj4(def, 'WGS84'); return (x, y) => { const [lo, la] = pr.forward([x, y]); return [la, lo]; };
}
async function projBoth(code, wkt) { // -> { fwd: (lat, lon) => [x, y], inv: (x, y) => [lat, lon] } or null
  await loadScript('lib/proj4.js');
  let def = code && EPSG[code];
  if (!def && code >= 32601 && code <= 32760) def = `+proj=utm +zone=${code % 100} ${code > 32700 ? '+south ' : ''}+datum=WGS84 +units=m +no_defs`;
  if (!def && wkt) def = wkt;
  if (!def) return null;
  const pr = proj4(def, 'WGS84'); return { fwd: (la, lo) => pr.inverse([lo, la]), inv: (x, y) => { const [lo, la] = pr.forward([x, y]); return [la, lo]; } };
}
async function geoTiffProj(f) { // used when the built-in importer reports an unsupported system
  toast('Processing GeoTIFF with full projection support…', 8000); await loadScript('lib/geotiff.js');
  const img = await (await GeoTIFF.fromBlob(f)).getImage(), W = img.getWidth(), H = img.getHeight(), gk = img.getGeoKeys() || {}, fd = img.getFileDirectory();
  const code = gk.ProjectedCSTypeGeoKey || gk.GeographicTypeGeoKey, toLL = await projFn(code, (S.set.userProj || {})[code]);
  let gt; if (fd.ModelTransformation) { const m = fd.ModelTransformation; gt = (px, py) => [m[0] * px + m[1] * py + m[3], m[4] * px + m[5] * py + m[7]]; } else { const o = img.getOrigin(), r = img.getResolution(); gt = (px, py) => [o[0] + px * r[0], o[1] + py * r[1]]; }
  const s = Math.min(1, 4096 / Math.max(W, H)), w = Math.round(W * s), h = Math.round(H * s), rgb = await img.readRGB({ width: w, height: h, interleave: true }), cv = el('canvas'); cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d'), id = ctx.createImageData(w, h), ch = rgb.length / (w * h);
  for (let i = 0, j = 0; i < w * h; i++, j += ch) { id.data[i * 4] = rgb[j]; id.data[i * 4 + 1] = rgb[j + 1]; id.data[i * 4 + 2] = rgb[j + 2]; id.data[i * 4 + 3] = ch === 4 ? rgb[j + 3] : 255; }
  ctx.putImageData(id, 0, 0);
  await newImageMap({ name: f.name.replace(/\.[^.]+$/, ''), blob: await new Promise(r => cv.toBlob(r, 'image/jpeg', .9)), corners: [toLL(...gt(0, 0)), toLL(...gt(W, 0)), toLL(...gt(0, H))] });
  toast('GeoTIFF ready (EPSG:' + code + ')');
}
// route unsupported-projection cases (GeoTIFF / Shapefile / GeoPackage) through proj4
const _importFile = importFile;
importFile = async function (f) {
  const ext = f.name.split('.').pop().toLowerCase();
  if (ext === 'tif' || ext === 'tiff') {
    await loadScript('lib/geotiff.js'); const gk = (await (await GeoTIFF.fromBlob(f)).getImage()).getGeoKeys() || {}, code = gk.ProjectedCSTypeGeoKey || gk.GeographicTypeGeoKey || 4326;
    if (![4326, 4269, 4258, 4742, 3857, 900913, 3785, 102100].includes(code) && !(code >= 32601 && code <= 32760)) { try { return await geoTiffProj(f); } catch (e) { return toast('Could not read ' + f.name + ': ' + e.message, 7000); } }
  }
  if (ext === 'zip') { try { return await importShpZipProj(f); } catch (e) { return toast('Could not read ' + f.name + ': ' + e.message, 7000); } }
  if (ext === 'gpkg') { try { return await importGpkgProj(f); } catch (e) { return toast('Could not read ' + f.name + ': ' + e.message, 7000); } }
  return _importFile(f);
};
async function importShpZipProj(f) {
  const files = await unzip(await f.arrayBuffer()), o = { tracks: [], wpts: [] }, dec = new TextDecoder(); let found = 0;
  for (const n of Object.keys(files).filter(n => /\.shp$/i.test(n))) {
    const base = n.slice(0, -4), get = ext => files[Object.keys(files).find(k => k.toLowerCase() === (base + ext).toLowerCase())];
    const prj = get('.prj') ? dec.decode(get('.prj')) : '';
    let toLL; try { toLL = prjToLL(prj); } catch (e) { toLL = await projFn(null, prj); }
    const sh = readShp(files[n].slice().buffer, toLL), recs = get('.dbf') ? readDbf(get('.dbf')) : [];
    sh.forEach((g, i) => {
      if (!g) return; const r = recs[i] || {}, nk = Object.keys(r).find(k => /^(name|nama|title|label)$/i.test(k)), name = nk ? r[nk] : '', attrs = Object.fromEntries(Object.entries(r).filter(([k, v]) => k !== nk && v !== '' && !/^(folder|note)$/i.test(k))), note = r.note || r.NOTE || '';
      if (g.type === 'point') o.wpts.push({ name, lat: g.parts[0][0][0], lon: g.parts[0][0][1], note, attrs });
      else g.parts.forEach(p => p.length > 1 && o.tracks.push({ name, pts: p.map(q => [q[0], q[1], null, null]), kind: g.type === 'area' ? 'area' : 'line', note, attrs }));
      found++;
    });
  }
  if (!found) throw Error('no Shapefile (.shp) inside the zip');
  mergeImport(o, f.name);
}
async function importGpkgProj(f) {
  const SQL = await sqljs(), d = new SQL.Database(new Uint8Array(await f.arrayBuffer())), o = { tracks: [], wpts: [] };
  const gc = d.exec('SELECT table_name, column_name, srs_id FROM gpkg_geometry_columns')[0]; if (!gc) throw Error('no feature tables');
  for (const [tn, col, srs] of gc.values) {
    let toLL; if (srs === 4326 || srs === 0) toLL = (x, y) => [y, x]; else { const def = (d.exec(`SELECT definition FROM gpkg_spatial_ref_sys WHERE srs_id=${+srs}`)[0] || { values: [['']] }).values[0][0]; toLL = await projFn(srs, def && def !== 'undefined' ? def : null); }
    const r = d.exec(`SELECT * FROM "${tn}"`)[0]; if (!r) continue; const gi = r.columns.indexOf(col);
    for (const row of r.values) {
      const g = row[gi]; if (!g) continue; const env = [0, 32, 48, 48, 64][(g[3] >> 1) & 7] || 0, attrs = {};
      r.columns.forEach((c, i) => { if (i !== gi && c !== 'fid' && row[i] != null && row[i] !== '') attrs[c] = String(row[i]); });
      const nk = Object.keys(attrs).find(k => /^(name|nama|title)$/i.test(k)), name = nk ? attrs[nk] : '', note = attrs.note || ''; if (nk) delete attrs[nk]; delete attrs.note; delete attrs.folder;
      for (const gg of readWKB(g.subarray(8 + env), toLL)) gg.type === 'point' ? o.wpts.push({ name, lat: gg.parts[0][0][0], lon: gg.parts[0][0][1], note, attrs }) : o.tracks.push({ name, pts: gg.parts[0].map(q => [q[0], q[1], null, null]), kind: gg.type, note, attrs });
    }
  }
  d.close(); if (!o.tracks.length && !o.wpts.length) throw Error('no features found'); mergeImport(o, f.name);
}

// ---------- map rotation, follow modes, position styles ----------
let gpsMode = 'north'; // north-up follow | compass (map turns with you)
const canRotate = !!map.setBearing;
function setGpsMode(m) {
  gpsMode = m; const b = $('#fLoc'); b.classList.toggle('compass', m === 'compass'); b.title = m === 'compass' ? 'Compass mode: map turns with you' : 'My location';
  if (m !== 'compass' && canRotate && !S.set.freeRotate) map.setBearing(0); northBtn();
}
$('#fLoc').onclick = () => {
  if (watchId === null) { startGPS(); setGpsMode('north'); return; }
  if (!follow && last) { follow = true; map.setView([last.lat, last.lon], Math.max(map.getZoom(), 16)); return; }
  if (canRotate) { setGpsMode(gpsMode === 'compass' ? 'north' : 'compass'); toast(gpsMode === 'compass' ? (noCompass() ? 'Heading-up mode: the map turns to your walking direction' : 'Compass mode: the map turns with you') : 'North up'); }
};
function northBtn() { // north arrow appears when the map is rotated; tap to turn north up
  const b = $('#fNorth'), br = canRotate ? map.getBearing() : 0; if (!b) return;
  b.hidden = !br; b.firstChild.style.transform = `rotate(${-br}deg)`;
}
$('#fNorth').onclick = () => { setGpsMode('north'); if (canRotate) map.setBearing(0); };
if (canRotate) { map.on('rotate', northBtn); if (S.set.freeRotate) map.touchRotate.enable(); }
const _drawHeading = drawHeading;
drawHeading = function () {
  const m = me && me.getElement(), hd = heading(); if (!m) return;
  const dot = m.querySelector('.me'), c = m.querySelector('.cone'), br = canRotate ? map.getBearing() : 0;
  dot.dataset.style = S.set.posStyle;
  if (c) { c.style.display = hd == null || S.set.posStyle === 'dot' ? 'none' : 'block'; if (hd != null) c.style.transform = `rotate(${hd - br}deg)`; }
  if (gpsMode === 'compass' && hd != null && canRotate) map.setBearing(hd);
};

// ---------- cockpit (big live numbers while recording or navigating) ----------
let cockpitTimer = null;
function openCockpit() {
  const box = el('div', { class: 'cockpit' }), draw = () => {
    const tiles = [];
    if (rec.on) { const t = (rec.paused ? rec.pauseAt : Date.now()) - rec.t0 - rec.pauseAcc, d = pathLen(rec.pts); tiles.push(['Time', fmtT(t)], ['Distance', fmtD(d)], ['Avg speed', t > 0 ? fmtV(d / (t / 1000) * 3.6) : '—']); let up = 0; for (let i = 1; i < rec.pts.length; i++) if (rec.pts[i][2] != null && rec.pts[i - 1][2] != null && rec.pts[i][2] > rec.pts[i - 1][2]) up += rec.pts[i][2] - rec.pts[i - 1][2]; tiles.push(['Climb', fmtD(up)]); if (rec.laps && rec.laps.length) tiles.push(['Lap', String(rec.laps.length + 1)]); }
    if (last) { tiles.push(['Speed', last.spd != null ? fmtV(last.spd * 3.6) : '—'], ['Altitude', last.ele != null ? fmtD(last.ele) : '—'], ['Accuracy', '±' + Math.round(last.acc) + ' m']); const hd = heading(); if (hd != null) tiles.push(['Heading', fmtAng(hd) + ' ' + card(hd)]); }
    if (nav.t && last) { const d = hav([last.lat, last.lon], [nav.t.lat, nav.t.lon]); tiles.unshift(['To ' + nav.t.name, $('#navbar b') ? $('#navbar b').textContent : fmtD(d)]); }
    box.replaceChildren(...tiles.map(([k, v]) => el('div', { class: 'ck' }, el('span', {}, k), el('b', {}, v))));
  };
  draw(); clearInterval(cockpitTimer); cockpitTimer = setInterval(draw, 1000);
  modal('Cockpit', box, el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: () => { clearInterval(cockpitTimer); closeModal(); } }, 'Close')));
}
const _recBar = recBar;
recBar = function () {
  _recBar(); const b = $('#recbar'); if (!rec.on) return;
  b.append(' ', el('button', { class: 'btn sm', onclick: () => { rec.laps = rec.laps || []; rec.laps.push(rec.pts.length - 1); toast('Lap ' + rec.laps.length + ' marked'); } }, 'Lap'), ' ', el('button', { class: 'btn sm', onclick: openCockpit }, 'Cockpit'));
};
const _startRec = startRec;
startRec = async function (resume) {
  const was = rec.on; await _startRec(resume);
  if (!was && rec.on) { rec.laps = resume && resume.laps || []; rec.lastT = 0; setTimeout(() => { if (rec.on && (!last || last.acc > 30)) toast('Weak GPS signal (' + (last ? '±' + Math.round(last.acc) + ' m' : 'no fix yet') + '). Move to open sky for a better track.', 5000); }, 6000); }
};
const _stopRec = stopRec;
stopRec = async function () { const laps = rec.laps, id = rec.id; await _stopRec(); const t = S.tracks.find(x => x.id === id); if (t && laps && laps.length) { t.laps = laps; save.tracks(); } };
const _onPos = onPos;
onPos = function (p) {
  if (rec.on && !rec.paused && S.set.recMode === 'time') { // record by time interval instead of distance
    const c = p.coords; if (c.accuracy <= S.set.maxAcc && p.timestamp - (rec.lastT || 0) >= S.set.recSec * 1000) { rec.lastT = p.timestamp; rec.pts.push([c.latitude, c.longitude, c.altitude, p.timestamp]); rec.line.addLatLng([c.latitude, c.longitude]); if (rec.pts.length % 5 === 0) kvSet('rec', { id: rec.id, pts: rec.pts, t0: rec.t0, pauseAcc: rec.pauseAcc, laps: rec.laps }); }
    const keep = S.set.minDist; S.set.minDist = 1e9; _onPos(p); S.set.minDist = keep;
  } else _onPos(p);
  checkFences(p.coords.latitude, p.coords.longitude);
};

// ---------- geofences (alerts when entering / leaving an area or a point's radius) ----------
const gFence = L.layerGroup().addTo(map);
function inPoly(ll, pts) { let ins = false; for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) { const [yi, xi] = pts[i], [yj, xj] = pts[j]; if ((yi > ll[0]) !== (yj > ll[0]) && ll[1] < (xj - xi) * (ll[0] - yi) / (yj - yi) + xi) ins = !ins; } return ins; }
function fenceInside(g, ll) { if (g.area) { const t = S.tracks.find(x => x.id === g.area); return t ? inPoly(ll, t.pts) : null; } return hav(ll, [g.lat, g.lon]) <= g.radius; }
function drawFences() { gFence.clearLayers(); S.geofences.forEach(g => { if (!g.area) L.circle([g.lat, g.lon], { radius: g.radius, color: '#FF5B1A', weight: 2, dashArray: '4 6', fillOpacity: .05, interactive: false }).addTo(gFence); }); }
function checkFences(lat, lon) {
  let changed = false;
  for (const g of S.geofences) {
    const inside = fenceInside(g, [lat, lon]); if (inside == null) continue;
    if (g.inside != null && inside !== g.inside && (g.on === 'both' || (g.on === 'enter') === inside)) {
      const msg = `${inside ? 'Entered' : 'Left'} ${g.name}`; toast('⚠ ' + msg, 6000); navigator.vibrate && navigator.vibrate([300, 120, 300]);
      try { if (Notification.permission === 'granted') new Notification('Trail Atlas', { body: msg, icon: 'icon-192.png' }); } catch (e) { }
    }
    if (g.inside !== inside) { g.inside = inside; changed = true; }
  }
  if (changed) saveX.geofences();
}
function fenceUI(f, kind) {
  const g = S.geofences.find(x => x.target === f.id), on = el('select'); [['', 'Off'], ['enter', 'When I enter'], ['leave', 'When I leave'], ['both', 'Enter and leave']].forEach(([v, n]) => on.append(el('option', { value: v }, n))); on.value = g ? g.on : '';
  const rad = el('input', { type: 'number', min: 10, max: 50000, value: g ? g.radius : 100, style: 'width:110px' });
  const apply = () => {
    S.geofences = S.geofences.filter(x => x.target !== f.id);
    if (on.value) { S.geofences.push({ id: uid(), target: f.id, name: f.name, on: on.value, area: kind === 'area' ? f.id : null, lat: f.lat, lon: f.lon, radius: +rad.value || 100, inside: null }); try { Notification.requestPermission && Notification.permission === 'default' && Notification.requestPermission(); } catch (e) { } startGPS(); }
    saveX.geofences(); drawFences();
  };
  on.onchange = apply; rad.onchange = apply;
  return [el('label', {}, kind === 'area' ? 'Geofence alert for this area' : 'Geofence alert around this point'), el('div', { class: 'row', style: 'flex-wrap:nowrap' }, on, kind === 'wpt' ? rad : '', kind === 'wpt' ? el('span', { class: 'mut' }, 'm') : '')];
}

// ---------- extra fields in the details dialog ----------
const ACTIVITIES = ['Walk / survey', 'Hike', 'Run', 'Cycle', 'Motorbike', 'Drive', 'Boat', 'Other'];
const _editFeature = editFeature;
editFeature = function (f, kind) {
  _editFeature(f, kind);
  const box = $('#modal .mbox'), act = box.querySelector('.act'); if (!act) return;
  const add = (...n) => n.flat().forEach(x => x && box.insertBefore(x, act));
  if (kind === 'wpt') {
    const paste = el('input', { type: 'text', placeholder: 'Paste coordinates, UTM, MGRS or a Google/Apple Maps link' });
    paste.onchange = () => { const p = parseAnyCoord(paste.value); if (!p) return toast('Could not read that position'); const la = box.querySelector('[data-k=lat]'), lo = box.querySelector('[data-k=lon]'); la.value = p[0].toFixed(7); lo.value = p[1].toFixed(7); toast('Position filled in. Tap Save to keep it.'); };
    add(el('label', {}, 'Set position from text'), paste, f.ele != null ? el('div', { class: 'mut' }, 'Elevation ' + fmtD(f.ele)) : '', fenceUI(f, 'wpt'));
  } else {
    const isTrack = !f.kind || f.kind === 'track', a = el('select', { onchange: e => { f.activity = e.target.value; save.tracks(); } }, el('option', { value: '' }, '—'), ACTIVITIES.map(x => el('option', { value: x }, x))); a.value = f.activity || '';
    const rr = el('input', { type: 'number', min: 10, max: 2000, value: f.offRadius || 40, style: 'width:110px', onchange: e => { f.offRadius = +e.target.value || 40; save.tracks(); } });
    const sp = el('input', { type: 'number', min: 5, max: 5000, value: 100, style: 'width:100px' }), code = el('input', { type: 'text', value: (f.name.match(/[A-Z0-9]+/) || ['P'])[0].slice(0, 6), style: 'width:100px' });
    add(isTrack ? [el('label', {}, 'Activity'), a] : '', f.kind !== 'area' ? [el('label', {}, 'Off-route alert distance when following'), el('div', { class: 'row', style: 'flex-wrap:nowrap' }, rr, el('span', { class: 'mut' }, 'm'))] : '',
      f.kind === 'area' ? fenceUI(f, 'area') : '',
      f.laps && f.laps.length ? lapTable(f) : '',
      el('label', {}, 'Tools'),
      el('div', { class: 'row' },
        f.kind !== 'area' ? el('button', { class: 'btn sm', onclick: () => { const t = { ...f, id: uid(), kind: 'area', name: f.name + ' (area)', color: '#7B4FC9', pts: f.pts.map(p => [p[0], p[1], null, null]), photos: [], created: Date.now() }; S.tracks.push(t); save.tracks(); drawTracks(); closeModal(); editFeature(t, 'track'); toast('Area created: ' + fmtA(areaOf(t.pts))); } }, 'Convert to area') : '',
        f.kind !== 'area' && f.pts.some(p => p[3]) ? el('button', { class: 'btn sm', onclick: () => { closeModal(); playTrack(f); } }, 'Play back') : '',
        f.kind !== 'area' ? el('button', { class: 'btn sm', onclick: () => { closeModal(); trackVideo(f); } }, 'Video') : ''),
      f.kind !== 'area' ? [el('label', {}, 'Numbered points along the line'), el('div', { class: 'row', style: 'flex-wrap:nowrap' }, el('span', { class: 'mut' }, 'every'), sp, el('span', { class: 'mut' }, 'm, code'), code, el('button', { class: 'btn sm', onclick: () => callPoints(f, +sp.value, code.value.trim() || 'P') }, 'Points'))] : '');
  }
};
function lapTable(t) {
  const idx = [0, ...t.laps, t.pts.length - 1], rows = [];
  for (let i = 1; i < idx.length; i++) { const seg = t.pts.slice(idx[i - 1], idx[i] + 1), d = pathLen(seg), dt = seg[seg.length - 1][3] - seg[0][3]; rows.push(el('div', { class: 'mut' }, `Lap ${i}: ${fmtD(d)}` + (dt ? `, ${fmtT(dt)}, ${fmtV(d / (dt / 1000) * 3.6)}` : ''))); }
  return [el('label', {}, 'Laps'), ...rows];
}
function pointAlong(P, dist) { let acc = 0; for (let i = 1; i < P.length; i++) { const d = hav(P[i - 1], P[i]); if (acc + d >= dist) { const u = (dist - acc) / (d || 1); return [P[i - 1][0] + u * (P[i][0] - P[i - 1][0]), P[i - 1][1] + u * (P[i][1] - P[i - 1][1])]; } acc += d; } return [P[P.length - 1][0], P[P.length - 1][1]]; }
function callPoints(t, step, code) {
  const L_ = pathLen(t.pts); if (!(step > 0) || L_ / step > 500) return toast('Choose a larger spacing (max 500 points)');
  const fo = t.name + ' points'; let n = 0;
  for (let d = 0; d <= L_ + .01; d += step) { const p = pointAlong(t.pts, d); S.wpts.push({ id: uid(), name: `${code}-${String(++n).padStart(3, '0')}`, note: `${fmtD(d)} along ${t.name}`, lat: p[0], lon: p[1], color: t.color, icon: '🚩', folder: fo, attrs: { chainage_m: String(Math.round(d)) }, photos: [], t: Date.now() }); }
  save.wpts(); drawWpts(); closeModal(); toast(`${n} numbered points placed in layer "${fo}"`);
}

// ---------- positions: paste text, project by bearing & distance, MGRS ----------
function mgrsInv(s) { // "47N QD 98648 47340" -> [lat, lon]
  const m = s.toUpperCase().replace(/\s+/g, '').match(/^(\d{1,2})([C-HJ-NP-X])([A-HJ-NP-Z])([A-HJ-NP-V])(\d*)$/); if (!m || m[5].length % 2) return null;
  const zone = +m[1], band = m[2], set = (zone - 1) % 6 + 1, k = m[5].length / 2, col = ['ABCDEFGH', 'JKLMNPQR', 'STUVWXYZ'][(set - 1) % 3].indexOf(m[3]);
  if (col < 0) return null; let row = 'ABCDEFGHJKLMNPQRSTUV'.indexOf(m[4]); if (set % 2 === 0) row = (row - 5 + 20) % 20;
  const E = (col + 1) * 1e5 + (k ? +m[5].slice(0, k) * 10 ** (5 - k) + 10 ** (5 - k) / 2 * 0 : 5e4), n0 = row * 1e5 + (k ? +m[5].slice(k) * 10 ** (5 - k) : 5e4);
  const lo = -80 + 'CDEFGHJKLMNPQRSTUVWX'.indexOf(band) * 8, hi = lo + (band === 'X' ? 12 : 8), south = band < 'N';
  for (let c = 0; c < 6; c++) { const p = utmInv(zone, south, E, n0 + c * 2e6); if (p[0] >= lo - .5 && p[0] <= hi + .5) return p; }
  return null;
}
function parseAnyCoord(t) {
  t = t.trim(); let m;
  if ((m = t.match(/@(-?\d+\.\d+),(-?\d+\.\d+)/)) || (m = t.match(/[?&](?:q|ll|query|destination)=(-?\d+\.\d+)(?:,|%2C)(-?\d+\.\d+)/))) return [+m[1], +m[2]];
  if ((m = t.match(/^(-?\d+(?:\.\d+)?)\s*[, ]\s*(-?\d+(?:\.\d+)?)$/)) && Math.abs(+m[1]) <= 90 && Math.abs(+m[2]) <= 180) return [+m[1], +m[2]];
  if ((m = t.match(/^(\d{1,2})\s*([NS])\s+(\d+(?:\.\d+)?)\s*E?\s+(\d+(?:\.\d+)?)\s*N?$/i))) return utmInv(+m[1], m[2].toUpperCase() === 'S', +m[3], +m[4]);
  const dm = [...t.matchAll(/(\d+)[°\s]+(\d+)['\s]+(\d+(?:\.\d+)?)["\s]*([NSEW])/gi)]; if (dm.length === 2) { const v = x => (+x[1] + x[2] / 60 + x[3] / 3600) * (/[SW]/i.test(x[4]) ? -1 : 1); return [v(dm[0]), v(dm[1])]; }
  return mgrsInv(t);
}
function destPoint(p, brgDeg, dist) { const d = dist / R, b = rad(brgDeg), p1 = rad(p[0]), l1 = rad(p[1]), p2 = Math.asin(Math.sin(p1) * Math.cos(d) + Math.cos(p1) * Math.sin(d) * Math.cos(b)); return [deg(p2), deg(l1 + Math.atan2(Math.sin(b) * Math.sin(d) * Math.cos(p1), Math.cos(d) - Math.sin(p1) * Math.sin(p2)))]; }
function projectPoint() {
  const from = last ? [last.lat, last.lon] : [map.getCenter().lat, map.getCenter().lng], b = el('input', { type: 'number', step: 'any', placeholder: S.set.angle === 'mils' ? 'mils' : 'degrees' }), d = el('input', { type: 'number', step: 'any', placeholder: 'metres' });
  modal('Point by bearing and distance', el('p', { class: 'mut' }, `From ${last ? 'your GPS position' : 'the map crosshair'}: ${fmtC(from[0], from[1])}`), el('label', {}, 'Bearing (' + (S.set.angle === 'mils' ? 'mils' : 'degrees from north') + ')'), b, el('label', {}, 'Distance (metres)'), d,
    el('div', { class: 'row act' }, el('button', { class: 'btn pri', onclick: () => { const bv = +b.value * (S.set.angle === 'mils' ? 360 / 6400 : 1), dv = +d.value; if (!(dv > 0) || !isFinite(bv)) return toast('Enter a bearing and a distance'); const p = destPoint(from, bv, dv); closeModal(); map.setView(p, Math.max(map.getZoom(), 16)); editFeature(addWpt(p[0], p[1], { name: `${fmtAng(bv)} / ${fmtD(dv)}` }), 'wpt'); } }, 'Place point'), el('button', { class: 'btn', onclick: closeModal }, 'Cancel')));
}
const _addWpt = addWpt;
addWpt = function (lat, lon, o = {}) { // dropped pins also get elevation (when online) and the layer's default symbol
  const d = (S.set.layerDefaults || {})[o.folder || ''] || {}; const w = _addWpt(lat, lon, { icon: d.icon, color: d.color, ...Object.fromEntries(Object.entries(o).filter(([, v]) => v != null)) });
  fetch(`https://api.open-meteo.com/v1/elevation?latitude=${lat.toFixed(5)}&longitude=${lon.toFixed(5)}`).then(r => r.json()).then(r => { if (r.elevation) { w.ele = r.elevation[0]; save.wpts(); } }).catch(() => { });
  return w;
};

// ---------- freehand drawing and "add at crosshair" while measuring ----------
let freehand = false;
const _measUpdate = measUpdate;
measUpdate = function () {
  _measUpdate(); const b = $('#measbar'); if (!meas.on) { setFreehand(false); return; }
  b.append(' ', el('button', { class: 'btn sm', onclick: () => { const c = map.getCenter(); meas.segs.push([[c.lat, c.lng]]); measUpdate(); } }, '+ Crosshair'), ' ',
    el('button', { class: 'btn sm' + (freehand ? ' pri' : ''), onclick: () => { setFreehand(!freehand); measUpdate(); toast(freehand ? 'Draw with one finger; the map is locked' : 'Freehand off'); } }, freehand ? 'Freehand: on' : 'Freehand'),
    ' ', last ? el('button', { class: 'btn sm', onclick: () => { meas.segs.push([[last.lat, last.lon]]); measUpdate(); } }, '+ GPS') : '');
  const row = el('div', { class: 'mrow' }); b.querySelectorAll('button').forEach(x => row.append(x)); b.querySelectorAll('br').forEach(x => x.remove()); b.append(row);
};
function setFreehand(on) {
  freehand = on; const c = map.getContainer();
  if (on) { map.dragging.disable(); c.addEventListener('pointerdown', fhDown); } else { map.dragging.enable(); c.removeEventListener('pointerdown', fhDown); }
}
function fhDown(e) {
  if (e.target.closest('.leaflet-marker-icon, .pill, .rail')) return; e.preventDefault(); const seg = [], c = map.getContainer(), r = c.getBoundingClientRect(); let lastP = null;
  const mv = ev => { const p = L.point(ev.clientX - r.left, ev.clientY - r.top); if (lastP && p.distanceTo(lastP) < 6) return; lastP = p; const ll = map.containerPointToLatLng(p); seg.push([ll.lat, ll.lng]); meas.segs.push([[ll.lat, ll.lng]]); _measUpdate(); };
  const up = () => { c.removeEventListener('pointermove', mv); removeEventListener('pointerup', up); measUpdate(); };
  mv(e); c.addEventListener('pointermove', mv); addEventListener('pointerup', up);
}

// ---------- web map layers (XYZ / WMS), hillshade, map footprints, downloaded areas, fire hotspots ----------
const gCustom = L.layerGroup().addTo(map), gFoot = L.layerGroup().addTo(map), gOff = L.layerGroup(), gFire = L.layerGroup();
function drawCustom() {
  gCustom.clearLayers();
  if (S.set.hillshade) L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/Elevation/World_Hillshade/MapServer/tile/{z}/{y}/{x}', { pane: 'maps', opacity: .45, maxNativeZoom: 16, maxZoom: 22, crossOrigin: true }).addTo(gCustom);
  for (const c of S.custom) if (c.on) (c.type === 'wms' ? L.tileLayer.wms(c.url, { layers: c.layers, format: 'image/png', transparent: true, pane: 'maps', opacity: c.opacity, crossOrigin: true }) : L.tileLayer(c.url, { pane: 'maps', opacity: c.opacity, maxZoom: 22, crossOrigin: true })).addTo(gCustom);
}
function drawFoot() {
  gFoot.clearLayers(); if (!S.set.footprints) return;
  for (const o of S.overlays) if (o.hidden) {
    const c = o.type === 'tiles' ? (() => { const b = L.latLngBounds(o.bounds); return [b.getNorthWest(), b.getNorthEast(), b.getSouthEast(), b.getSouthWest()]; })() : [o.corners[0], o.corners[1], brOf(o.corners), o.corners[2]];
    L.polygon(c, { color: '#8C6239', weight: 1.5, dashArray: '6 5', fill: true, fillOpacity: .02 }).bindTooltip(o.name, { direction: 'center', className: 'foot' }).on('click', () => { showMap(o); save.overlays(); drawOverlays(); map.fitBounds(ovBounds(o)); }).addTo(gFoot);
  }
}
function drawOff() { gOff.clearLayers(); S.offAreas.forEach(a => L.rectangle(a.b, { color: '#2F6B40', weight: 1.5, dashArray: '3 5', fillOpacity: .04, interactive: false }).addTo(gOff)); }
const _drawOverlays = drawOverlays;
drawOverlays = function () { _drawOverlays(); drawFoot(); };
const _downloadTiles = downloadTiles;
downloadTiles = async function (list, bar, label) { const b = map.getBounds(); await _downloadTiles(list, bar, label); S.offAreas.push({ b: [[b.getSouth(), b.getWest()], [b.getNorth(), b.getEast()]], t: Date.now(), base: S.set.base }); saveX.offAreas(); drawOff(); };
const _newImageMap = newImageMap;
newImageMap = async function (p) {
  const o = await _newImageMap(p);
  if (S.set.autoBase && S.set.base !== 'none') { const b = ovBounds(o); let z1 = 16, list; while ((list = tileList(b, 12, z1, S.set.base)).length > 3000 && z1 > 12) z1--; downloadTiles(list, el('i'), el('span')); toast(`Saving the base map under this map for offline use (${list.length} tiles)…`, 5000); }
  return o;
};
async function loadFires() {
  gFire.clearLayers(); if (!S.set.fires) return;
  try {
    const r0 = await fetch(apiBase() + 'api/fires'); if (!r0.ok) throw Error(r0.status); const txt = await r0.text(), ctr = map.getCenter();
    const rows = txt.trim().split('\n'), h = rows.shift().split(','), I = k => h.indexOf(k), now = Date.now(); let n = 0;
    for (const r of rows) { const c = r.split(','), la = +c[I('latitude')], lo = +c[I('longitude')]; if (!isFinite(la) || hav([ctr.lat, ctr.lng], [la, lo]) > 400000) continue; const tm = Date.parse(`${c[I('acq_date')]}T${String(c[I('acq_time')]).padStart(4, '0').replace(/(\d\d)(\d\d)/, '$1:$2')}:00Z`), age = (now - tm) / 36e5;
      L.circleMarker([la, lo], { radius: 6, color: '#fff', weight: 1, fillColor: age < 12 ? '#D7191C' : age < 24 ? '#FF7F00' : '#FDB863', fillOpacity: .9 })
        .bindPopup(() => el('div', {}, el('b', {}, 'Fire hotspot (NASA VIIRS)'), el('div', { class: 'mut' }, `${new Date(tm).toLocaleString('en-GB')} (${Math.round(age)} h ago), FRP ${c[I('frp')]} MW`), last ? el('div', { class: 'mut' }, fmtD(hav([last.lat, last.lon], [la, lo])) + ' from you') : '', el('button', { class: 'btn sm', onclick: () => { map.closePopup(); editFeature(addWpt(la, lo, { name: 'Hotspot ' + new Date(tm).toLocaleDateString('en-GB'), icon: '⚠️', color: '#C2185B', folder: 'Fire hotspots' }), 'wpt'); } }, 'Save as point'))).addTo(gFire); n++; }
    toast(`${n} fire hotspots within 400 km in the last 48 hours`);
  } catch (e) { toast('Fire hotspots need internet and the Trail Atlas server (NASA FIRMS)'); }
}

// ---------- track playback & vertical video ----------
let play = null;
function playTrack(t) {
  stopPlay(); const P = t.pts, t0 = P[0][3], dur = P[P.length - 1][3] - t0; if (!dur) return toast('This track has no times to play back');
  const mk = L.circleMarker([P[0][0], P[0][1]], { radius: 9, color: '#fff', weight: 3, fillColor: '#FF5B1A', fillOpacity: 1 }).addTo(map), photoPts = S.wpts.filter(w => (w.photos || []).length && P.some(p => hav(p, [w.lat, w.lon]) < 25));
  play = { mk, i: 0, speed: Math.max(10, Math.round(dur / 60000)), t: t0, paused: false, seen: new Set() };
  map.fitBounds(L.latLngBounds(feat(t)).pad(.2)); setTab('map');
  const bar = $('#navbar'); bar.hidden = false;
  const tick = () => {
    if (!play) return; if (!play.paused) play.t += 100 * play.speed;
    while (play.i < P.length - 1 && P[play.i + 1][3] <= play.t) play.i++;
    const p = P[play.i]; mk.setLatLng([p[0], p[1]]); map.panTo([p[0], p[1]], { animate: false });
    const d = pathLen(P.slice(0, play.i + 1)), w = photoPts.find(w => !play.seen.has(w.id) && hav(p, [w.lat, w.lon]) < 25);
    if (w) { play.seen.add(w.id); play.paused = true; photoURL(w.photos[0]).then(u => { bar.append(el('img', { src: u, style: 'width:100%;max-width:260px;border-radius:10px;margin-top:6px', alt: '' })); }); setTimeout(() => { if (play) play.paused = false; }, 2500); }
    let sp = 0; if (play.i > 0) { const a = P[Math.max(0, play.i - 3)]; const dt = (p[3] - a[3]) / 1000; sp = dt > 0 ? pathLen(P.slice(Math.max(0, play.i - 3), play.i + 1)) / dt * 3.6 : 0; }
    if (!w) bar.replaceChildren(el('div', { class: 'navtop' }, el('div', {}, el('b', {}, fmtT(play.t - t0)), el('div', { class: 'mut' }, `${t.name}: ${fmtD(d)}, ${fmtV(sp)}` + (p[2] != null ? `, alt ${fmtD(p[2])}` : '') + `, ×${play.speed}`))),
      el('div', { class: 'row', style: 'margin:4px 0 0' }, el('button', { class: 'btn sm', onclick: () => { play.paused = !play.paused; } }, play.paused ? 'Resume' : 'Pause'), el('button', { class: 'btn sm', onclick: () => { play.speed = play.speed >= 400 ? 10 : play.speed * 2; } }, 'Speed ×2'), el('button', { class: 'btn sm dng', onclick: stopPlay }, 'Stop')));
    if (play.i >= P.length - 1) { toast('Playback finished'); return stopPlay(); }
    play.h = setTimeout(tick, 100);
  };
  tick();
}
function stopPlay() { if (!play) return; clearTimeout(play.h); map.removeLayer(play.mk); play = null; $('#navbar').hidden = !nav.t; if (nav.t) navUpdate(); }
async function trackVideo(t) {
  if (!window.MediaRecorder) return toast('This browser cannot record video');
  toast('Making the video… keep the app open', 15000);
  const snap = await withView(L.latLngBounds(feat(t)), () => snapshotMap(t, 1), 1000, 1000);
  const W = 1080, H = 1920, cv = el('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d'), P = t.pts, k = 1000 / snap.cv.width;
  const toPx = ll => { const c = snap.corners, [u, v] = toUV(c, ll); return [40 + u * 1000, 380 + v * 1000]; }, total = pathLen(P), frames = 30 * 12;
  const mime = ['video/mp4;codecs=avc1', 'video/webm;codecs=vp9', 'video/webm'].find(m => MediaRecorder.isTypeSupported(m)) || '', recr = new MediaRecorder(cv.captureStream(30), mime ? { mimeType: mime, videoBitsPerSecond: 6e6 } : {}), chunks = [];
  recr.ondataavailable = e => e.data.size && chunks.push(e.data); const done = new Promise(r => recr.onstop = r); recr.start();
  const ele = series(t, 'ele');
  for (let f = 0; f <= frames; f++) {
    const n = Math.max(1, Math.round(f / frames * (P.length - 1))), d = pathLen(P.slice(0, n + 1));
    g.fillStyle = '#15241C'; g.fillRect(0, 0, W, H); g.fillStyle = '#FF5B1A'; g.fillRect(0, 300, W, 8);
    g.fillStyle = '#F1F5EF'; g.font = '700 64px Archivo, sans-serif'; g.fillText(t.name.slice(0, 26), 40, 130); g.font = '500 36px Archivo, sans-serif'; g.fillStyle = 'rgba(241,245,239,.75)'; g.fillText(new Date(t.created || Date.now()).toLocaleDateString('en-GB') + (t.activity ? ' · ' + t.activity : ''), 40, 200);
    g.drawImage(snap.cv, 40, 380, 1000, 1000 * snap.cv.height / snap.cv.width);
    g.beginPath(); P.slice(0, n + 1).forEach((p, i) => { const [x, y] = toPx(p); i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.strokeStyle = '#fff'; g.lineWidth = 14; g.lineCap = g.lineJoin = 'round'; g.stroke(); g.strokeStyle = '#FF5B1A'; g.lineWidth = 8; g.stroke();
    const [cx, cy] = toPx(P[n]); g.beginPath(); g.arc(cx, cy, 16, 0, 7); g.fillStyle = '#FF5B1A'; g.fill(); g.lineWidth = 5; g.strokeStyle = '#fff'; g.stroke();
    g.fillStyle = '#F1F5EF'; g.font = '700 84px Archivo, sans-serif'; g.fillText(fmtD(d), 40, 1520); g.font = '500 34px Archivo, sans-serif'; g.fillStyle = 'rgba(241,245,239,.75)'; g.fillText('of ' + fmtD(total) + (P[n][3] && P[0][3] ? '  ·  ' + fmtT(P[n][3] - P[0][3]) : ''), 40, 1575);
    if (ele.length > 1) { const vs = ele.map(e => e[1]), mn = Math.min(...vs), mx = Math.max(...vs), D = ele[ele.length - 1][0] || 1; g.beginPath(); ele.forEach(([dd, v], i) => { const x = 40 + dd / D * 1000, y = 1840 - (v - mn) / Math.max(mx - mn, 1) * 180; i ? g.lineTo(x, y) : g.moveTo(x, y); }); g.strokeStyle = 'rgba(241,245,239,.4)'; g.lineWidth = 4; g.stroke(); g.fillStyle = '#FF5B1A'; g.fillRect(40 + Math.min(d, D) / D * 1000 - 3, 1640, 6, 210); }
    g.font = '500 26px Archivo, sans-serif'; g.fillStyle = 'rgba(241,245,239,.5)'; g.fillText('Trail Atlas', W - 200, H - 30);
    await new Promise(r => setTimeout(r, 1000 / 30));
  }
  recr.stop(); await done; const type = (recr.mimeType || 'video/webm').split(';')[0];
  await shareFile(fname(t.name) + (type.includes('mp4') ? '.mp4' : '.webm'), new Blob(chunks, { type }), type);
}

// ---------- colour tracks by speed ----------
const _drawTracks = drawTracks;
drawTracks = function () {
  _drawTracks(); if (!S.set.speedColour) return;
  for (const t of S.tracks) {
    if (t.hidden || (t.kind && t.kind !== 'track') || !t.pts[0][3]) continue; const sp = series(t, 'speed'); if (sp.length < 2) continue;
    const vs = sp.map(x => x[1]).sort((a, b) => a - b), lo = vs[Math.floor(vs.length * .05)], hi = vs[Math.floor(vs.length * .95)] || lo + 1;
    for (let i = 1; i < t.pts.length && i < sp.length; i++) { const u = Math.max(0, Math.min(1, (sp[i][1] - lo) / (hi - lo || 1))); L.polyline([[t.pts[i - 1][0], t.pts[i - 1][1]], [t.pts[i][0], t.pts[i][1]]], { color: `hsl(${120 - u * 120},85%,45%)`, weight: 6, interactive: false }).addTo(gTracks); }
  }
};

// ---------- recycle bin (30 days) & multi-select ----------
const _delFeature = delFeature;
delFeature = function (f, kind) {
  S.bin.push({ kind, item: f, at: Date.now() }); saveX.bin();
  if (kind === 'wpt') { S.wpts = S.wpts.filter(x => x !== f); save.wpts(); drawWpts(); } else { S.tracks = S.tracks.filter(x => x !== f); save.tracks(); drawTracks(); }
  S.geofences = S.geofences.filter(g => g.target !== f.id); saveX.geofences(); drawFences();
  if (nav.t === f) stopNav(); render(); toast('Moved to the recycle bin (kept 30 days)');
};
function purgeBin() { const old = S.bin.filter(b => Date.now() - b.at > 30 * 864e5); old.forEach(b => (b.item.photos || []).forEach(id => kvDel('ph:' + id))); if (old.length) { S.bin = S.bin.filter(b => !old.includes(b)); saveX.bin(); } }
function binUI() {
  const box = el('div'), draw = () => box.replaceChildren(...(S.bin.length ? [...S.bin].reverse().map(b => el('div', { class: 'item' }, el('div', { class: 't' }, b.item.name), el('div', { class: 'mut' }, `${b.kind === 'wpt' ? 'Waypoint' : 'Track / route / area'}, deleted ${new Date(b.at).toLocaleDateString('en-GB')}`),
    el('div', { class: 'row' }, el('button', { class: 'btn sm pri', onclick: () => { (b.kind === 'wpt' ? S.wpts : S.tracks).push(b.item); S.bin = S.bin.filter(x => x !== b); saveX.bin(); save.wpts(); save.tracks(); drawWpts(); drawTracks(); draw(); toast('Restored'); } }, 'Restore'),
      el('button', { class: 'btn sm dng', onclick: () => { (b.item.photos || []).forEach(id => kvDel('ph:' + id)); S.bin = S.bin.filter(x => x !== b); saveX.bin(); draw(); } }, 'Delete forever')))) : [el('p', { class: 'mut' }, 'The recycle bin is empty.')]));
  draw(); modal('Recycle bin', el('p', { class: 'mut' }, 'Deleted waypoints and tracks stay here for 30 days.'), box, el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: () => { closeModal(); render(); } }, 'Close')));
}
const sel = { tracks: null, wpts: null };
const _groupedList = groupedList;
groupedList = function (s, kind, items, row, posOf, onVis) {
  if (kind === 'maps') return _groupedList(s, kind, items, row, posOf, onVis);
  const set = sel[kind], bar = el('div', { class: 'row' });
  bar.append(el('button', { class: 'btn sm', onclick: () => { sel[kind] = set ? null : new Set(); render(); } }, set ? 'Cancel selection' : 'Select'));
  if (set) {
    const picked = () => items().filter(x => set.has(x.id)), isW = kind === 'wpts';
    bar.append(el('span', { class: 'mut' }, set.size + ' selected'),
      el('button', { class: 'btn sm', onclick: () => { const fo = prompt('Move to layer (folder) name:', ''); if (fo == null) return; picked().forEach(x => x.folder = fo.trim()); save.tracks(); save.wpts(); sel[kind] = null; render(); } }, 'Move to layer'),
      el('button', { class: 'btn sm', onclick: async () => { const p = picked(); await shareFile('selection.kmz', await toKMZ(isW ? [] : p, isW ? p : []), 'application/vnd.google-earth.kmz'); } }, 'Share KMZ'),
      el('button', { class: 'btn sm dng', onclick: () => { const p = picked(); if (!p.length || !confirm(`Move ${p.length} items to the recycle bin?`)) return; p.forEach(x => delFeature(x, isW ? 'wpt' : 'track')); sel[kind] = null; render(); } }, 'Delete'));
  }
  s.append(bar);
  _groupedList(s, kind, items, x => { const r = row(x); if (set) { const cb = el('input', { type: 'checkbox', checked: set.has(x.id), 'aria-label': 'Select ' + x.name }); cb.onclick = e => e.stopPropagation(); cb.onchange = () => { cb.checked ? set.add(x.id) : set.delete(x.id); render(); }; r.querySelector('.t').prepend(cb); } return r; }, posOf, onVis);
};

// ---------- photos: date/position stamp, place by capture time on a track ----------
async function exifInfo(file) { // {gps:[lat,lon]|null, time:ms|null}
  const out = { gps: await exifGPS(file), time: null };
  try {
    const b = new DataView(await file.slice(0, 262144).arrayBuffer()); let o = 2;
    while (o < b.byteLength - 10) { const mk = b.getUint16(o), len = b.getUint16(o + 2);
      if (mk === 0xFFE1 && b.getUint32(o + 4) === 0x45786966) { const t = o + 10, le = b.getUint16(t) === 0x4949, u16 = p => b.getUint16(p, le), u32 = p => b.getUint32(p, le), ifd = t + u32(t + 4); let ex = 0;
        for (let i = 0, n = u16(ifd); i < n; i++) { const e = ifd + 2 + i * 12; if (u16(e) === 0x8769) ex = t + u32(e + 8); }
        if (ex) for (let i = 0, n = u16(ex); i < n; i++) { const e = ex + 2 + i * 12; if (u16(e) === 0x9003) { const vo = t + u32(e + 8); let s = ''; for (let k = 0; k < 19; k++) s += String.fromCharCode(b.getUint8(vo + k)); const m = s.match(/(\d{4}):(\d\d):(\d\d) (\d\d):(\d\d):(\d\d)/); if (m) out.time = new Date(+m[1], m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime(); } }
        break; }
      if ((mk & 0xFF00) !== 0xFF00) break; o += 2 + len; }
  } catch (e) { }
  return out;
}
function trackPosAt(time) { let best = null; for (const t of S.tracks) { if (!t.pts[0][3] || time < t.pts[0][3] - 3e5 || time > t.pts[t.pts.length - 1][3] + 3e5) continue; for (const p of t.pts) { const d = Math.abs(p[3] - time); if (!best || d < best.d) best = { d, p }; } } return best && best.d < 3e5 ? [best.p[0], best.p[1]] : null; }
const _storePhoto = storePhoto;
storePhoto = async function (file, where) {
  if (!S.set.stamp) return _storePhoto(file);
  const info = await exifInfo(file), pos = info.gps || where || (last ? [last.lat, last.lon] : null), bm = await createImageBitmap(file), s = Math.min(1, 1600 / Math.max(bm.width, bm.height)), c = el('canvas');
  c.width = Math.round(bm.width * s); c.height = Math.round(bm.height * s); const g = c.getContext('2d'); g.drawImage(bm, 0, 0, c.width, c.height);
  const txt = [new Date(info.time || Date.now()).toLocaleString('en-GB'), pos ? fmtC(pos[0], pos[1]) : 'No position'], fs = Math.round(c.width / 34);
  g.fillStyle = 'rgba(0,0,0,.55)'; g.fillRect(0, c.height - fs * 3.2, c.width, fs * 3.2); g.fillStyle = '#fff'; g.font = `600 ${fs}px Archivo, sans-serif`; txt.forEach((t, i) => g.fillText(t, fs * .6, c.height - fs * (2.1 - i * 1.25)));
  const id = uid(); await kvSet('ph:' + id, await new Promise(r => c.toBlob(r, 'image/jpeg', .85))); return id;
};
photoWpt = async function (file) {
  const info = await exifInfo(file), onTrack = !info.gps && info.time ? trackPosAt(info.time) : null, c = map.getCenter();
  const pos = info.gps || onTrack || (last ? [last.lat, last.lon] : [c.lat, c.lng]);
  const w = addWpt(pos[0], pos[1], { name: 'Photo ' + new Date(info.time || Date.now()).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' }), icon: '📷', folder: 'Photos' });
  w.photos = [await storePhoto(file, pos)]; if (info.time) w.t = info.time; save.wpts(); drawWpts(); map.setView(pos, Math.max(map.getZoom(), 16));
  toast(info.gps ? 'Photo placed using its GPS tag' : onTrack ? 'Photo placed on your track by the time it was taken' : last ? 'Photo placed at your GPS position' : 'Photo placed at map centre (no GPS)'); editFeature(w, 'wpt');
};

// ---------- import by link or QR code ----------
async function importURL(u) {
  try { const r = await fetch(u); if (!r.ok) throw Error('HTTP ' + r.status); const b = await r.blob(), nm = decodeURIComponent((new URL(u).pathname.split('/').pop() || 'download').split('?')[0]) || 'download';
    const ext = /\.\w{2,7}$/.test(nm) ? '' : ({ 'application/pdf': '.pdf', 'application/vnd.google-earth.kmz': '.kmz', 'application/gpx+xml': '.gpx', 'image/tiff': '.tif' }[b.type] || '');
    await importFile(new File([b], nm + ext, { type: b.type })); closeModal();
  } catch (e) { toast('Could not download: ' + e.message + '. The server may not allow downloads from apps (CORS).', 7000); }
}
function importLinkUI() {
  const u = el('input', { type: 'text', placeholder: 'https://… (GeoPDF, KMZ, GPX, GeoTIFF, MBTiles…)' }), vid = el('video', { playsinline: '', muted: '', style: 'width:100%;border-radius:12px;display:none' });
  const scan = async () => {
    if (!('BarcodeDetector' in window)) return toast('QR scanning is not supported in this browser; paste the link instead');
    try { const st = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } }); vid.srcObject = st; vid.style.display = 'block'; await vid.play(); const bd = new BarcodeDetector({ formats: ['qr_code'] });
      const loop = async () => { if (!vid.srcObject) return; const r = await bd.detect(vid).catch(() => []); if (r[0]) { st.getTracks().forEach(t => t.stop()); vid.srcObject = null; vid.style.display = 'none'; u.value = r[0].rawValue; importURL(r[0].rawValue); } else requestAnimationFrame(loop); }; loop();
    } catch (e) { toast('Camera not available: ' + e.message); }
  };
  modal('Import from a link or QR code', u, el('div', { class: 'row' }, el('button', { class: 'btn pri', onclick: () => u.value.trim() && importURL(u.value.trim()) }, 'Download & import'), el('button', { class: 'btn', onclick: scan }, 'Scan QR code')), vid,
    el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: () => { if (vid.srcObject) vid.srcObject.getTracks().forEach(t => t.stop()); vid.srcObject = null; closeModal(); } }, 'Close')));
}

// ---------- weather (Open-Meteo, 9 days, with field alerts) ----------
async function weatherUI() {
  const c = map.getCenter(), box = el('div', {}, el('p', { class: 'mut' }, 'Loading forecast…'));
  modal('Weather at the crosshair', box, el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: closeModal }, 'Close')));
  let j; try { j = await (await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${c.lat.toFixed(3)}&longitude=${c.lng.toFixed(3)}&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,uv_index_max&timezone=auto&forecast_days=9`)).json(); localStorage.setItem('wx', JSON.stringify(j)); }
  catch (e) { j = JSON.parse(localStorage.getItem('wx') || 'null'); if (!j) return box.replaceChildren(el('p', { class: 'mut' }, 'Weather needs internet.')); box.append(el('p', { class: 'mut' }, 'Offline: showing the last saved forecast.')); }
  const W = { 0: 'Clear', 1: 'Mostly clear', 2: 'Partly cloudy', 3: 'Cloudy', 45: 'Fog', 48: 'Fog', 51: 'Drizzle', 53: 'Drizzle', 55: 'Drizzle', 61: 'Rain', 63: 'Rain', 65: 'Heavy rain', 80: 'Showers', 81: 'Showers', 82: 'Heavy showers', 95: 'Thunderstorm', 96: 'Thunderstorm, hail', 99: 'Thunderstorm, hail' }, d = j.daily;
  box.replaceChildren(...d.time.map((t, i) => {
    const al = []; if (d.temperature_2m_max[i] >= 35) al.push('Heat'); if (d.temperature_2m_min[i] <= 5) al.push('Cold'); if (d.precipitation_sum[i] >= 20) al.push('Heavy rain'); if (d.wind_speed_10m_max[i] >= 40) al.push('Strong wind'); if (d.uv_index_max[i] >= 8) al.push('Very high UV'); if (d.weather_code[i] >= 95) al.push('Thunderstorm');
    return el('div', { class: 'item' }, el('div', { class: 't' }, new Date(t).toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' }), el('span', { class: 'mut' }, W[d.weather_code[i]] || '')),
      el('div', { class: 'mut' }, `${Math.round(d.temperature_2m_min[i])}–${Math.round(d.temperature_2m_max[i])} °C, rain ${d.precipitation_sum[i]} mm, wind ${fmtV(d.wind_speed_10m_max[i])}, UV ${d.uv_index_max[i]}`),
      al.length ? el('div', { style: 'color:var(--danger);font-weight:650;font-size:14px' }, '⚠ ' + al.join(', ')) : '');
  }));
}

// ---------- settings, layers & tools in the panels ----------
const _viewMore = viewMore;
viewMore = function (s) {
  _viewMore(s);
  const pick = (k, opts, after) => { const x = el('select', { onchange: () => { S.set[k] = x.value; save.set(); after && after(); } }); opts.forEach(([v, n]) => x.append(el('option', { value: v }, n))); x.value = S.set[k]; return x; };
  const chk = (k, label, after) => { const c = el('input', { type: 'checkbox', checked: !!S.set[k] }); c.onchange = () => { S.set[k] = c.checked; save.set(); after && after(); }; return el('label', { class: 'mut', style: 'display:block;margin:6px 0' }, c, ' ' + label); };
  const cs = el('p', { class: 'mut' }, noCompass() ? 'Compass sensor: not found in this phone. Direction comes from GPS while you walk (works best outdoors, moving forward).' : compassSeen ? 'Compass sensor: working.' : 'Compass sensor: checking…');
  const tools = [['fWpt', 'Mark waypoint'], ['fMeas', 'Measure / draw'], ['fPhoto', 'Photo waypoint'], ['fCam', 'Camera compass'], ['fShare', 'Share']];
  const before = s.querySelector('p.mut:last-child');
  const sec = [el('h3', { style: 'margin-top:16px' }, 'Field tools'),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: projectPoint }, 'Point by bearing & distance'), el('button', { class: 'btn', onclick: weatherUI }, 'Weather (9 days)'), el('button', { class: 'btn', onclick: importLinkUI }, 'Import from link / QR'), el('button', { class: 'btn', onclick: binUI }, `Recycle bin (${S.bin.length})`),
      document.fullscreenEnabled ? el('button', { class: 'btn', onclick: () => document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen() }, 'Full screen') : ''),
    S.geofences.length ? [el('h3', { style: 'margin-top:16px' }, `Geofences (${S.geofences.length})`), ...S.geofences.map(g => el('div', { class: 'item' }, el('div', { class: 't' }, g.name), el('div', { class: 'mut' }, `Alert ${g.on === 'both' ? 'on enter and leave' : 'when I ' + g.on}` + (g.area ? '' : `, radius ${fmtD(g.radius)}`) + (g.inside == null ? '' : g.inside ? ', you are inside' : ', you are outside')), el('div', { class: 'row' }, el('button', { class: 'btn sm dng', onclick: () => { S.geofences = S.geofences.filter(x => x !== g); saveX.geofences(); drawFences(); render(); } }, 'Remove'))))] : '',
    el('h3', { style: 'margin-top:16px' }, 'Units & display'),
    cs, el('label', { class: 'mut' }, 'Units'), pick('units', [['metric', 'Metric (km, m, ha)'], ['imperial', 'Imperial (mi, ft, ac)'], ['nautical', 'Nautical (NM, kn)']], () => { onMove(); drawTracks(); }),
    el('label', { class: 'mut' }, 'Bearings'), pick('angle', [['deg', 'Degrees'], ['mils', 'Mils (6400)']]),
    el('label', { class: 'mut' }, 'My position marker'), pick('posStyle', [['wedge', 'Dot with heading wedge'], ['arrow', 'Dot with heading arrow'], ['dot', 'Dot only']], drawHeading),
    canRotate ? chk('freeRotate', 'Allow two-finger map rotation', () => { S.set.freeRotate ? map.touchRotate.enable() : (map.touchRotate.disable(), map.setBearing(0)); }) : '',
    chk('speedColour', 'Colour recorded tracks by speed', drawTracks), chk('footprints', 'Show outlines of my other maps', drawFoot),
    el('label', { class: 'mut' }, 'Buttons on the map'), ...tools.map(([id, n]) => { const c = el('input', { type: 'checkbox', checked: !S.set.hideTools.includes(id) }); c.onchange = () => { S.set.hideTools = c.checked ? S.set.hideTools.filter(x => x !== id) : [...S.set.hideTools, id]; save.set(); applyTools(); }; return el('label', { class: 'mut', style: 'display:block;margin:4px 0' }, c, ' ' + n); }),
    el('h3', { style: 'margin-top:16px' }, 'Recording & photos'),
    el('label', { class: 'mut' }, 'Record a point'), pick('recMode', [['dist', 'By distance (setting above)'], ['time', 'By time interval']]),
    el('div', { class: 'row' }, (() => { const i = el('input', { type: 'number', min: 1, max: 600, value: S.set.recSec, style: 'width:90px' }); i.onchange = () => { S.set.recSec = Math.max(1, +i.value || 5); save.set(); }; return i; })(), el('span', { class: 'mut' }, 'seconds between points (time mode)')),
    chk('stamp', 'Write date and coordinates onto new photos'), chk('autoBase', 'Save the base map for offline use when I import a map'),
    el('h3', { style: 'margin-top:16px' }, 'Layer defaults'),
    el('p', { class: 'mut' }, 'Choose a default colour for each layer. New points and lines in that layer start with that colour.'),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: layerDefaultsUI }, 'Default colour per layer')),
    el('h3', { style: 'margin-top:16px' }, 'Coordinate systems'),
    el('p', { class: 'mut' }, 'Malaysian RSO (GDM2000 / Kertau), Cassini state grids, UTM and Web Mercator are built in. For other systems, add the EPSG code with its proj4 or WKT text.'),
    (() => { const code = el('input', { type: 'number', placeholder: 'EPSG code', style: 'width:130px' }), def = el('input', { type: 'text', placeholder: '+proj=… or PROJCS[…]' }); return el('div', {}, el('div', { class: 'row', style: 'flex-wrap:nowrap' }, code, def), el('button', { class: 'btn sm', onclick: () => { if (!+code.value || !def.value.trim()) return; S.set.userProj = { ...(S.set.userProj || {}), [+code.value]: def.value.trim() }; EPSG[+code.value] = def.value.trim(); save.set(); toast('Coordinate system saved'); } }, 'Save system')); })()];
  sec.flat().forEach(x => x && s.insertBefore(x, before));
};
function layerDefaultsUI() {
  const box = el('div'); S.set.layerDefaults = S.set.layerDefaults || {};
  box.append(...(folders().length ? folders() : ['']).map(fo => { const d = S.set.layerDefaults[fo] || {}, co = el('select', { onchange: e => { S.set.layerDefaults[fo] = { ...S.set.layerDefaults[fo], color: e.target.value }; save.set(); } }, COLORS.map(c => el('option', { value: c }, c)));
    co.value = d.color || COLORS[0]; return el('div', { class: 'item' }, el('div', { class: 't' }, fo || 'No folder'), el('div', { class: 'row', style: 'flex-wrap:nowrap' }, co)); }));
  modal('Default symbol per layer', el('p', { class: 'mut' }, 'New waypoints in a layer get its symbol and colour.'), box, el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: closeModal }, 'Close')));
}
function applyTools() { ['fWpt', 'fMeas', 'fPhoto', 'fCam', 'fShare'].forEach(id => { const b = $('#' + id); if (b) b.hidden = S.set.hideTools.includes(id); }); }
const _viewLayers = viewLayers;
viewLayers = function (s) {
  _viewLayers(s);
  const chk = (k, label, after) => { const c = el('input', { type: 'checkbox', checked: !!S.set[k] }); c.onchange = () => { S.set[k] = c.checked; save.set(); after(); }; return el('label', { class: 'mut', style: 'display:block;margin:6px 0' }, c, ' ' + label); };
  const offChk = el('input', { type: 'checkbox', checked: map.hasLayer(gOff) }); offChk.onchange = () => { offChk.checked ? (drawOff(), gOff.addTo(map)) : map.removeLayer(gOff); };
  const name = el('input', { type: 'text', placeholder: 'Name' }), url = el('input', { type: 'text', placeholder: 'https://…/{z}/{x}/{y}.png  or a WMS address' }), lay = el('input', { type: 'text', placeholder: 'WMS layer name(s) (WMS only)' }), typ = el('select', {}, el('option', { value: 'xyz' }, 'XYZ tiles'), el('option', { value: 'wms' }, 'WMS'));
  const anchor = s.querySelector('h3:nth-of-type(3)') || null;
  [el('h3', { style: 'margin-top:16px' }, 'Overlays'),
    chk('hillshade', 'Hillshade relief (Esri)', drawCustom), chk('fires', 'Fire hotspots, last 48 h (NASA)', () => { S.set.fires ? (gFire.addTo(map), loadFires()) : map.removeLayer(gFire); }),
    el('label', { class: 'mut', style: 'display:block;margin:6px 0' }, offChk, ` Show areas saved for offline use (${S.offAreas.length})`),
    ...S.custom.map(c => { const cb = el('input', { type: 'checkbox', checked: !!c.on }), sl = el('input', { type: 'range', min: 10, max: 100, value: Math.round(c.opacity * 100) }); cb.onchange = () => { c.on = cb.checked; saveX.custom(); drawCustom(); }; sl.onchange = () => { c.opacity = sl.value / 100; saveX.custom(); drawCustom(); };
      return el('div', { class: 'item' }, el('label', { class: 't' }, cb, c.name), sl, el('div', { class: 'row' }, el('button', { class: 'btn sm dng', onclick: () => { S.custom = S.custom.filter(x => x !== c); saveX.custom(); drawCustom(); render(); } }, 'Remove'))); }),
    el('label', { class: 'mut' }, 'Add a web map layer (satellite, cadastral, drone orthophoto…)'), el('div', { class: 'row', style: 'flex-wrap:nowrap' }, name, typ), url, lay,
    el('button', { class: 'btn sm', onclick: () => { if (!url.value.trim()) return toast('Enter the layer address'); S.custom.push({ id: uid(), name: name.value.trim() || 'Web layer', url: url.value.trim(), type: typ.value, layers: lay.value.trim(), opacity: .8, on: true }); saveX.custom(); drawCustom(); render(); } }, '+ Add layer')
  ].forEach(x => anchor ? s.insertBefore(x, anchor) : s.append(x));
};
const _viewWpts = viewWpts;
viewWpts = function (s) { _viewWpts(s); const r = s.querySelector('.row'); r && r.append(el('button', { class: 'btn', onclick: projectPoint }, 'Point by bearing')); };
const _viewTracks = viewTracks;
viewTracks = function (s) {
  _viewTracks(s);
  s.querySelectorAll('.item').forEach(it => { const ti = it.querySelector('.t'), t = ti && S.tracks.find(x => x.name === ti.textContent.trim()); if (t && t.activity) it.querySelector('.mut').prepend(t.activity + ' — '); });
};

// ---------- start ----------
(async () => {
  for (const k of ['geofences', 'bin', 'custom', 'offAreas']) S[k] = await kvGet(k) || [];
  await new Promise(r => setTimeout(r, 300)); Object.assign(S.set, Object.assign({ units: 'metric', angle: 'deg', posStyle: 'wedge', recMode: 'dist', recSec: 5, hideTools: [], customIcons: [] }, S.set));
  (S.set.customIcons || []).forEach(i => ICONS[i] = 'Custom'); Object.entries(S.set.userProj || {}).forEach(([k, v]) => EPSG[k] = v);
  purgeBin(); drawFences(); drawCustom(); drawFoot(); applyTools(); onMove(); drawTracks();
  if (S.set.fires) { gFire.addTo(map); loadFires(); }
})();
Object.assign(window.__jejak, { parseAnyCoord, mgrsInv, destPoint, callPoints, playTrack, stopPlay, trackVideo, checkFences, inPoly, projFn, exifInfo, trackPosAt, openCockpit, weatherUI, importURL, setGpsMode, binUI, sel });

// ---------- newest free maps: Sentinel-2 latest & 2025, Esri Wayback history, NASA daily, fresh street maps ----------
Object.assign(BASES, {
  hot: { n: 'Streets, humanitarian style (OSM, updated daily)', u: 'https://a.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png', max: 19, att: '© OpenStreetMap, HOT' },
  cyclosm: { n: 'Paths & trails (CyclOSM)', u: 'https://a.tile-cyclosm.openstreetmap.fr/cyclosm/{z}/{x}/{y}.png', max: 19, att: '© OpenStreetMap, CyclOSM' },
  estreet: { n: 'Streets (Esri)', u: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}', max: 19, att: 'Esri' },
  s2new: { n: 'Satellite, newest clear Sentinel-2 (last 6 months)', u: '', max: 15, att: 'Copernicus Sentinel-2 via Microsoft Planetary Computer' },
  s2y: { n: 'Satellite, Sentinel-2 cloudless 2025 (EOX)', u: 'https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2025_3857/default/g/{z}/{y}/{x}.jpg', max: 15, att: 'Sentinel-2 cloudless 2025 by EOX (CC BY-NC-SA 4.0)' },
  wb: { n: 'Satellite history by date (Esri Wayback)', u: '', max: 19, att: 'Esri World Imagery Wayback' },
  gibs: { n: 'Satellite, yesterday (NASA, coarse, for haze/floods)', u: '', max: 9, att: 'NASA GIBS, VIIRS NOAA-20' }
});
const S2Q = from => ({ collections: ['sentinel-2-l2a'], 'filter-lang': 'cql2-json', filter: { op: 'and', args: [{ op: 'anyinteracts', args: [{ property: 'datetime' }, { interval: [from + 'T00:00:00Z', new Date().toISOString().slice(0, 10) + 'T23:59:59Z'] }] }, { op: '<=', args: [{ property: 'eo:cloud_cover' }, 50] }] }, sortby: [{ field: 'eo:cloud_cover', direction: 'asc' }] });
async function prepS2(refresh) { // register a cloud-sorted Sentinel-2 mosaic once and keep its id (keeps offline tiles valid)
  let c = JSON.parse(localStorage.getItem('s2sid') || 'null');
  if (!c || refresh) { const r = await (await fetch('https://planetarycomputer.microsoft.com/api/data/v1/mosaic/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(S2Q(new Date(Date.now() - 180 * 864e5).toISOString().slice(0, 10))) })).json(); c = { sid: r.id, t: Date.now() }; localStorage.setItem('s2sid', JSON.stringify(c)); }
  BASES.s2new.u = `https://planetarycomputer.microsoft.com/api/data/v1/mosaic/${c.sid}/tiles/WebMercatorQuad/{z}/{x}/{y}@1x?collection=sentinel-2-l2a&assets=visual&nodata=0&format=png`;
  return c;
}
let wayback = null;
async function prepWayback() {
  if (!wayback) { let c = JSON.parse(localStorage.getItem('wbcfg') || 'null'); if (!c || Date.now() - c.t > 7 * 864e5) { try { const j = await (await fetch('https://s3-us-west-2.amazonaws.com/config.maptiles.arcgis.com/waybackconfig.json')).json(); c = { t: Date.now(), j }; localStorage.setItem('wbcfg', JSON.stringify(c)); } catch (e) { if (!c) throw e; } }
    wayback = Object.entries(c.j).map(([k, v]) => ({ rel: k, date: (v.itemTitle.match(/\d{4}-\d\d-\d\d/) || [''])[0], url: v.itemURL, meta: v.metadataLayerUrl })).sort((a, b) => b.date.localeCompare(a.date)); }
  const w = wayback.find(x => x.rel === S.set.wbRel) || wayback[0]; BASES.wb.u = w.url.replace('{level}', '{z}').replace('{row}', '{y}').replace('{col}', '{x}'); BASES.wb.n = `Satellite on ${w.date} (Esri Wayback)`; return w;
}
function prepGibs() { const d = new Date(Date.now() - 864e5).toISOString().slice(0, 10); BASES.gibs.u = `https://gibs.earthdata.nasa.gov/wmts/epsg3857/best/VIIRS_NOAA20_CorrectedReflectance_TrueColor/default/${d}/GoogleMapsCompatible_Level9/{z}/{y}/{x}.jpg`; BASES.gibs.n = `Satellite on ${d} (NASA, coarse)`; }
const _setBase = setBase;
setBase = function (k) {
  const go = () => _setBase(k), fail = e => { toast('Could not load this map (needs internet the first time): ' + e.message, 6000); };
  if (k === 's2new') return prepS2().then(() => { go(); imageryDate(true); }).catch(fail);
  if (k === 'wb') return prepWayback().then(go).catch(fail);
  if (k === 'gibs') prepGibs();
  go();
};
async function imageryDate(quiet) { // when was the imagery under the crosshair taken?
  const c = map.getCenter(), b = S.set.base;
  try {
    if (b === 's2new') {
      const r = await (await fetch('https://planetarycomputer.microsoft.com/api/stac/v1/search', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ collections: ['sentinel-2-l2a'], intersects: { type: 'Point', coordinates: [c.lng, c.lat] }, datetime: new Date(Date.now() - 180 * 864e5).toISOString() + '/' + new Date().toISOString(), query: { 'eo:cloud_cover': { lte: 50 } }, sortby: [{ field: 'eo:cloud_cover', direction: 'asc' }], limit: 1 }) })).json();
      const f = r.features && r.features[0]; return toast(f ? `Sentinel-2 image here: ${new Date(f.properties.datetime).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}, ${Math.round(f.properties['eo:cloud_cover'])}% cloud, 10 m detail` : 'No clear Sentinel-2 image here in the last 6 months', 7000);
    }
    if (b === 's2y') return toast('Sentinel-2 cloudless: yearly mosaic of 2025, 10 m detail', 6000);
    if (b === 'gibs') return toast(BASES.gibs.n + ', about 375 m detail', 6000);
    if (['sat', 'hyb', 'wb'].includes(b)) {
      const w = b === 'wb' ? await prepWayback() : (await prepWayback(), wayback[0]);
      const r = await (await fetch(`${w.meta}/identify?geometry=${c.lng},${c.lat}&geometryType=esriGeometryPoint&sr=4326&layers=all&tolerance=0&mapExtent=${c.lng - .05},${c.lat - .05},${c.lng + .05},${c.lat + .05}&imageDisplay=800,800,96&returnGeometry=false&f=json`)).json();
      const a = (r.results || []).map(x => x.attributes).find(x => x.SRC_DATE2) || null;
      return toast(a ? `Esri image here: taken ${new Date(a.SRC_DATE2).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}, ${a.SRC_RES} m detail (${a.NICE_DESC || a.SRC_DESC}). Try "Satellite, newest clear Sentinel-2" for a more recent view.` : 'No date information for this spot', 9000);
    }
    if (!quiet) toast('Street maps are updated continuously; dates apply to satellite maps only', 5000);
  } catch (e) { toast('Imagery date needs internet'); }
}

// ---------- vector street map from your own server (OpenStreetMap data via Protomaps; no outside tile server, saving areas offline is allowed) ----------
async function probeOwnTiles() {
  const api = apiBase(), ck = JSON.parse(localStorage.getItem('taTiles') || 'null'), fresh = ck && ck.api === api && Date.now() - ck.t < 6 * 36e5; // remember the answer for 6 h so servers without tiles are not asked on every start
  if (fresh && !ck.ok) return;
  try {
    if (!fresh) { const r = await fetch(api + 'api/tiles/0/0/0.mvt', { cache: 'no-store' }); localStorage.setItem('taTiles', JSON.stringify({ t: Date.now(), ok: r.status === 200, api })); if (r.status !== 200) return; }
    const u = api + 'api/tiles/{z}/{x}/{y}.mvt', att = '© OpenStreetMap contributors, Protomaps';
    BASES.pm = { n: 'Streets, own server (vector)', u, max: 15, vec: true, flavor: 'light', att }; BASES.pmd = { n: 'Night streets, own server (vector)', u, max: 15, vec: true, flavor: 'dark', att };
    NIGHT.pm = 'pmd'; NIGHT.pmd = 'pmd'; if (S.set.base === 'pm' || S.set.base === 'pmd') setBase(S.set.base, { persist: false });
  } catch (err) { }
}
setTimeout(probeOwnTiles, 1500);

// ---------- server address: lets the app live on a free static host while backups and fire data stay on your own server ----------
function apiBase() { const v = (localStorage.getItem('taApi') || '').trim(); return /^(https:\/\/|http:\/\/(localhost|127\.0\.0\.1)[:\/])/.test(v) ? v.replace(/\/*$/, '/') : ''; } // http only for local testing

// ---------- your own base maps: providers that give a free key (MapTiler, Thunderforest, Stadia) or any XYZ address ----------
const PROVIDERS = {
  maptiler: { n: 'MapTiler Outdoor', u: k => `https://api.maptiler.com/maps/outdoor-v2/256/{z}/{x}/{y}.png?key=${k}`, att: '© MapTiler © OpenStreetMap contributors', link: 'cloud.maptiler.com' },
  thunderforest: { n: 'Thunderforest Outdoors', u: k => `https://tile.thunderforest.com/outdoors/{z}/{x}/{y}.png?apikey=${k}`, att: '© Thunderforest © OpenStreetMap contributors', link: 'thunderforest.com' },
  stadia: { n: 'Stadia Alidade Smooth', u: k => `https://tiles.stadiamaps.com/tiles/alidade_smooth/{z}/{x}/{y}.png?api_key=${k}`, att: '© Stadia Maps © OpenMapTiles © OpenStreetMap contributors', link: 'stadiamaps.com' },
  custom: { n: 'Other (paste an XYZ address)' }
};
function userBaseUI() {
  const wrap = el('div', { style: 'margin-top:14px' }), sel = el('select');
  for (const k in PROVIDERS) sel.append(el('option', { value: k }, PROVIDERS[k].n));
  const key = el('input', { type: 'text', placeholder: 'Your free key from the provider' }), url = el('input', { type: 'text', placeholder: 'https://…/{z}/{x}/{y}.png', hidden: '' }), hint = el('p', { class: 'mut' });
  const sync = () => { const c = sel.value === 'custom'; url.hidden = !c; key.hidden = c; hint.textContent = (c ? 'Use a tile server you are allowed to use.' : `Get a free key at ${PROVIDERS[sel.value].link} and paste it here. The key stays on this phone and in your own backup.`) + ' Check the provider\'s terms before saving areas offline.'; };
  sel.onchange = sync; sync();
  const rows = (S.set.userBases || []).map(b => el('div', { class: 'row', style: 'align-items:center' }, el('span', { style: 'flex:1' }, b.n), el('button', { class: 'btn sm', onclick: () => { S.set.userBases = S.set.userBases.filter(x => x.id !== b.id); delete BASES[b.id]; if (S.set.base === b.id) setBase('osm'); save.set(); render(); } }, 'Remove')));
  const add = el('button', { class: 'btn sm', onclick: () => {
    let u, n, att = ''; const p = PROVIDERS[sel.value];
    if (sel.value === 'custom') { u = url.value.trim(); n = 'My map'; if (!/^https:\/\/\S+\{z\}\S*\{x\}\S*\{y\}/.test(u)) return toast('The address must start with https:// and contain {z}, {x} and {y}'); }
    else { const k = key.value.trim(); if (!/^[A-Za-z0-9_-]{8,80}$/.test(k)) return toast('Paste the key exactly as the provider shows it'); u = p.u(k); n = p.n; att = p.att; }
    const id = 'u' + uid(), b = { id, n, u, max: 19, att }; (S.set.userBases = S.set.userBases || []).push(b); BASES[id] = b; save.set(); setBase(id); render(); toast(n + ' added');
  } }, 'Add base map');
  wrap.append(el('label', { class: 'mut' }, 'Add your own base map (free key from a provider that allows it)'), sel, key, url, hint, add, ...rows);
  return wrap;
}
const _viewLayers2 = viewLayers;
viewLayers = function (s) {
  _viewLayers2(s);
  const sel = s.querySelector('select'); if (!sel) return;
  const order = [['Street maps', ['pm', 'osm', 'hot', 'estreet', 'cyclosm']], ['Topographic', ['topo', 'etopo']], ['Night maps', ['pmd', 'dgray']], ['My base maps', (S.set.userBases || []).map(b => b.id)], ['Satellite', ['s2new', 's2y', 'sat', 'hyb', 'wb', 'gibs']], ['Other', ['none']]];
  sel.replaceChildren(...order.map(([g, ks]) => el('optgroup', { label: g }, ks.filter(k => BASES[k]).map(k => el('option', { value: k }, BASES[k].n))))); sel.value = S.set.base;
  const extra = el('div'); extra.append(userBaseUI());
  extra.append(el('div', { class: 'row' }, el('button', { class: 'btn sm', onclick: () => imageryDate() }, 'When was this image taken?'),
    S.set.base === 's2new' ? el('button', { class: 'btn sm', onclick: async () => { await prepS2(true); setBase('s2new'); toast('Fetching the newest Sentinel-2 images…'); } }, 'Refresh newest') : ''),
    el('p', { class: 'mut' }, (BASES[S.set.base] && BASES[S.set.base].att ? 'Source: ' + BASES[S.set.base].att : '') + (S.set.nightMap !== false && isDarkTheme() && NIGHT[S.set.base] && NIGHT[S.set.base] !== S.set.base ? ' · night version shown while the app is dark' : '')));
  if (S.set.base === 'wb') prepWayback().then(w => { const ws = el('select', { onchange: () => { S.set.wbRel = ws.value; save.set(); setBase('wb'); render(); } }); wayback.forEach(x => ws.append(el('option', { value: x.rel }, x.date + (x === wayback[0] ? ' (newest)' : '')))); ws.value = w.rel; extra.prepend(el('label', { class: 'mut' }, 'Image date (compare before and after)'), ws); }).catch(() => { });
  sel.after(extra);
};

// ---------- live camera compass (camera view + compass tape + your points, photo with stamp, sight a bearing) ----------
const cam = { on: false, hd: null, pitch: 0, stream: null, raf: 0, fov: 60 };
function camHeading(e) { // heading of the rear camera from the device orientation (works with the phone held upright)
  if (e.webkitCompassHeading != null) return { h: (e.webkitCompassHeading + 360) % 360, p: (e.beta || 0) - 90 };
  if (e.alpha == null || !(e.absolute || e.type === 'deviceorientationabsolute')) return null;
  const a = rad(e.alpha), b = rad(e.beta || 0), g = rad(e.gamma || 0), ca = Math.cos(a), sa = Math.sin(a), cb = Math.cos(b), sb = Math.sin(b), cg = Math.cos(g), sg = Math.sin(g);
  const vx = -ca * sg - sa * sb * cg, vy = -sa * sg + ca * sb * cg, vz = -cb * cg;
  return { h: (deg(Math.atan2(vx, vy)) + 360) % 360, p: deg(Math.asin(Math.max(-1, Math.min(1, vz)))) };
}
function onCamOri(e) {
  const r = camHeading(e); if (!r) return; cam.gotSensor = true;
  if (cam.hd == null) cam.hd = r.h; else { const d = ((r.h - cam.hd + 540) % 360) - 180; cam.hd = (cam.hd + d * .25 + 360) % 360; }
  cam.pitch = cam.pitch * .7 + r.p * .3;
}
async function openCamCompass() {
  const box = el('div', { id: 'camview' }), vid = el('video', { playsinline: '', muted: '', autoplay: '' }), cv = el('canvas', { class: 'camhud' });
  const info = el('div', { class: 'caminfo' }), top = el('div', { class: 'camtop' }), close = el('button', { class: 'cambtn', 'aria-label': 'Close camera compass', onclick: closeCamCompass }, '✕');
  const shot = el('button', { class: 'shutter', 'aria-label': 'Take photo with compass' }), sight = el('button', { class: 'btn sm cam2', onclick: sightBearing }, 'Sight bearing');
  box.append(vid, cv, top, el('div', { id: 'camsub', class: 'camsub' }), close, info, el('div', { class: 'cambar' }, sight, shot, el('button', { class: 'btn sm cam2', onclick: () => { cam.fov = cam.fov === 60 ? 45 : cam.fov === 45 ? 75 : 60; toast('Field of view ' + cam.fov + '°'); } }, 'Zoom view')));
  document.body.append(box); cam.on = true; cam.hd = null; cam.gotSensor = false; cam.t0 = Date.now(); startGPS();
  const go = () => { addEventListener('deviceorientationabsolute', onCamOri); addEventListener('deviceorientation', onCamOri); };
  go(); if (typeof DeviceOrientationEvent !== 'undefined' && DeviceOrientationEvent.requestPermission) DeviceOrientationEvent.requestPermission().then(go).catch(() => { });
  try { cam.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } }, audio: false }); vid.srcObject = cam.stream; vid.play().catch(() => { }); }
  catch (e) { info.textContent = 'Camera not available (' + e.name + '). Allow camera access for this site.'; }
  shot.onclick = () => camPhoto(vid, cv);
  const loop = () => { if (!cam.on) return; if (!cam.gotSensor && Date.now() - cam.t0 > 2500 && derived) cam.hd = derived.h; drawCamHud(cv, top, info); cam.raf = requestAnimationFrame(loop); }; loop();
}
function closeCamCompass() {
  cam.on = false; cancelAnimationFrame(cam.raf); if (cam.stream) cam.stream.getTracks().forEach(t => t.stop()); cam.stream = null;
  removeEventListener('deviceorientationabsolute', onCamOri); removeEventListener('deviceorientation', onCamOri); const v = $('#camview'); v && v.remove();
}
function camTargets() { // your waypoints within 20 km, plus the navigation target
  if (!last) return []; const me_ = [last.lat, last.lon], list = S.wpts.filter(w => !w.hidden).map(w => ({ name: w.name, color: w.color, b: brg(me_, [w.lat, w.lon]), d: hav(me_, [w.lat, w.lon]) })).filter(x => x.d < 20000 && x.d > 2);
  if (nav.t) list.push({ name: nav.t.name, color: '#FF5B1A', b: brg(me_, [nav.t.lat, nav.t.lon]), d: hav(me_, [nav.t.lat, nav.t.lon]), target: true });
  return list.sort((a, b) => b.d - a.d).slice(-25);
}
function drawCamHud(cv, top, info, forPhoto) {
  const W = cv.clientWidth || cv.width, H = cv.clientHeight || cv.height, dpr = forPhoto ? 1 : (devicePixelRatio || 1);
  if (!forPhoto && (cv.width !== W * dpr || cv.height !== H * dpr)) { cv.width = W * dpr; cv.height = H * dpr; }
  const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
  const hd = cam.hd, ppd = W / cam.fov, cx = W / 2, ty = 70;
  g.fillStyle = 'rgba(10,18,13,.55)'; g.fillRect(0, 0, W, ty + 34);
  if (hd != null) {
    g.strokeStyle = '#fff'; g.fillStyle = '#fff'; g.textAlign = 'center'; g.lineWidth = 1.5;
    for (let d = Math.floor((hd - cam.fov / 2 - 5) / 5) * 5; d <= hd + cam.fov / 2 + 5; d += 5) {
      const x = cx + (d - hd) * ppd, dd = (d + 360) % 360, major = dd % 15 === 0; g.globalAlpha = major ? 1 : .6;
      g.beginPath(); g.moveTo(x, ty + 30); g.lineTo(x, ty + (major ? 12 : 20)); g.stroke();
      if (major) { const c = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SW', 270: 'W', 315: 'NW' }[dd]; g.font = c ? '700 17px Archivo, sans-serif' : '500 13px Archivo, sans-serif'; g.fillStyle = c === 'N' ? '#FF5B1A' : '#fff'; g.fillText(c || String(dd), x, ty + 6); g.fillStyle = '#fff'; }
    }
    g.globalAlpha = 1; g.fillStyle = '#FF5B1A'; g.beginPath(); g.moveTo(cx, ty + 34); g.lineTo(cx - 8, ty + 46); g.lineTo(cx + 8, ty + 46); g.closePath(); g.fill();
    for (const t of camTargets()) { // points in view as markers; the nav target gets an edge arrow when out of view
      let off = ((t.b - hd + 540) % 360) - 180, x = cx + off * ppd; const inView = Math.abs(off) <= cam.fov / 2;
      if (!inView && !t.target) continue; if (!inView) x = off < 0 ? 26 : W - 26;
      const y = H * .42 - Math.min(140, 6000 / Math.max(t.d, 50));
      g.fillStyle = t.color; g.strokeStyle = '#fff'; g.lineWidth = 2.5; g.beginPath(); g.arc(x, y, t.target ? 11 : 8, 0, 7); g.fill(); g.stroke();
      g.font = '650 13px Archivo, sans-serif'; g.textAlign = inView ? 'center' : off < 0 ? 'left' : 'right'; g.lineWidth = 4; g.strokeStyle = 'rgba(0,0,0,.6)';
      const lab = (inView ? '' : off < 0 ? '◀ ' : '') + t.name + ' · ' + fmtD(t.d) + (inView ? '' : off > 0 ? ' ▶' : ''); g.strokeText(lab, inView ? x : x + (off < 0 ? 14 : -14), y - 16); g.fillStyle = '#fff'; g.fillText(lab, inView ? x : x + (off < 0 ? 14 : -14), y - 16);
    }
  }
  g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = 2; const cy = H * .5; g.beginPath(); g.arc(cx, cy, 22, 0, 7); g.moveTo(cx - 40, cy); g.lineTo(cx - 26, cy); g.moveTo(cx + 26, cy); g.lineTo(cx + 40, cy); g.moveTo(cx, cy - 40); g.lineTo(cx, cy - 26); g.moveTo(cx, cy + 26); g.lineTo(cx, cy + 40); g.stroke();
  const gpsMode_ = !cam.gotSensor && Date.now() - (cam.t0 || 0) > 2500, ago = derived ? Math.round((Date.now() - derived.t) / 1000) : null;
  const txt = hd == null ? (gpsMode_ ? 'No compass in this phone' : 'Turn the phone in a figure 8 to wake the compass') : `${fmtAng(hd)} ${card(hd)}`;
  if (top) { top.textContent = txt; const sub = $('#camsub'); if (sub) sub.textContent = !gpsMode_ ? '' : hd == null ? 'Walk forward about 10 m with the phone pointing ahead. The direction comes from GPS.' : `From GPS: your walking direction${ago > 20 ? ' (' + ago + ' s ago)' : ''}. Updates only while you walk forward.`; }
  const lines = [last ? fmtC(last.lat, last.lon) : 'Waiting for GPS…', [last && last.ele != null ? 'Alt ' + fmtD(last.ele) : '', last ? '±' + Math.round(last.acc) + ' m' : '', hd != null ? 'Tilt ' + Math.round(cam.pitch) + '°' : ''].filter(Boolean).join('   '), new Date().toLocaleString('en-GB')];
  if (info && !forPhoto) info.replaceChildren(...lines.map((l, i) => el(i ? 'div' : 'b', {}, l)));
  return { txt, lines };
}
async function camPhoto(vid, hud) {
  if (!vid.videoWidth) return toast('Camera is not ready');
  const W = vid.videoWidth, H = vid.videoHeight, c = el('canvas'); c.width = W; c.height = H; const g = c.getContext('2d'); g.drawImage(vid, 0, 0, W, H);
  const o = el('canvas'); o.width = W; o.height = H; Object.defineProperty(o, 'clientWidth', { value: W }); Object.defineProperty(o, 'clientHeight', { value: H }); const h = drawCamHud(o, null, null, true); g.drawImage(o, 0, 0);
  const fs = Math.round(W / 34); g.fillStyle = 'rgba(10,18,13,.62)'; g.fillRect(0, H - fs * 5.2, W, fs * 5.2); g.fillStyle = '#fff'; g.textAlign = 'left';
  g.font = `700 ${Math.round(fs * 1.25)}px Archivo, sans-serif`; g.fillText(h.txt, fs * .7, H - fs * 3.7);
  g.font = `500 ${fs}px Archivo, sans-serif`; h.lines.forEach((l, i) => g.fillText(l, fs * .7, H - fs * (2.45 - i * 1.05)));
  const s = Math.min(1, 1600 / Math.max(W, H)), r = el('canvas'); r.width = Math.round(W * s); r.height = Math.round(H * s); r.getContext('2d').drawImage(c, 0, 0, r.width, r.height);
  const id = uid(); await kvSet('ph:' + id, await new Promise(res => r.toBlob(res, 'image/jpeg', .88)));
  const p = last ? [last.lat, last.lon] : [map.getCenter().lat, map.getCenter().lng];
  const w = addWpt(p[0], p[1], { name: `Photo ${cam.hd != null ? fmtAng(cam.hd) + ' ' + card(cam.hd) : ''}`.trim(), icon: '📷', folder: 'Photos' }); w.photos = [id]; w.attrs = { heading: cam.hd != null ? Math.round(cam.hd) + '°' : '', heading_source: cam.gotSensor ? 'compass' : cam.hd != null ? 'GPS walking direction' : '', tilt: cam.gotSensor ? Math.round(cam.pitch) + '°' : '' }; save.wpts(); drawWpts();
  const f = el('div', { class: 'flash' }); $('#camview').append(f); setTimeout(() => f.remove(), 350); toast('Photo saved with compass stamp (Points → Photos)');
}
function sightBearing() { // record a sighting line from your position along the camera heading (for triangulation)
  if (cam.hd == null || !last) return toast(noCompass() ? 'No compass in this phone. Walk forward about 10 m first so GPS can set the direction.' : 'Need GPS and compass first');
  const a = [last.lat, last.lon], b = destPoint(a, cam.hd, 2000), t = { id: uid(), kind: 'line', name: `Sight ${fmtAng(cam.hd)} ${card(cam.hd)}`, color: '#FF5B1A', pts: [[a[0], a[1], null, null], [b[0], b[1], null, null]], created: Date.now(), folder: 'Sightings', attrs: { bearing: Math.round(cam.hd) + '°' }, photos: [] };
  S.tracks.push(t); save.tracks(); drawTracks(); toast(`Bearing ${fmtAng(cam.hd)} saved as a 2 km sight line (layer "Sightings")`);
}
Object.assign(window.__jejak, { camHeading, openCamCompass, closeCamCompass, cam, drawCamHud });


// ---------- area from manual points (typed coordinates, existing waypoints, or GPS at each corner) ----------
const areaPrev = L.layerGroup().addTo(map);
function orderAround(pts) { const c = [pts.reduce((a, p) => a + p[0], 0) / pts.length, pts.reduce((a, p) => a + p[1], 0) / pts.length], k = Math.cos(rad(c[0])); return [...pts].sort((a, b) => Math.atan2(a[0] - c[0], (a[1] - c[1]) * k) - Math.atan2(b[0] - c[0], (b[1] - c[1]) * k)); }
function areaFromPoints(initial = []) {
  const ta = el('textarea', { placeholder: 'One corner per line, e.g.\n2.37512, 103.75131\n48N 361234 262345\n2°22\'30"N 103°45\'05"E', style: 'min-height:140px;font-variant-numeric:tabular-nums' });
  ta.value = initial.map(p => `${p[0].toFixed(7)}, ${p[1].toFixed(7)}`).join('\n');
  const res = el('div', { class: 'arearesult' }), sortC = el('input', { type: 'checkbox' }), mkC = el('input', { type: 'checkbox', checked: true }), nm = el('input', { type: 'text', placeholder: 'Area name', value: 'Area ' + (S.tracks.filter(t => t.kind === 'area').length + 1) });
  const wsel = el('select'); wsel.append(el('option', { value: '' }, 'Insert a saved waypoint…')); [...S.wpts].sort((a, b) => a.name.localeCompare(b.name)).forEach(w => wsel.append(el('option', { value: w.id }, w.name + (w.folder ? ' (' + w.folder + ')' : ''))));
  const parse = () => { const bad = [], pts = []; ta.value.split('\n').map(x => x.trim()).filter(Boolean).forEach((l, i) => { const p = parseAnyCoord(l); p ? pts.push(p) : bad.push(i + 1); }); return { pts: sortC.checked && pts.length > 2 ? orderAround(pts) : pts, bad }; };
  const upd = () => {
    const { pts, bad } = parse(); areaPrev.clearLayers();
    if (pts.length) { (pts.length > 2 ? L.polygon(pts, { color: '#FF5B1A', weight: 3, fillOpacity: .15, dashArray: '6 5' }) : L.polyline(pts, { color: '#FF5B1A', weight: 3, dashArray: '6 5' })).addTo(areaPrev); pts.forEach((p, i) => L.marker(p, { icon: L.divIcon({ className: '', html: `<div class="cornerno">${i + 1}</div>`, iconSize: [22, 22] }), interactive: false }).addTo(areaPrev)); }
    const a = pts.length > 2 ? areaOf(pts) : 0, per = pts.length > 1 ? pathLen(pts.length > 2 ? [...pts, pts[0]] : pts) : 0;
    res.replaceChildren(el('div', { class: 'ar-big' }, pts.length > 2 ? (a / 1e4).toFixed(4) + ' ha' : '—'),
      el('div', { class: 'mut' }, pts.length > 2 ? `${Math.round(a).toLocaleString('en-GB')} m² · ${(a / 4046.856).toFixed(3)} acres · perimeter ${fmtD(per)} · ${pts.length} corners` : `${pts.length} corner${pts.length === 1 ? '' : 's'}: add at least 3`),
      bad.length ? el('div', { style: 'color:var(--danger);font-size:13.5px;font-weight:600' }, `Could not read line ${bad.join(', ')}`) : '');
  };
  ta.oninput = upd; sortC.onchange = upd;
  wsel.onchange = () => { const w = S.wpts.find(x => x.id === wsel.value); if (w) { ta.value = (ta.value.trim() ? ta.value.trim() + '\n' : '') + `${w.lat.toFixed(7)}, ${w.lon.toFixed(7)}`; upd(); } wsel.value = ''; };
  const addGps = () => { if (!last) { startGPS(); return toast('Waiting for GPS… try again in a moment'); } ta.value = (ta.value.trim() ? ta.value.trim() + '\n' : '') + `${last.lat.toFixed(7)}, ${last.lon.toFixed(7)}`; upd(); toast(`Corner added (GPS ±${Math.round(last.acc)} m)`); };
  const addCtr = () => { const c = map.getCenter(); ta.value = (ta.value.trim() ? ta.value.trim() + '\n' : '') + `${c.lat.toFixed(7)}, ${c.lng.toFixed(7)}`; upd(); };
  const done = () => { areaPrev.clearLayers(); closeModal(); };
  modal('Area from points', el('p', { class: 'mut' }, 'Type or paste each corner, insert saved waypoints, or walk to each corner and add your GPS position. Any format works: lat/lon, UTM, DMS, MGRS or a map link.'), res,
    el('label', {}, 'Corners (in order around the boundary)'), ta,
    el('div', { class: 'row' }, el('button', { class: 'btn sm', onclick: addGps }, '+ Add my GPS position'), el('button', { class: 'btn sm', onclick: addCtr }, '+ Add map crosshair')), wsel,
    el('label', { class: 'mut', style: 'display:block;margin:8px 0' }, sortC, ' Put corners in order automatically (if I typed them out of order)'),
    el('label', { class: 'mut', style: 'display:block;margin:8px 0' }, mkC, ' Also save each corner as a waypoint'), el('label', {}, 'Name'), nm,
    el('div', { class: 'row act' },
      el('button', { class: 'btn pri', onclick: () => {
        const { pts } = parse(); if (pts.length < 3) return toast('Add at least 3 corners');
        const t = { id: uid(), kind: 'area', name: nm.value.trim() || 'Area', color: '#7B4FC9', pts: pts.map(p => [p[0], p[1], null, null]), created: Date.now(), folder: '', attrs: { method: 'manual points' }, photos: [] };
        S.tracks.push(t); save.tracks();
        if (mkC.checked) pts.forEach((p, i) => S.wpts.push({ id: uid(), name: `${t.name} corner ${i + 1}`, note: '', lat: p[0], lon: p[1], color: '#7B4FC9', icon: '🚩', folder: t.name + ' corners', attrs: {}, photos: [], t: Date.now() }));
        save.wpts(); drawTracks(); drawWpts(); done(); map.fitBounds(L.latLngBounds(pts).pad(.2)); toast(`Saved "${t.name}": ${(areaOf(pts) / 1e4).toFixed(4)} ha`); render();
      } }, 'Save area'), el('button', { class: 'btn', onclick: done }, 'Cancel')));
  upd(); if (initial.length > 2) map.fitBounds(L.latLngBounds(initial).pad(.2));
}
const _viewTracks2 = viewTracks;
viewTracks = function (s) { _viewTracks2(s); };
const _viewWpts2 = viewWpts;
viewWpts = function (s) {
  _viewWpts2(s);
  if (sel.wpts) { const bar = [...s.querySelectorAll('.row')].find(x => /selected/.test(x.textContent)); bar && bar.append(el('button', { class: 'btn sm pri', onclick: () => { const p = [...sel.wpts].map(id => S.wpts.find(w => w.id === id)).filter(Boolean); if (p.length < 3) return toast('Select at least 3 waypoints'); sel.wpts = null; render(); areaFromPoints(p.map(w => [w.lat, w.lon])); } }, 'Make area')); }
};
Object.assign(window.__jejak, { areaFromPoints, orderAround });


// ---------- premium layout helpers: tetapan dalam kad boleh dilipat; blok jenama; skrin sambutan ----------
const _render = render;
const OPEN_DEFAULT = { more: 2, layers: 1 }; // berapa kumpulan pertama dibuka secara lalai
const openKey = (t, h) => 'taOpen:' + t + ':' + h;
function brandBlock() {
  const b = el('button', { class: 'brand', 'aria-label': 'About Trail Atlas', onclick: () => welcome(null) }, el('img', { src: 'icon.svg', width: 44, height: 44, alt: '' }),
    el('div', {}, el('b', {}, 'Trail Atlas'), el('span', {}, 'Offline maps · GPS tracks · your own maps')));
  return b;
}
function welcome(after) {
  const row = (ic, t) => el('li', {}, el('span', { 'aria-hidden': 'true' }, ic), t);
  modal('Welcome to Trail Atlas', el('div', { class: 'welcome' }, el('img', { src: 'icon.svg', width: 64, height: 64, alt: '' }),
    el('p', { class: 'mut' }, 'Maps and GPS that keep working when the signal does not.'),
    el('ul', {}, row('🗺️', 'Save map areas and your own paper maps for offline use'), row('🥾', 'Record tracks and drop waypoints with photos'), row('🔒', 'Your data stays on this phone. Back it up from More')),
    el('div', { class: 'row act' }, el('button', { class: 'btn pri', onclick: () => { closeModal(); localStorage.setItem('taWelcomed', '1'); after && after(); } }, 'Start exploring'))));
}
const MORE_LABELS = { Import: 'Import file (GPX, KML, GeoJSON…)', Layers: 'Layers & fields…', 'Point by bearing': 'Point by bearing & distance…' };
function tidyActions(s) { // butang utama sentiasa nampak; yang lain dalam menu "More" (tiada lagi gelongsor mendatar)
  const row = [...s.children].find(c => c.classList && c.classList.contains('row') && c.querySelector('.btn.go,.btn.pri')); if (!row) return;
  const btns = [...row.children]; if (btns.length <= 3) return;
  const main = btns.slice(0, 2), rest = btns.slice(2), holder = el('div', { hidden: '' }, ...rest); // dikekalkan dalam DOM supaya klik (termasuk pemilih fail) berfungsi
  const chev = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
  const more = el('button', { class: 'btn', 'aria-haspopup': 'menu', onclick: ev => { ev.stopPropagation(); $('.menu') ? closeMenu() : actionMenu(more, rest.map(b => { const t = b.textContent.trim(); return [MORE_LABELS[t] || t, () => b.click()]; }), 'More actions'); } }, 'More '); more.insertAdjacentHTML('beforeend', chev);
  const acts = el('div', { class: 'acts' }, ...main, more); row.replaceWith(acts); s.append(holder);
}
render = function () {
  _render(); if (['tracks', 'wpts'].includes(tab)) tidyActions($('#sheet'));
  if (!['layers', 'more'].includes(tab)) return;
  const s = $('#sheet'), kids = [...s.children].slice(1); let grp = null, body = null, n = 0;
  kids.forEach((k, i) => {
    if (k.tagName === 'H3') {
      const nx = kids[i + 1];
      if (!nx || nx.tagName === 'H3') { k.classList.add('ptitle'); grp = null; return; } // tajuk tanpa isi = tajuk halaman, bukan kad kosong
      const key = openKey(tab, k.textContent.trim()), saved = localStorage.getItem(key);
      const d = grp = el('details', { class: 'group' }); if (saved === '1' || (saved === null && n < (OPEN_DEFAULT[tab] || 0))) d.open = true; n++;
      d.addEventListener('toggle', () => localStorage.setItem(key, d.open ? '1' : '0')); // d (bukan grp): grp berubah untuk kumpulan seterusnya
      body = el('div', { class: 'gbody' }); const h = k.cloneNode(true); d.append(el('summary', {}, h), body); s.insertBefore(d, k); k.remove(); return;
    }
    if (grp) body.append(k);
  });
  if (tab === 'more') s.insertBefore(brandBlock(), s.children[1]);
};
$('#fCam').onclick = openCamCompass;


// ---------- new waypoint chooser: GPS, manual crosshair, typed coordinates, bearing & distance ----------
function choiceCard(icon, title, desc, fn, tone) {
  const b = el('button', { class: 'choice ' + (tone || '') , onclick: fn }); const i = el('span', { class: 'choice-i' }); i.innerHTML = icon;
  b.append(i, el('span', { class: 'choice-t' }, el('b', {}, title), el('span', {}, desc)), el('span', { class: 'choice-c', 'aria-hidden': 'true' }, '›')); return b;
}
function newWaypoint() {
  const gpsDesc = last ? `Use the current GPS position (±${Math.round(last.acc)} m)` : 'Use the current GPS position (starts GPS)';
  modal('New waypoint', el('p', { class: 'mut', style: 'margin-top:0' }, 'Where do you want to place it?'),
    choiceCard('<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="8.5"/><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3"/></svg>', 'At my GPS location', gpsDesc, () => { closeModal(); placeAtGps(); }, 'blue'),
    choiceCard('<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="7"/><path d="M12 2v6M12 16v6M2 12h6M16 12h6"/></svg>', 'Manual crosshair', 'Move the map and confirm where the crosshair points', () => { closeModal(); pickCrosshair(); }, 'amber'),
    choiceCard('<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 10h2M11 10h2M15 10h2M7 14h10"/></svg>', 'Enter coordinates', 'Type lat/lon, UTM, MGRS or paste a map link', () => { closeModal(); typeCoords(); }),
    choiceCard('<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 12 17 7"/><circle cx="12" cy="12" r="1.6" fill="currentColor"/><path d="M6.5 17.5 12 12"/></svg>', 'Bearing & distance', 'Project a point from where you stand', () => { closeModal(); projectPoint(); }));
}
function placeAtGps() {
  const put = () => { map.setView([last.lat, last.lon], Math.max(map.getZoom(), 17)); editFeature(addWpt(last.lat, last.lon), 'wpt'); toast(`Placed at your GPS position (±${Math.round(last.acc)} m)`); };
  if (last && watchId !== null) return put();
  const before = last; startGPS(); toast('Waiting for GPS fix…', 30000); const t0 = Date.now();
  const iv = setInterval(() => { if (last && last !== before) { clearInterval(iv); put(); } else if (Date.now() - t0 > 30000) { clearInterval(iv); toast('No GPS fix yet. Try the manual crosshair instead.', 5000); } }, 400);
}
function pickCrosshair(after) { // move the map under the crosshair, then confirm
  setTab('map'); document.body.classList.add('picking'); const b = $('#pickbar'); b.hidden = false;
  const upd = () => { const c = map.getCenter(); b.querySelector('.pk-c').textContent = fmtC(c.lat, c.lng); };
  const end = () => { document.body.classList.remove('picking'); b.hidden = true; map.off('move', upd); };
  b.replaceChildren(el('div', { class: 'pk-h' }, el('span'), 'Drag the map — the target stays put'), el('b', { class: 'pk-c' }),
    el('div', { class: 'row', style: 'margin:6px 0 0;flex-wrap:nowrap' }, el('button', { class: 'btn sm pri', onclick: () => { const c = map.getCenter(); end(); after ? after([c.lat, c.lng]) : editFeature(addWpt(c.lat, c.lng), 'wpt'); } }, 'Place here'), el('button', { class: 'btn sm', onclick: end }, 'Cancel')));
  map.on('move', upd); upd();
}
function typeCoords() {
  const i = el('input', { type: 'text', placeholder: 'e.g. 2.37512, 103.75131 or 48N 361889 264984', autocomplete: 'off' }), out = el('div', { class: 'mut', style: 'min-height:22px;margin-top:6px' });
  let p = null; i.oninput = () => { p = parseAnyCoord(i.value); out.textContent = i.value.trim() ? (p ? '✓ ' + fmtC(p[0], p[1]) + (S.set.coord !== 'utm' ? '  ·  ' + utm(p[0], p[1]) : '') : 'Not recognised yet') : ''; out.style.color = p || !i.value.trim() ? '' : 'var(--danger)'; };
  modal('Enter coordinates', el('p', { class: 'mut', style: 'margin-top:0' }, 'Accepted: decimal lat, lon · UTM (zone, easting, northing) · MGRS · DMS · Google/Apple Maps link.'), i, out,
    el('div', { class: 'row act' }, el('button', { class: 'btn pri', onclick: () => { if (!p) return toast('Enter a valid position'); closeModal(); map.setView(p, Math.max(map.getZoom(), 16)); editFeature(addWpt(p[0], p[1]), 'wpt'); } }, 'Place point'), el('button', { class: 'btn', onclick: closeModal }, 'Cancel')));
  setTimeout(() => i.focus(), 50);
}
Object.assign(window.__jejak, { newWaypoint, pickCrosshair, typeCoords, placeAtGps });


// ---------- crosshair drawing (FO Maps style): rubber-band to the crosshair, live area / perimeter, +Vertex ----------
const draw = { on: false, kind: 'area', pts: [], color: '#2F8BFF', weight: 3, fill: .2, style: false, gL: L.layerGroup(), gV: L.layerGroup() };
function startDraw(kind = 'area') {
  if (meas.on) toggleMeas(); closeModal(); setTab('map'); stopEditOv();
  Object.assign(draw, { on: true, kind, pts: [] }); draw.gL.addTo(map); draw.gV.addTo(map); document.body.classList.add('drawing'); $('#fMeas').classList.add('on');
  map.on('move', drawUpdate); drawVerts(); drawUpdate(); toast('Move the map to put the crosshair on a corner, then tap +Vertex', 4000);
}
function endDraw() { draw.on = false; map.off('move', drawUpdate); draw.gL.clearLayers(); draw.gV.clearLayers(); map.removeLayer(draw.gL); map.removeLayer(draw.gV); document.body.classList.remove('drawing'); $('#fMeas').classList.remove('on'); $('#drawpanel').hidden = true; }
function drawVerts() {
  draw.gV.clearLayers();
  draw.pts.forEach((p, i) => L.marker(p, { draggable: true, icon: L.divIcon({ className: '', html: `<div class="vtx${i === 0 ? ' first' : ''}" style="--c:${draw.color}"></div>`, iconSize: [22, 22] }) })
    .on('drag', e => { const q = e.target.getLatLng(); draw.pts[i] = [q.lat, q.lng]; drawUpdate(); }).addTo(draw.gV));
}
function drawUpdate() {
  if (!draw.on) return; const c = map.getCenter(), cc = [c.lat, c.lng], P = draw.pts, area = draw.kind === 'area', st = { color: draw.color, weight: draw.weight, interactive: false };
  draw.gL.clearLayers();
  if (P.length) {
    if (area && P.length >= 2) L.polygon([...P, cc], { ...st, stroke: false, fillOpacity: draw.fill }).addTo(draw.gL);
    if (P.length >= 2) L.polyline(P, st).addTo(draw.gL);
    L.polyline([P[P.length - 1], cc], { ...st, dashArray: '6 7', opacity: .9 }).addTo(draw.gL);
    if (area && P.length >= 2) L.polyline([cc, P[0]], { ...st, dashArray: '6 7', opacity: .55 }).addTo(draw.gL);
  }
  const live = P.length ? [...P, cc] : [], seg = P.length ? [hav(P[P.length - 1], cc), brg(P[P.length - 1], cc)] : null;
  const big = area ? (live.length >= 3 ? `${fmtA(areaOf(live))} · perimeter ${fmtD(pathLen([...live, live[0]]))}` : 'Add 2 corners to see the area') : (live.length >= 2 ? `Length ${fmtD(pathLen(live))}` : 'Add a point to start');
  const b = $('#drawpanel'); b.hidden = false;
  const icon = area ? '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3 21 9.5 17.5 20h-11L3 9.5Z"/></svg>' : '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 18 10 8l4 6 6-9"/></svg>';
  const kindBtn = el('button', { class: 'dp-kind', 'aria-label': 'Switch between polygon and line', onclick: () => { draw.kind = area ? 'line' : 'area'; drawUpdate(); } }); kindBtn.innerHTML = icon + `<span>${area ? 'Polygon' : 'Line'} · ${P.length} pt${P.length === 1 ? '' : 's'}</span>`;
  const gps = el('button', { class: 'dp-gps', onclick: () => { if (!last) { startGPS(); return toast('Waiting for GPS… tap GPS again in a moment'); } draw.pts.push([last.lat, last.lon]); map.panTo([last.lat, last.lon]); drawVerts(); drawUpdate(); toast(`Corner added at GPS (±${Math.round(last.acc)} m)`); } }, 'GPS');
  const tile = (label, svg, fn, cls = '') => { const t = el('button', { class: 'dp-tile ' + cls, onclick: fn }); t.innerHTML = svg; t.append(el('span', {}, label)); return t; };
  const style = el('div', { class: 'dp-style' + (draw.style ? ' open' : '') },
    el('div', { class: 'row', style: 'flex-wrap:nowrap;overflow-x:auto' }, ...['#2F8BFF', '#FF5B1A', '#2F6B40', '#E8B400', '#7B4FC9', '#C2185B', '#FFFFFF', '#15241C'].map(c => el('button', { class: 'sw' + (c === draw.color ? ' on' : ''), style: 'background:' + c + ';flex:none', 'aria-label': 'Colour ' + c, onclick: () => { draw.color = c; drawVerts(); drawUpdate(); } }))),
    el('div', { class: 'row' }, el('span', { class: 'mut' }, 'Line'), ...[2, 3, 5].map(w => el('button', { class: 'btn sm' + (w === draw.weight ? ' pri' : ''), onclick: () => { draw.weight = w; drawUpdate(); } }, w + ' px')),
      area ? el('span', { class: 'mut', style: 'margin-left:6px' }, 'Fill') : '', ...(area ? [0, .2, .4].map(f => el('button', { class: 'btn sm' + (f === draw.fill ? ' pri' : ''), onclick: () => { draw.fill = f; drawUpdate(); } }, Math.round(f * 100) + '%')) : [])));
  b.replaceChildren(
    el('div', { class: 'dp-head' }, kindBtn, el('div', { class: 'dp-big' }, big), gps),
    el('div', { class: 'dp-sub' }, seg ? `→ ${fmtD(seg[0])} · ${fmtAng(seg[1])} ${card(seg[1])} from last corner` : 'Crosshair: ' + fmtC(cc[0], cc[1])),
    el('button', { class: 'dp-styletoggle', onclick: () => { draw.style = !draw.style; drawUpdate(); } }, el('span', { class: 'dot', style: 'background:' + draw.color }), `Style · ${draw.weight}px` + (area ? ` · ${Math.round(draw.fill * 100)}% fill` : ''), el('span', { class: 'mut', style: 'margin-left:auto' }, draw.style ? '▴' : '▾')), style,
    el('div', { class: 'dp-tiles' },
      tile('Cancel', '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 6l12 12M18 6 6 18"/></svg>', () => { if (!draw.pts.length || confirm('Discard this drawing?')) endDraw(); }),
      tile('Undo', '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 14 4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/></svg>', () => { draw.pts.pop(); drawVerts(); drawUpdate(); }),
      tile('+Vertex', '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 21.5s-6.5-5.8-6.5-11.5a6.5 6.5 0 0 1 13 0c0 5.7-6.5 11.5-6.5 11.5Z"/><path d="M12 7v6M9 10h6"/></svg>', () => { draw.pts.push(cc); navigator.vibrate && navigator.vibrate(15); drawVerts(); drawUpdate(); }, 'add'),
      tile('Save', '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2.2"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>', saveDraw, 'save')),
    el('div', { class: 'dp-more' }, el('span', { class: 'mut' }, 'Other ways:'),
      el('button', { class: 'dp-tap', onclick: () => { const pts = draw.pts.slice(); endDraw(); areaFromPoints(pts); } }, 'Type coordinates / pick saved points'),
      el('button', { class: 'dp-tap', onclick: () => { endDraw(); toggleMeas(); } }, 'Tap, freehand & road routing')));
}
function saveDraw() {
  const P = draw.pts, area = draw.kind === 'area';
  if (P.length < (area ? 3 : 2)) return toast(area ? 'An area needs at least 3 corners' : 'A line needs at least 2 points');
  const n = S.tracks.filter(t => t.kind === (area ? 'area' : 'line')).length + 1;
  const t = { id: uid(), kind: area ? 'area' : 'line', name: (area ? 'Area ' : 'Route ') + n, color: draw.color, weight: draw.weight, fill: draw.fill, pts: P.map(p => [p[0], p[1], null, null]), created: Date.now(), folder: '', attrs: { method: 'crosshair' }, photos: [] };
  S.tracks.push(t); save.tracks(); endDraw(); drawTracks(); toast(area ? `Saved: ${fmtA(areaOf(P))}, perimeter ${fmtD(pathLen([...P, P[0]]))}` : `Saved: ${fmtD(pathLen(P))}`, 4000); editFeature(t, 'track');
}
$('#fMeas').onclick = () => { if (meas.on) return toggleMeas(); if (draw.on) { if (!draw.pts.length || confirm('Discard this drawing?')) endDraw(); return; } startDraw('area'); };
Object.assign(window.__jejak, { startDraw, endDraw, draw, saveDraw });


// ---------- (2) tool labels: shown on first run, and on long-press of any tool ----------
const TOOL_NAMES = { fLoc: 'My location / compass mode', fWpt: 'New waypoint', fMeas: 'Draw area or route', fPhoto: 'Photo waypoint', fCam: 'Camera compass', fShare: 'Share map (PDF, image, files)', fRec: 'Record track', fNorth: 'Turn map north up' };
function showToolLabels(ms = 3500) {
  hideToolLabels(); const box = el('div', { id: 'toollabels', 'aria-hidden': 'true' });
  Object.entries(TOOL_NAMES).forEach(([id, n]) => { const b = $('#' + id); if (!b || b.hidden || !b.offsetParent) return; const r = b.getBoundingClientRect(); box.append(el('span', { class: 'tl', style: `top:${r.top + r.height / 2}px;right:${innerWidth - r.left + 10}px` }, n)); });
  document.body.append(box); clearTimeout(showToolLabels.t); showToolLabels.t = setTimeout(hideToolLabels, ms);
}
function hideToolLabels() { const x = $('#toollabels'); if (x) x.remove(); }
Object.keys(TOOL_NAMES).forEach(id => {
  const b = $('#' + id); if (!b) return; let t = 0, fired = false;
  b.addEventListener('pointerdown', () => { fired = false; t = setTimeout(() => { fired = true; navigator.vibrate && navigator.vibrate(10); showToolLabels(); }, 450); });
  ['pointerup', 'pointerleave', 'pointercancel'].forEach(ev => b.addEventListener(ev, () => clearTimeout(t)));
  b.addEventListener('click', e => { if (fired) { e.stopImmediatePropagation(); e.preventDefault(); fired = false; } }, true);
  b.addEventListener('contextmenu', e => e.preventDefault());
});
addEventListener('pointerdown', e => { if ($('#toollabels') && !e.target.closest('.rail')) hideToolLabels(); });

// ---------- (3) first run: go to the open estate map or to your GPS position; later runs keep your last view ----------
setTimeout(() => {
  if (localStorage.getItem('firstRunDone')) return;
  localStorage.setItem('firstRunDone', '1');
  const open = S.overlays.find(o => !o.hidden), fresh = !localStorage.getItem('taWelcomed') && !S.tracks.length && !S.wpts.length;
  if (open) map.fitBounds(ovBounds(open)); else if (!fresh) { startGPS(); toast('Finding your location…', 4000); }
  const tips = () => { showToolLabels(7000); toast('Tip: press and hold any button to see its name', 5000); };
  if (fresh) welcome(() => { if (!open) startGPS(); tips(); }); else setTimeout(tips, 800); // pengguna baharu: GPS dimulakan SELEPAS sambutan supaya amaran kebenaran tidak menutupnya
}, 900);
Object.assign(window.__jejak, { showToolLabels, hideToolLabels });

// ---------- cloud backup: automatic, to Shaiful's own cloud computer (key-protected), restore on any phone or new link ----------
const cloud = { dirty: { data: false, maps: false }, busy: false, last: JSON.parse(localStorage.getItem('taCloudLast') || '{}') };
cloud.dev = localStorage.getItem('taDev') || (() => { const d = 'd' + uid(); localStorage.setItem('taDev', d); return d; })();
(() => { const h = location.hash, m = h.match(/[#&]k=([A-Za-z0-9_-]{16,64})/), sv = h.match(/[#&]s=((?:https:\/\/|http:\/\/(?:localhost|127\.0\.0\.1)[:\/])[^&?#\s]+)/); if (sv) localStorage.setItem('taApi', decodeURIComponent(sv[1])); if (m) localStorage.setItem('taKey', m[1]); if (m || sv) history.replaceState(null, '', location.pathname + location.search); })();
const cloudKey = () => localStorage.getItem('taKey');
for (const k of ['tracks', 'wpts', 'schemas', 'set']) { const f = save[k]; save[k] = (...a) => { cloud.dirty.data = true; return f(...a); }; }
{ const f = save.overlays; save.overlays = (...a) => { cloud.dirty.maps = true; return f(...a); }; }
for (const k of ['geofences', 'custom', 'bin']) { const f = saveX[k]; saveX[k] = (...a) => { cloud.dirty.data = true; return f(...a); }; }
async function cloudPart(part) {
  if (part === 'maps') return { v: 3, part, at: Date.now(), maps: await Promise.all(S.overlays.filter(o => o.type === 'image').map(async o => ({ ...o, _url: undefined, blob: await blobToURL(o.blob) }))) };
  const photos = {}; for (const id of [...S.wpts, ...S.tracks, ...S.bin.map(b => b.item)].flatMap(x => x.photos || [])) { const b = await kvGet('ph:' + id); if (b) photos[id] = await blobToURL(b); }
  return { v: 3, part, at: Date.now(), tracks: S.tracks, wpts: S.wpts, photos, schemas: S.schemas, set: S.set, geofences: S.geofences, custom: S.custom, bin: S.bin };
}
async function cloudUpload(part, quiet) {
  const key = cloudKey(); if (!key) throw Error('cloud backup is not set up on this phone');
  const body = JSON.stringify(await cloudPart(part));
  const r = await fetch(`${apiBase()}api/backup?dev=${cloud.dev}&part=${part}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-TA-Key': key }, body, keepalive: body.length < 60000 });
  if (r.status === 403) throw Error('the backup key is wrong — open the setup link from Telegram again');
  if (!r.ok) throw Error('server said ' + r.status);
  cloud.dirty[part] = false; cloud.last[part] = Date.now(); localStorage.setItem('taCloudLast', JSON.stringify(cloud.last));
  if (!quiet) toast(`Backed up to your cloud (${(body.length / 1048576).toFixed(1)} MB)`);
  return body.length;
}
async function cloudSync(force) { // runs every minute, when going offline→online and when the app goes to the background
  if (cloud.busy || !cloudKey() || !navigator.onLine) return; cloud.busy = true;
  try {
    const stale = p => force || cloud.dirty[p] || (Date.now() - (cloud.last[p] || 0) > 24 * 36e5 && (p === 'data' ? S.tracks.length + S.wpts.length : S.overlays.length));
    if (stale('data')) await cloudUpload('data', !force); if (stale('maps')) await cloudUpload('maps', !force);
  } catch (e) { if (force) toast('Backup failed: ' + e.message, 6000); }
  finally { cloud.busy = false; }
}
setInterval(() => cloudSync(), 60000);
addEventListener('online', () => cloudSync());
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') cloudSync(); });
async function cloudList() { const r = await fetch(apiBase() + 'api/backups', { headers: { 'X-TA-Key': cloudKey() || '' } }); if (r.status === 403) throw Error('wrong or missing backup key'); if (!r.ok) throw Error('server said ' + r.status); return r.json(); }
async function cloudRestore(dev, files) { // files: {data: name, maps: name}
  const get = async f => { const r = await fetch(`${apiBase()}api/backup?dev=${dev}&file=${f}`, { headers: { 'X-TA-Key': cloudKey() } }); if (!r.ok) throw Error('download failed ' + r.status); return r.json(); };
  toast('Restoring from cloud…', 15000);
  if (files.data) {
    const j = await get(files.data);
    for (const [id, u] of Object.entries(j.photos || {})) await kvSet('ph:' + id, await (await fetch(u)).blob());
    S.tracks = j.tracks || []; S.wpts = j.wpts || []; S.schemas = j.schemas || {}; S.geofences = j.geofences || []; S.custom = j.custom || []; S.bin = j.bin || [];
    Object.assign(S.set, j.set || {}); for (const b of S.set.userBases || []) BASES[b.id] = b; await save.tracks(); await save.wpts(); await save.schemas(); await save.set(); for (const k of ['geofences', 'custom', 'bin']) await saveX[k]();
  }
  if (files.maps) {
    const j = await get(files.maps);
    for (const m of j.maps || []) if (!S.overlays.some(o => o.id === m.id)) S.overlays.push(migrateOv({ ...m, blob: await (await fetch(m.blob)).blob() }));
    await save.overlays();
  }
  cloud.dirty = { data: false, maps: false }; setBase(S.set.base); drawTracks(); drawWpts(); drawOverlays(); drawFences(); drawCustom(); render();
  toast(`Restored: ${S.tracks.length} tracks/areas, ${S.wpts.length} waypoints, ${S.overlays.length} maps`, 6000);
}
function pickLatest(list) { // newest device backup: latest data + latest maps of that device
  if (!list.length) return null; const dev = list[0].dev, of = p => (list.find(x => x.dev === dev && x.part === p) || {}).file;
  return { dev, time: list[0].time, files: { data: of('data'), maps: of('maps') }, mine: dev === cloud.dev };
}
async function cloudUI() {
  const box = el('div', {}, el('p', { class: 'mut' }, 'Loading…'));
  modal('Cloud backup', box, el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: closeModal }, 'Close')));
  if (!cloudKey()) return box.replaceChildren(el('p', {}, 'Cloud backup is not set up on this phone yet.'), el('p', { class: 'mut' }, 'Open the setup link Mat sent you on Telegram (@MatKelod_Bot). It contains your private key and turns on automatic backup.'),
    (() => { const i = el('input', { type: 'text', placeholder: 'or paste the backup key here' }); return el('div', {}, i, el('button', { class: 'btn pri', style: 'margin-top:8px', onclick: () => { const v = i.value.trim().replace(/.*k=/, ''); if (!/^[A-Za-z0-9_-]{16,64}$/.test(v)) return toast('That key does not look right'); localStorage.setItem('taKey', v); cloudUI(); cloudSync(true); } }, 'Save key')); })());
  let list = []; try { list = await cloudList(); } catch (e) { return box.replaceChildren(el('p', { style: 'color:var(--danger)' }, 'Cannot reach the cloud: ' + e.message)); }
  const fmt = t => t ? new Date(t).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }) : 'never';
  const byDev = {}; list.forEach(x => (byDev[x.dev] = byDev[x.dev] || []).push(x));
  box.replaceChildren(
    el('div', { class: 'arearesult' }, el('b', {}, '✓ Automatic backup is on'), el('div', { class: 'mut' }, `Last backup from this phone: data ${fmt(cloud.last.data)}, maps ${fmt(cloud.last.maps)}. Changes are backed up within a few minutes when online, and copied weekly to Google Drive.`)),
    el('div', { class: 'row' }, el('button', { class: 'btn pri', onclick: async () => { await cloudSync(true); cloudUI(); } }, 'Back up now')),
    el('h3', { style: 'margin-top:14px' }, 'Restore'),
    ...(Object.keys(byDev).length ? Object.entries(byDev).map(([dev, xs]) => { const lt = pickLatest(xs), size = xs.filter(x => x.file === lt.files.data || x.file === lt.files.maps).reduce((a, x) => a + x.size, 0);
      return el('div', { class: 'item' }, el('div', { class: 't' }, dev === cloud.dev ? 'This phone' : 'Another phone / older link'), el('div', { class: 'mut' }, `Latest ${fmt(lt.time)}, ${(size / 1048576).toFixed(1)} MB`),
        el('div', { class: 'row' }, el('button', { class: 'btn sm', onclick: async () => { if (!confirm('Replace the tracks and waypoints on this phone with this backup? Maps are added, not replaced.')) return; closeModal(); try { await cloudRestore(dev, lt.files); } catch (e) { toast('Restore failed: ' + e.message, 6000); } } }, 'Restore this backup'))); })
      : [el('p', { class: 'mut' }, 'No backups yet.')]));
}
async function offerRestore() { // a new link (new web address) starts empty: offer the newest cloud backup
  if (!cloudKey() || S.tracks.length || S.wpts.length || S.overlays.length) return;
  try { const lt = pickLatest(await cloudList()); if (!lt) return;
    modal('Restore your data?', el('p', {}, `This link starts empty, but your cloud has a backup from ${new Date(lt.time).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}.`),
      el('div', { class: 'row act' }, el('button', { class: 'btn pri', onclick: async () => { closeModal(); try { await cloudRestore(lt.dev, lt.files); } catch (e) { toast('Restore failed: ' + e.message, 6000); } } }, 'Restore'), el('button', { class: 'btn', onclick: closeModal }, 'Not now')));
  } catch (e) { }
}
function backupReminder() { // without cloud backup: remind weekly to save a backup file
  if (cloudKey() || !(S.tracks.length || S.wpts.length)) return; const lastR = +localStorage.getItem('taRemind') || 0, lastB = +localStorage.getItem('taManualBackup') || 0;
  if (Date.now() - Math.max(lastR, lastB) < 7 * 864e5) return; localStorage.setItem('taRemind', Date.now());
  toast('Data stays on this phone · More → Cloud backup', 5000);
}
const _backup = backup; backup = async (...a) => { localStorage.setItem('taManualBackup', Date.now()); return _backup(...a); };
const _viewMore2 = viewMore;
viewMore = function (s) {
  _viewMore2(s); const first = s.querySelector('h3');
  const card = el('div', {}, el('h3', {}, 'Cloud backup'), el('p', { class: 'mut' }, cloudKey() ? `On. Last backup ${cloud.last.data ? new Date(cloud.last.data).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' }) : 'pending'}.` : 'Off. Your data is only on this phone.'),
    el('div', { class: 'row' }, el('button', { class: 'btn ' + (cloudKey() ? '' : 'pri'), onclick: cloudUI }, cloudKey() ? 'Backup & restore' : 'Set up cloud backup')));
  [...card.children].forEach(x => s.insertBefore(x, first));
};
setTimeout(() => { offerRestore(); backupReminder(); cloudSync(); }, 2500);
Object.assign(window.__jejak, { cloud, cloudSync, cloudUpload, cloudList, cloudRestore, cloudUI, offerRestore });
