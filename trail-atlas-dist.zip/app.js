'use strict';
// ---------- util ----------
const $ = s => document.querySelector(s);
const BTN_ICONS = [ // line icons shown before button labels (matched on the label's first word)
  [/^(zoom|show)\b/i, '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.8-4.8"/>'], [/^hide\b/i, '<path d="M3 3l18 18M10.6 6.1A9.8 9.8 0 0 1 12 6c5 0 9 6 9 6a15 15 0 0 1-3 3.4M6.6 6.6C4.3 8.1 3 12 3 12s4 6 9 6a9 9 0 0 0 4.4-1.2"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>'],
  [/^(go to|follow|directions)\b/i, '<path d="M12 2 19 21 12 17 5 21Z"/>'], [/^(edit|details|rename)\b/i, '<path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m14 6 4 4"/>'],
  [/^share\b/i, '<path d="M12 15V3.5M7.5 8 12 3.5 16.5 8"/><path d="M5 12v7.5h14V12"/>'], [/^(delete|remove)\b/i, '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>'],
  [/^(save|done|✔)/i, '<path d="m5 12.5 4.5 4.5L19 7.5"/>'], [/^(import|restore)\b/i, '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5"/><path d="M5 19.5h14"/>'],
  [/^(download|export)\b/i, '<path d="M12 4v11M7.5 10.5 12 15l4.5-4.5"/><path d="M5 19.5h14"/>'], [/^charts?\b/i, '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'],
  [/^record\b/i, '<circle cx="12" cy="12" r="6" fill="currentColor"/>'], [/^(stop|pause)\b/i, '<rect x="7" y="7" width="10" height="10" rx="1.5"/>'], [/^resume\b/i, '<path d="M8 5v14l11-7Z"/>'],
  [/^(camera|photo|photograph)\b/i, '<path d="M3.5 8h3.5l2-3h6l2 3h3.5v11.5h-17Z"/><circle cx="12" cy="13.2" r="3.6"/>'], [/^gallery\b/i, '<rect x="3.5" y="4.5" width="17" height="15" rx="2"/><path d="m4 17 5-5 4 4 3-3 4 4"/><circle cx="15.5" cy="9" r="1.5"/>'],
  [/^open\b/i, '<path d="M3.5 6.5h6l2 2h9v10h-17Z"/>'], [/^align\b/i, '<path d="M12 3v18M3 12h18M12 3l-2.5 2.5M12 3l2.5 2.5M12 21l-2.5-2.5M12 21l2.5-2.5M3 12l2.5-2.5M3 12l2.5 2.5M21 12l-2.5-2.5M21 12l-2.5 2.5"/>'],
  [/^layers\b/i, '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12.5 9 5 9-5"/>'], [/^mark map/i, '<path d="M12 3v6M12 15v6M3 12h6M15 12h6"/>'], [/^mark my/i, '<circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>'],
  [/^(plan|draw)\b/i, '<circle cx="5.5" cy="18.5" r="2"/><circle cx="18.5" cy="5.5" r="2"/><path d="M7.5 18.5H15a3.5 3.5 0 0 0 0-7H9a3.5 3.5 0 0 1 0-7h7.5"/>'], [/^(cancel|close|clear)\b/i, '<path d="M6 6l12 12M18 6 6 18"/>'],
  [/^\+|^add\b|^new\b/i, '<path d="M12 5v14M5 12h14"/>'], [/^(elevation|add elevation)\b/i, '<path d="m3 19 6-10 4 6 3-4 5 8Z"/>'], [/^(geopdf|pdf)\b/i, '<path d="M6 3h8l4 4v14H6Z"/><path d="M14 3v4h4"/>'],
  [/^(fields|🧾)/i, '<path d="M5 4h14v16H5ZM8 9h8M8 13h8M8 17h5"/>'], [/^cockpit\b/i, '<path d="M4 15a8 8 0 1 1 16 0"/><path d="m12 15 4-5"/>'], [/^lap\b/i, '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>'],
  [/^play\b/i, '<path d="M8 5v14l11-7Z"/>'], [/^video\b/i, '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3"/>'], [/^weather\b/i, '<path d="M7 18h10a4 4 0 0 0 .5-8 6 6 0 0 0-11.5 1.5A3.3 3.3 0 0 0 7 18Z"/>'],
  [/^select\b/i, '<rect x="4" y="4" width="16" height="16" rx="3"/><path d="m8 12 3 3 5-6"/>'], [/^(convert)\b/i, '<path d="M4 7h13l-3-3M20 17H7l3 3"/>'], [/^(point|points)\b/i, '<path d="M12 21.5s-6.5-5.8-6.5-11.5a6.5 6.5 0 0 1 13 0c0 5.7-6.5 11.5-6.5 11.5Z"/><circle cx="12" cy="10" r="2.3"/>'],
  [/^copy\b/i, '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V5a1 1 0 0 0-1-1H5a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h3"/>'], [/^move\b/i, '<path d="M3.5 6.5h6l2 2h9v10h-17Z"/><path d="m11 13.5h6M14.5 11l2.5 2.5-2.5 2.5"/>'],
  [/^(area|make area)\b/i, '<path d="M4 7l7-4 9 5-2 11-11 2Z"/>'],
  [/^(scan)\b/i, '<path d="M4 8V4h4M16 4h4v4M20 16v4h-4M8 20H4v-4M7 12h10"/>'], [/^(alert|geofence)\b/i, '<path d="M6 16V11a6 6 0 0 1 12 0v5l2 2H4Z"/><path d="M10 20a2 2 0 0 0 4 0"/>']];
const el = (t, a = {}, ...c) => {
  const e = document.createElement(t);
  if (t === 'button' && /\bbtn\b/.test(a.class || '') && typeof c[0] === 'string') { const m = BTN_ICONS.find(([r]) => r.test(c[0].trim())); if (m && /^\+\s*/.test(c[0])) c[0] = c[0].replace(/^\+\s*/, ''); if (m) { const sv = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); sv.setAttribute('viewBox', '0 0 24 24'); sv.setAttribute('class', 'bi'); sv.setAttribute('aria-hidden', 'true'); sv.innerHTML = m[1]; e.append(sv); } }
  for (const k in a) { if (k === 'class') e.className = a[k]; else if (k.startsWith('on')) e[k] = a[k]; else if (k === 'value' || k === 'checked') e[k] = a[k]; else e.setAttribute(k, a[k]); }
  c.flat().forEach(x => x != null && x !== false && e.append(x));
  return e;
};
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
const toast = (m, ms = 2500) => { const t = $('#toast'); t.textContent = m; t.style.display = 'block'; clearTimeout(toast.h); toast.h = setTimeout(() => t.style.display = 'none', ms); };
const COLORS = ['#FF5B1A', '#1D6FB8', '#C2185B']; // three picks only; contrast-tested on satellite and topo
const ICONS = { '📍': 'Pin', '🚩': 'Flag', '🏠': 'Building', '⛺': 'Camp', '💧': 'Water', '🌴': 'Palm / estate', '🌳': 'Tree', '🚧': 'Hazard', '⚠️': 'Warning', '🅿️': 'Parking', '🛠️': 'Equipment', '⛽': 'Fuel', '🍴': 'Food', '🐘': 'Wildlife', '📷': 'Photo', '🏁': 'Finish' };
const esc = s => String(s ?? '').replace(/[<>&"']/g, c => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[c]));
const loadScript = src => new Promise((ok, no) => { if (document.querySelector(`script[src="${src}"]`)) return ok(); const s = el('script', { src }); s.onload = ok; s.onerror = () => no(Error('failed to load ' + src)); document.head.append(s); });
const nums = str => [...str.matchAll(/-?\d*\.?\d+(?:[eE][-+]?\d+)?/g)].map(m => +m[0]);
const blobToURL = b => new Promise(r => { const f = new FileReader(); f.onload = () => r(f.result); f.readAsDataURL(b); });

// ---------- storage: lihat core.js (kvGet/kvSet/kvDel, migrateStore, taErrLog) ----------
const S = { tracks: [], wpts: [], overlays: [], set: { base: 'osm', coord: 'dd', multi: false, minDist: 3, maxAcc: 50, labels: true, nightMap: true } };
S.schemas = {}; // per folder (layer): [{name, type, options}] like Avenza attribute schema
const save = { schemas: () => kvSet('schemas', S.schemas), tracks: () => kvSet('tracks', S.tracks), wpts: () => kvSet('wpts', S.wpts), overlays: () => kvSet('overlays', S.overlays), set: () => kvSet('set', S.set) };
const phCache = {};
async function photoURL(id) { if (!(id in phCache)) { const b = await kvGet('ph:' + id); phCache[id] = b ? URL.createObjectURL(b) : ''; } return phCache[id]; }

// ---------- geo ----------
const R = 6371008.8, rad = d => d * Math.PI / 180, deg = r => r * 180 / Math.PI;
function hav(a, b) {
  const dp = rad(b[0] - a[0]), dl = rad(b[1] - a[1]);
  const x = Math.sin(dp / 2) ** 2 + Math.cos(rad(a[0])) * Math.cos(rad(b[0])) * Math.sin(dl / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}
const brg = (a, b) => { const p1 = rad(a[0]), p2 = rad(b[0]), dl = rad(b[1] - a[1]); return (deg(Math.atan2(Math.sin(dl) * Math.cos(p2), Math.cos(p1) * Math.sin(p2) - Math.sin(p1) * Math.cos(p2) * Math.cos(dl))) + 360) % 360; };
const card = d => ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'][Math.round(d / 45) % 8];
const pathLen = p => { let d = 0; for (let i = 1; i < p.length; i++) d += hav(p[i - 1], p[i]); return d; };
function areaOf(p) { // m², spherical polygon
  if (p.length < 3) return 0; let s = 0;
  for (let i = 0; i < p.length; i++) { const a = p[i], b = p[(i + 1) % p.length]; s += rad(b[1] - a[1]) * (2 + Math.sin(rad(a[0])) + Math.sin(rad(b[0]))); }
  return Math.abs(s * R * R / 2);
}
const UNITS = () => S.set.units || 'metric';
const fmtD = m => UNITS() === 'imperial' ? (m >= 1609.34 ? (m / 1609.34).toFixed(2) + ' mi' : Math.round(m * 3.28084) + ' ft') : UNITS() === 'nautical' ? (m >= 1852 ? (m / 1852).toFixed(2) + ' NM' : Math.round(m) + ' m') : m >= 1000 ? (m / 1000).toFixed(2) + ' km' : Math.round(m) + ' m';
const fmtV = kmh => UNITS() === 'imperial' ? (kmh / 1.609344).toFixed(1) + ' mph' : UNITS() === 'nautical' ? (kmh / 1.852).toFixed(1) + ' kn' : kmh.toFixed(1) + ' km/h';
const fmtAng = d => S.set.angle === 'mils' ? Math.round(d * 6400 / 360) + ' mil' : Math.round(d) + '°';
const fmtA = a => UNITS() === 'imperial' ? (a >= 2589988 ? (a / 2589988).toFixed(3) + ' mi²' : (a / 4046.86).toFixed(2) + ' ac') : a >= 1e6 ? (a / 1e6).toFixed(3) + ' km²' : a >= 1e4 ? (a / 1e4).toFixed(2) + ' ha' : Math.round(a) + ' m²';
const fmtT = ms => { const s = Math.max(0, Math.round(ms / 1000)); return [Math.floor(s / 3600), Math.floor(s % 3600 / 60), s % 60].map(n => String(n).padStart(2, '0')).join(':'); };
function dms(v, pos, neg) { const h = v < 0 ? neg : pos; v = Math.abs(v); const d = Math.floor(v), m = Math.floor((v - d) * 60), s = ((v - d) * 60 - m) * 60; return `${d}°${String(m).padStart(2, '0')}'${s.toFixed(1).padStart(4, '0')}"${h}`; }
const WGS = (() => { const a = 6378137, f = 1 / 298.257223563, e2 = f * (2 - f); return { a, e2, ep2: e2 / (1 - e2), k0: .9996 }; })();
function utmObj(lat, lon, forceZone, cm) { // cm: optional central meridian in degrees (local map plane); omit for normal UTM
  const { a, e2, ep2, k0 } = WGS;
  const zone = forceZone || Math.floor((lon + 180) / 6) + 1, l0 = rad(cm !== undefined ? cm : (zone - 1) * 6 - 180 + 3), p = rad(lat), l = rad(lon);
  const N = a / Math.sqrt(1 - e2 * Math.sin(p) ** 2), T = Math.tan(p) ** 2, C = ep2 * Math.cos(p) ** 2, A = Math.cos(p) * (l - l0);
  const M = a * ((1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256) * p - (3 * e2 / 8 + 3 * e2 ** 2 / 32 + 45 * e2 ** 3 / 1024) * Math.sin(2 * p) + (15 * e2 ** 2 / 256 + 45 * e2 ** 3 / 1024) * Math.sin(4 * p) - 35 * e2 ** 3 / 3072 * Math.sin(6 * p));
  const E = k0 * N * (A + (1 - T + C) * A ** 3 / 6 + (5 - 18 * T + T * T + 72 * C - 58 * ep2) * A ** 5 / 120) + 5e5;
  let Nn = k0 * (M + N * Math.tan(p) * (A * A / 2 + (5 - T + 9 * C + 4 * C * C) * A ** 4 / 24 + (61 - 58 * T + T * T + 600 * C - 330 * ep2) * A ** 6 / 720));
  if (lat < 0) Nn += 1e7;
  return { zone, south: lat < 0, E, N: Nn };
}
function utmInv(zone, south, E, N, cm) {
  const { a, e2, ep2, k0 } = WGS, e1 = (1 - Math.sqrt(1 - e2)) / (1 + Math.sqrt(1 - e2));
  const x = E - 5e5, y = south ? N - 1e7 : N, mu = y / k0 / (a * (1 - e2 / 4 - 3 * e2 ** 2 / 64 - 5 * e2 ** 3 / 256));
  const p1 = mu + (3 * e1 / 2 - 27 * e1 ** 3 / 32) * Math.sin(2 * mu) + (21 * e1 ** 2 / 16 - 55 * e1 ** 4 / 32) * Math.sin(4 * mu) + 151 * e1 ** 3 / 96 * Math.sin(6 * mu) + 1097 * e1 ** 4 / 512 * Math.sin(8 * mu);
  const C1 = ep2 * Math.cos(p1) ** 2, T1 = Math.tan(p1) ** 2, N1 = a / Math.sqrt(1 - e2 * Math.sin(p1) ** 2), R1 = a * (1 - e2) / (1 - e2 * Math.sin(p1) ** 2) ** 1.5, D = x / (N1 * k0);
  const lat = p1 - N1 * Math.tan(p1) / R1 * (D * D / 2 - (5 + 3 * T1 + 10 * C1 - 4 * C1 * C1 - 9 * ep2) * D ** 4 / 24 + (61 + 90 * T1 + 298 * C1 + 45 * T1 * T1 - 252 * ep2 - 3 * C1 * C1) * D ** 6 / 720);
  const lon = rad(cm !== undefined ? cm : (zone - 1) * 6 - 180 + 3) + (D - (1 + 2 * T1 + C1) * D ** 3 / 6 + (5 - 2 * C1 + 28 * T1 - 3 * C1 * C1 + 8 * ep2 + 24 * T1 * T1) * D ** 5 / 120) / Math.cos(p1);
  return [deg(lat), deg(lon)];
}
const mercInv = (x, y) => [deg(2 * Math.atan(Math.exp(y / 6378137)) - Math.PI / 2), deg(x / 6378137)];
const utm = (lat, lon) => { const u = utmObj(lat, lon); return `${u.zone}${u.south ? 'S' : 'N'} ${Math.round(u.E)} E ${Math.round(u.N)} N`; };
function mgrs(lat, lon) {
  if (lat < -80 || lat > 84) return 'outside MGRS';
  const u = utmObj(lat, lon), band = 'CDEFGHJKLMNPQRSTUVWXX'[Math.floor((lat + 80) / 8)], set = (u.zone - 1) % 6 + 1;
  const col = ['ABCDEFGH', 'JKLMNPQR', 'STUVWXYZ'][(set - 1) % 3][Math.floor(u.E / 1e5) - 1];
  let row = Math.floor(u.N / 1e5) % 20; if (set % 2 === 0) row = (row + 5) % 20;
  const pad = v => String(Math.floor(v % 1e5)).padStart(5, '0');
  return `${u.zone}${band} ${col}${'ABCDEFGHJKLMNPQRSTUV'[row]} ${pad(u.E)} ${pad(u.N)}`;
}
const ddPlace = () => { const z = (typeof map !== 'undefined' && map) ? map.getZoom() : 12; return z >= 16 ? 6 : z >= 13 ? 5 : z >= 10 ? 4 : 3; }; // match the precision to what the screen can show
const fmtC = (lat, lon) => { const n = ddPlace(); return ({ dms: () => `${dms(lat, 'N', 'S')} ${dms(lon, 'E', 'W')}`, utm: () => utm(lat, lon), mgrs: () => mgrs(lat, lon) }[S.set.coord] || (() => `${lat.toFixed(n)}, ${lon.toFixed(n)}`))(); };
function fitAffine(pts, key) { // least squares: value = A*x + B*y + C
  let sxx = 0, sxy = 0, syy = 0, sx = 0, sy = 0, n = pts.length, sv = 0, sxv = 0, syv = 0;
  for (const p of pts) { sxx += p.x * p.x; sxy += p.x * p.y; syy += p.y * p.y; sx += p.x; sy += p.y; sv += p[key]; sxv += p.x * p[key]; syv += p.y * p[key]; }
  const M = [[sxx, sxy, sx], [sxy, syy, sy], [sx, sy, n]], V = [sxv, syv, sv];
  const det = m => m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1]) - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0]) + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
  const D = det(M); if (Math.abs(D) < 1e-18) return null;
  return [0, 1, 2].map(c => det(M.map((r, i) => r.map((v, j) => j === c ? V[i] : v))) / D);
}
// image maps: corners = [topLeft, topRight, bottomLeft] as [lat, lon]
const brOf = c => [c[1][0] + c[2][0] - c[0][0], c[1][1] + c[2][1] - c[0][1]];
const ovBounds = o => o.type === 'tiles' ? L.latLngBounds(o.bounds) : L.latLngBounds([...o.corners, brOf(o.corners)]);
function toUV(c, ll) { const ax = c[1][0] - c[0][0], ay = c[1][1] - c[0][1], bx = c[2][0] - c[0][0], by = c[2][1] - c[0][1], dx = ll[0] - c[0][0], dy = ll[1] - c[0][1], D = ax * by - ay * bx; return [(dx * by - dy * bx) / D, (ax * dy - ay * dx) / D]; }
const onMapO = (o, ll) => { if (o.type === 'tiles') return L.latLngBounds(o.bounds).contains([ll[0], ll[1]]); const [u, v] = toUV(o.corners, ll); return u >= 0 && u <= 1 && v >= 0 && v <= 1; };

// ---------- map ----------
const BASES = {
  osm: { n: 'Streets (OpenStreetMap)', u: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', max: 19, att: '© OpenStreetMap' },
  topo: { n: 'Topographic / hiking (OpenTopoMap)', u: 'https://a.tile.opentopomap.org/{z}/{x}/{y}.png', max: 17, att: '© OpenTopoMap, © OSM' },
  sat: { n: 'Satellite (Esri)', u: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', max: 19, att: 'Esri World Imagery' },
  hyb: { n: 'Hybrid: satellite + names (Esri)', u: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', over: 'https://server.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}', max: 19, att: 'Esri' },
  etopo: { n: 'Topographic (Esri)', u: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}', max: 19, att: 'Esri World Topo' },
  dgray: { n: 'Night map (Esri Dark Gray, with labels)', u: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/{z}/{y}/{x}', over: 'https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Reference/MapServer/tile/{z}/{y}/{x}', max: 16, att: 'Esri' },
  none: { n: 'None (my maps only)', u: '', max: 19 }
};
// night twins: when the app is in night mode the base map follows, unless the user picks a night map themselves
const NIGHT = { osm: 'dgray', voyager: 'dgray', hot: 'dgray', cyclosm: 'dgray', estreet: 'dgray', topo: 'dgray', etopo: 'dgray', sat: 'sat', hyb: 'hyb', s2new: 's2new', s2y: 's2y', wb: 'wb', gibs: 'gibs', none: 'none' };
const IMAGERY = ['sat', 'hyb', 's2new', 's2y', 'wb', 'gibs'];
const themePref = () => localStorage.getItem('theme') || 'auto';
const isDarkTheme = () => { const t = themePref(); return t === 'dark' || (t === 'auto' && matchMedia('(prefers-color-scheme: dark)').matches); };
const nightOn = () => S.set.nightMap !== false && isDarkTheme();
const map = L.map('map', { zoomControl: false, attributionControl: false, maxZoom: 22, rotate: !!L.Map.prototype.setBearing, bearing: 0, touchRotate: false, rotateControl: false, shiftKeyRotate: false, compassBearing: false });
map.createPane('maps').style.zIndex = 350;
L.control.scale({ imperial: false, position: 'bottomleft' }).addTo(map);
const lv = JSON.parse(localStorage.getItem('view') || '[4.2,102,7]');
map.setView([lv[0], lv[1]], lv[2]);
let baseLayer, baseOver;
function setBase(k, opt) {
  const want = k || S.set.base;
  const use = (S.set.nightMap !== false && isDarkTheme() && NIGHT[want]) ? NIGHT[want] : want;
  const b = BASES[use]; if (!b) return;
  if (b.vec && typeof protomapsL === 'undefined') { loadScript('lib/protomaps-leaflet.js').then(() => setBase(k, opt), () => toast('Could not load the vector map engine')); return; } // vector maps: engine loaded on first use
  if (baseLayer) map.removeLayer(baseLayer); if (baseOver) map.removeLayer(baseOver); baseLayer = baseOver = null;
  if (b.over) baseOver = L.tileLayer(b.over, { maxNativeZoom: b.max, maxZoom: 22, crossOrigin: true, zIndex: 2 }).addTo(map);
  if (b.u) { baseLayer = (b.vec ? protomapsL.leafletLayer({ url: b.u, flavor: b.flavor || 'light', maxDataZoom: b.max, maxNativeZoom: b.max, maxZoom: 22, attribution: b.att }) : L.tileLayer(b.u, { maxNativeZoom: b.max, maxZoom: 22, crossOrigin: true, attribution: b.att, errorTileUrl: '' })).addTo(map); baseLayer.bringToBack(); }
  $('#map').classList.toggle('dim', S.set.nightMap !== false && isDarkTheme() && IMAGERY.includes(use));
  if (!opt || opt.persist !== false) { S.set.base = want; save.set(); }
}
function applyTheme() {
  document.documentElement.dataset.theme = themePref();
  try { setBase(S.set.base, { persist: false }); } catch (e) { }
}
matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (themePref() === 'auto') applyTheme(); });
const gTracks = L.layerGroup().addTo(map), gWpts = L.layerGroup().addTo(map), gOv = L.layerGroup().addTo(map);
function onMove() {
  const c = map.getCenter();
  $('#coord').innerHTML = `<b>${esc(fmtC(c.lat, c.lng))}</b><small>${{ dd: 'Lat, lon', dms: 'DMS', utm: 'UTM', mgrs: 'MGRS' }[S.set.coord] || 'Lat, lon'} · zoom ${map.getZoom()} · tap to change</small>`;
  $('#coord').title = 'Tap to change the coordinate format';
  localStorage.setItem('view', JSON.stringify([+c.lat.toFixed(5), +c.lng.toFixed(5), map.getZoom()]));
}
const COORD_CYCLE = [['dd', 'Lat, lon'], ['dms', 'DMS'], ['utm', 'UTM'], ['mgrs', 'MGRS']];
function cycleCoord() {
  const i = COORD_CYCLE.findIndex(x => x[0] === S.set.coord), nx = COORD_CYCLE[(i + 1) % COORD_CYCLE.length];
  S.set.coord = nx[0]; save.set(); onMove();
  const t = $('#coord'); t.animate ? t.animate([{ transform: 'scale(.97)' }, { transform: 'scale(1)' }], { duration: 180, easing: 'ease-out' }) : 0;
  toast('Coordinates: ' + nx[1] + (nx[0] === 'dd' ? ' (decimal degrees)' : ''), 2200);
}
$('#coord').addEventListener('click', cycleCoord);
map.on('move', onMove); onMove();
map.on('zoomend', () => { if (S.wpts.length > 250 && wptMode !== (map.getZoom() < 17)) drawWpts(); });

// image placed by 3 corners (supports rotation/skew, like a photographed paper map)
const AffineImage = L.Layer.extend({
  initialize(url, corners, opt) { this._url = url; this._c = corners; L.setOptions(this, opt); },
  onAdd(m) {
    const i = this._img = L.DomUtil.create('img', 'leaflet-image-layer ' + (m._zoomAnimated ? 'leaflet-zoom-animated' : 'leaflet-zoom-hide'));
    Object.assign(i.style, { position: 'absolute', left: 0, top: 0, transformOrigin: '0 0', opacity: this.options.opacity ?? 1, pointerEvents: 'none', maxWidth: 'none' });
    i.onload = () => this._reset(); i.src = this._url; m.getPane('maps').appendChild(i);
    m.on('zoomend viewreset', this._reset, this); if (m._zoomAnimated) m.on('zoomanim', this._anim, this);
  },
  onRemove(m) { this._img.remove(); m.off('zoomend viewreset', this._reset, this); m.off('zoomanim', this._anim, this); },
  setCorners(c) { this._c = c; this._reset(); }, setOpacity(o) { this.options.opacity = o; if (this._img) this._img.style.opacity = o; },
  _set(f) {
    const i = this._img, W = i.naturalWidth, H = i.naturalHeight; if (!W) return;
    const a = f(this._c[0]), b = f(this._c[1]), c = f(this._c[2]);
    i.style.transform = `matrix(${(b.x - a.x) / W},${(b.y - a.y) / W},${(c.x - a.x) / H},${(c.y - a.y) / H},${a.x},${a.y})`;
  },
  _reset() { this._set(p => this._map.latLngToLayerPoint(p)); },
  _anim(e) { this._set(p => this._map._latLngToNewLayerPoint(L.latLng(p), e.zoom, e.center)); }
});
// tiles stored in Cache Storage (MBTiles import), loaded without needing the service worker
const MBT_CACHE = 'mbtiles-v1';
const CacheTiles = L.TileLayer.extend({
  createTile(c, done) {
    const img = document.createElement('img'); img.alt = ''; const url = this.getTileUrl(c);
    caches.open(MBT_CACHE).then(ca => ca.match(url)).then(r => r ? r.blob() : null).then(b => {
      if (!b) return done(null, img); img.onload = () => { URL.revokeObjectURL(img.src); done(null, img); }; img.src = URL.createObjectURL(b);
    }).catch(e => done(e, img));
    return img;
  }
});

// ---------- tracks, lines, areas & waypoints: drawing ----------
const feat = t => t.pts.map(p => [p[0], p[1]]);
function legendSym(t) { // map-legend swatch: solid line = track, dashed = route, hatched box = area
  const c = esc(t.color), w = el('span', { class: 'sym' });
  w.innerHTML = t.kind === 'area' ? `<svg width="26" height="16" viewBox="0 0 26 16"><defs><pattern id="h${t.id}" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><path d="M0 0v4" stroke="${c}" stroke-width="1.6"/></pattern></defs><rect x="1" y="1" width="24" height="14" rx="2" fill="url(#h${t.id})" stroke="${c}" stroke-width="2"/></svg>`
    : `<svg width="28" height="12" viewBox="0 0 28 12"><path d="M2 9 C8 1, 14 11, 26 3" fill="none" stroke="${c}" stroke-width="3.2" stroke-linecap="round"${t.kind === 'line' ? ' stroke-dasharray="5 4"' : ''}/></svg>`;
  return w;
}
const pinSym = w => { const s = el('span', { class: 'sym', style: 'position:relative;width:30px;height:34px' }); s.innerHTML = `<svg width="28" height="34" viewBox="0 0 24 28"><path d="M12 27s-10-8.6-10-16a10 10 0 0 1 20 0c0 7.4-10 16-10 16Z" fill="${esc(w.color)}" stroke="#fff" stroke-width="2"/><circle cx="12" cy="11" r="3" fill="#fff"/></svg>`; return s; };
function drawTracks() {
  gTracks.clearLayers();
  for (const t of S.tracks) {
    if (t.hidden || t.pts.length < 2) continue;
    const opt = { color: t.color, weight: t.weight || (t.kind === 'track' || !t.kind ? 4 : 3), opacity: .9, interactive: !meas.on };
    const l = (t.kind === 'area' ? L.polygon(feat(t), { ...opt, fillOpacity: t.fill ?? .18 }) : L.polyline(feat(t), t.kind === 'line' ? { ...opt, dashArray: '8 6' } : opt)).addTo(gTracks);
    l.bindPopup(() => el('div', {}, el('b', {}, t.name), el('br'), el('span', { class: 'mut' }, featSummary(t)),
      el('button', { class: 'btn sm', onclick: () => { map.closePopup(); editFeature(t, 'track'); } }, 'Details'),
      el('button', { class: 'btn sm', onclick: () => { map.closePopup(); startNav({ lat: t.pts[0][0], lon: t.pts[0][1], name: 'start of ' + t.name }); } }, 'Go to start')));
  }
}
function featSummary(t) {
  if (t.kind === 'area') return `Area ${fmtA(areaOf(t.pts))} · perimeter ${fmtD(pathLen([...t.pts, t.pts[0]]))}`;
  const d = pathLen(t.pts); if (t.kind !== 'line') return fmtD(d);
  let up = 0, pr = null; for (const p of t.pts) if (p[2] != null) { if (pr != null && p[2] > pr) up += p[2] - pr; pr = p[2]; }
  const walk = (d / 5000 + up / 600) * 36e5; // Naismith: 5 km/h + 1 h per 600 m climb
  return fmtD(d) + ` · walk ≈ ${fmtT(walk)}` + (t.drive ? ` · drive ≈ ${fmtT(t.drive * 1000)}` : '') + (pr != null ? ` · ↗ ${Math.round(up)} m` : '');
}
const wptCanvas = L.canvas({ padding: .3 });
let wptMode = null;
function drawWpts() {
  gWpts.clearLayers(); const many = S.wpts.length > 250 && map.getZoom() < 17; wptMode = many;
  for (const w of S.wpts) {
    if (w.hidden) continue;
    if (many) { L.circleMarker([w.lat, w.lon], { renderer: wptCanvas, radius: 6, weight: 2, color: '#fff', fillColor: w.color, fillOpacity: 1, interactive: !meas.on }).bindPopup(() => wptPopup(w), { minWidth: 200 }).addTo(gWpts); continue; }
    const lab = S.set.labels ? `<div class="wpl">${esc(w.name)}</div>` : '';
    const bd = w.st && typeof STATUS !== 'undefined' && STATUS[w.st] ? `<i class="sbd" style="background:${STATUS[w.st].c}"></i>` : '';
    const m = L.marker([w.lat, w.lon], { interactive: !meas.on, icon: L.divIcon({ className: '', html: `<div class="wp" style="background:${esc(w.color)}">${bd}<span></span></div>${lab}`, iconSize: [26, 26], iconAnchor: [13, 30], popupAnchor: [0, -28] }) }).addTo(gWpts);
    m.bindPopup(() => wptPopup(w), { minWidth: 200 });
  }
}
function wptPopup(w) {
  const th = el('div', { class: 'thumbs' });
  (w.photos || []).forEach(async id => { const u = await photoURL(id); if (u) th.append(el('img', { src: u, alt: '', onclick: () => viewPhoto(w, id) })); });
  return el('div', {}, el('b', {}, w.name), el('div', { class: 'mut' }, fmtC(w.lat, w.lon)), w.address ? el('div', { class: 'mut' }, w.address) : '', w.note ? el('div', {}, w.note) : '',
    w.st ? el('div', { style: 'margin:5px 0 2px' }, stChip(w.st)) : '',
    w.by ? el('div', { class: 'mut' }, 'Assigned to ' + w.by) : '',
    ...Object.entries(w.attrs || {}).map(([k, v]) => el('div', { class: 'mut' }, k + ': ' + v)), th,
    el('button', { class: 'btn sm', onclick: () => { map.closePopup(); statusUI(w); } }, w.st ? 'Change status' : 'Set work status'),
    el('button', { class: 'btn sm go', onclick: () => { map.closePopup(); startNav(w); } }, 'Go to (compass)'),
    el('button', { class: 'btn sm', onclick: () => { map.closePopup(); editFeature(w, 'wpt'); } }, 'Edit / photos'),
    el('button', { class: 'btn sm', onclick: () => gmaps(w) }, 'Directions (Google Maps)'));
}
const gmaps = w => window.open(`https://www.google.com/maps/dir/?api=1&destination=${w.lat},${w.lon}`, '_blank');
function addWpt(lat, lon, o = {}) {
  const w = { id: uid(), name: o.name || 'Waypoint ' + (S.wpts.length + 1), note: '', lat, lon, color: o.color || COLORS[S.wpts.length % COLORS.length], icon: o.icon || '📍', folder: o.folder || '', attrs: {}, photos: o.photos || [], t: Date.now() };
  S.wpts.push(w); save.wpts(); drawWpts(); if (tab === 'wpts') render(); return w;
}

// ---------- modal & feature editor (Avenza placemark / NomadTracks POI) ----------
function modal(title, ...content) {
  const m = $('#modal'), box = m.firstChild;
  box.replaceChildren(el('div', { class: 'mhead' }, el('h3', {}, title), xBtn('Close', () => { const c = [...box.querySelectorAll('.act button')].find(b => /^(cancel|close|back)$/i.test(b.textContent.trim())); c ? c.click() : closeModal(); })), ...content.flat(3).filter(x => x != null && x !== false && x !== '')); m.hidden = false;
  box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', title);
  m.onclick = e => { if (e.target === m) closeModal(); };
  setTimeout(() => { if (!box.contains(document.activeElement)) { const f = box.querySelector('input,select,textarea,.btn,.choice'); f && f.focus({ preventScroll: true }); } }, 40);
  return box;
}
const closeModal = () => { $('#modal').hidden = true; $('#modal').firstChild.replaceChildren(); };
const folders = () => [...new Set([...S.tracks, ...S.wpts, ...S.overlays].map(x => x.folder).filter(Boolean))].sort();
const attrKeys = () => [...new Set([...S.tracks, ...S.wpts].flatMap(x => Object.keys(x.attrs || {})))].sort();
async function resizeImg(file, max = 1600) {
  const bm = await createImageBitmap(file), s = Math.min(1, max / Math.max(bm.width, bm.height)), c = el('canvas');
  c.width = Math.round(bm.width * s); c.height = Math.round(bm.height * s); c.getContext('2d').drawImage(bm, 0, 0, c.width, c.height);
  return new Promise(r => c.toBlob(r, 'image/jpeg', .85));
}
async function exifGPS(file) { // read GPS position from a JPEG's EXIF
  try {
    const b = new DataView(await file.slice(0, 262144).arrayBuffer()); if (b.getUint16(0) !== 0xFFD8) return null; let o = 2;
    while (o < b.byteLength - 10) {
      const mk = b.getUint16(o), len = b.getUint16(o + 2);
      if (mk === 0xFFE1 && b.getUint32(o + 4) === 0x45786966) {
        const t = o + 10, le = b.getUint16(t) === 0x4949, u16 = p => b.getUint16(p, le), u32 = p => b.getUint32(p, le);
        const ifd = t + u32(t + 4); let gps = 0;
        for (let i = 0, n = u16(ifd); i < n; i++) { const e = ifd + 2 + i * 12; if (u16(e) === 0x8825) gps = t + u32(e + 8); }
        if (!gps) return null; const g = {};
        for (let i = 0, n = u16(gps); i < n; i++) {
          const e = gps + 2 + i * 12, tag = u16(e), type = u16(e + 2);
          if (type === 2) g[tag] = String.fromCharCode(b.getUint8(e + 8)); else if (type === 5) { const vo = t + u32(e + 8); g[tag] = [0, 1, 2].map(k => u32(vo + k * 8) / u32(vo + k * 8 + 4)); }
        }
        if (!g[2] || !g[4]) return null; const dd = v => v[0] + v[1] / 60 + v[2] / 3600;
        const lat = dd(g[2]) * (g[1] === 'S' ? -1 : 1), lon = dd(g[4]) * (g[3] === 'W' ? -1 : 1);
        return isFinite(lat) && isFinite(lon) && (lat || lon) ? [lat, lon] : null;
      }
      if ((mk & 0xFF00) !== 0xFF00) break; o += 2 + len;
    }
  } catch (e) { }
  return null;
}
async function storePhoto(file) { const id = uid(); await kvSet('ph:' + id, await resizeImg(file)); return id; }
async function photoWpt(file) { // Avenza "photo placemark": position from EXIF, else GPS, else map centre
  const g = await exifGPS(file), c = map.getCenter(), pos = g || (last ? [last.lat, last.lon] : [c.lat, c.lng]);
  const w = addWpt(pos[0], pos[1], { name: 'Photo ' + new Date().toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' }), icon: '📷', folder: 'Photos', photos: [await storePhoto(file)] });
  save.wpts(); drawWpts(); map.setView(pos, Math.max(map.getZoom(), 16));
  toast(g ? 'Photo placed using its GPS tag' : last ? 'Photo placed at your GPS position' : 'Photo placed at map centre (no GPS)'); editFeature(w, 'wpt');
}
async function viewPhoto(f, id) {
  const u = await photoURL(id);
  modal('📷 ' + f.name, el('div', { class: 'photo' }, el('img', { src: u, alt: '' }), el('div', { class: 'meta' }, `${f.name} · ${f.lat != null ? fmtC(f.lat, f.lon) : ''} · ${new Date(f.t || f.created || Date.now()).toLocaleString('en-GB')}`)),
    el('div', { class: 'row' }, el('a', { class: 'btn', href: u, download: fname(f.name) + '.jpg' }, 'Save'), el('button', { class: 'btn', onclick: closeModal }, 'Close')));
}
function editFeature(f, kind) { // kind: 'wpt' | 'track'
  const isW = kind === 'wpt', attrs = { ...(f.attrs || {}) }, photos = [...(f.photos || [])];
  let color = f.color;
  const name = el('input', { type: 'text', value: f.name }), note = el('textarea', {}, f.note || '');
  const dlF = el('datalist', { id: 'dlF' }, folders().map(x => el('option', { value: x }))), folder = el('input', { type: 'text', value: f.folder || '', list: 'dlF', placeholder: 'e.g. Block 04, Survey Nov' });
  const sws = el('div', { class: 'row' }), at = el('div'), th = el('div', { class: 'thumbs' }), sch = el('div');
  let stVal = f.st || '';
  const crewNames = [...new Set([...S.wpts, ...S.tracks].map(x => (x.by || '').trim()).filter(Boolean))];
  const dlB = el('datalist', { id: 'dlB' }, crewNames.map(x => el('option', { value: x })));
  const byInp = el('input', { type: 'text', value: f.by || '', list: 'dlB', placeholder: 'e.g. Ali, Team B' });
  const stRow = el('div', { class: 'segs' });
  const drawSt = () => stRow.replaceChildren(...['', ...typeof STATUS !== 'undefined' ? Object.keys(STATUS) : []].map(k => el('button', { class: stVal === k ? 'on' : '', onclick: () => { stVal = k; drawSt(); } }, k ? STATUS[k].n : 'None')));
  drawSt();
  const schema = () => S.schemas[folder.value.trim()] || [];
  const drawSch = () => { sch.replaceChildren(...schema().map(fd => { const v = attrs[fd.name] ?? '', set = x => attrs[fd.name] = x;
    const inp = fd.type === 'picklist' ? el('select', { onchange: e => set(e.target.value) }, el('option', { value: '' }, '—'), (fd.options || []).map(o => el('option', { value: o }, o)))
      : fd.type === 'yesno' ? el('select', { onchange: e => set(e.target.value) }, ['', 'Yes', 'No'].map(o => el('option', { value: o }, o || '—')))
      : el('input', { type: fd.type === 'number' ? 'number' : fd.type === 'date' ? 'date' : 'text', step: 'any', oninput: e => set(e.target.value) });
    inp.value = v; return [el('label', {}, fd.name + (fd.type !== 'text' ? ` (${fd.type})` : '')), inp]; }).flat()); drawAt(); };
  const swNote = el('div', { class: 'mut', style: 'font-size:12.5px;margin-top:6px;align-items:center;gap:7px;display:none' });
  const drawSw = () => {
    sws.replaceChildren(...COLORS.map(c => el('button', { class: 'sw' + (c === color ? ' on' : ''), style: 'background:' + c, title: c, 'aria-label': 'Colour ' + c, onclick: () => { color = c; drawSw(); } })));
    if (COLORS.includes(color)) { swNote.style.display = 'none'; swNote.replaceChildren(); return; }
    swNote.style.display = 'flex';
    swNote.replaceChildren(el('i', { style: `width:11px;height:11px;border-radius:50%;background:${esc(color)};box-shadow:0 0 0 1.5px rgba(0,0,0,.14);flex:none` }), el('span', {}, 'Old colour — choose one of the three above to update it.'));
  };
  const dlK = el('datalist', { id: 'dlK' }, attrKeys().map(x => el('option', { value: x })));
  const drawAt = () => at.replaceChildren(...Object.entries(attrs).filter(([k]) => !schema().some(fd => fd.name === k)).map(([k, v]) => el('div', { class: 'row', style: 'flex-wrap:nowrap' },
    el('input', { type: 'text', value: k, list: 'dlK', style: 'flex:1', onchange: e => { const nv = e.target.value.trim(); delete attrs[k]; if (nv) attrs[nv] = v; drawAt(); } }),
    el('input', { type: 'text', value: v, style: 'flex:1', oninput: e => attrs[k] = e.target.value }),
    el('button', { class: 'btn sm dng', onclick: () => { delete attrs[k]; drawAt(); } }, '✕'))));
  const drawTh = () => { th.replaceChildren(); photos.forEach(async id => { const u = await photoURL(id); th.append(el('div', { style: 'position:relative' }, el('img', { src: u, alt: '', onclick: () => viewPhoto({ ...f, name: name.value }, id) }), el('button', { class: 'btn sm dng', style: 'position:absolute;top:0;right:0;padding:0 5px', onclick: () => { photos.splice(photos.indexOf(id), 1); drawTh(); } }, '✕'))); }); };
  const addPh = cap => { const i = el('input', { type: 'file', accept: 'image/*', hidden: '' }); if (cap) i.setAttribute('capture', 'environment'); i.multiple = !cap; i.onchange = async () => { for (const x of i.files) photos.push(await storePhoto(x)); drawTh(); }; document.body.append(i); i.click(); setTimeout(() => i.remove(), 60000); };
  const lat = el('input', { type: 'number', step: 'any', value: f.lat, 'data-k': 'lat' }), lon = el('input', { type: 'number', step: 'any', value: f.lon, 'data-k': 'lon' }), addr = el('div', { class: 'mut' }, f.address || '');
  folder.oninput = drawSch; drawSw(); drawSch(); drawTh();
  modal(isW ? 'Waypoint details' : (f.kind === 'area' ? 'Area' : f.kind === 'line' ? 'Line / route' : 'Track') + ' details',
    el('label', {}, 'Name'), name,
    isW ? '' : [el('div', { class: 'mut' }, featSummary(f)), f.kind !== 'area' && !f.pts.some(p => p[2] != null) ? el('button', { class: 'btn sm', style: 'margin-top:8px', onclick: async () => { await fetchElevation(f); closeModal(); editFeature(f, kind); } }, 'Add elevation (needs internet)') : ''],
    el('label', {}, 'Colour'), sws, swNote, isW ? [el('label', {}, 'Work status'), stRow, el('label', {}, 'Assigned to (crew)'), byInp, dlB] : '', el('label', {}, 'Folder (layer)'), folder, dlF, sch, el('label', {}, 'Notes'), note,
    el('label', {}, 'Other fields'), at, dlK, el('button', { class: 'btn sm', onclick: () => { let k = 'Field ' + (Object.keys(attrs).length + 1); attrs[k] = ''; drawAt(); } }, '+ Add field'),
    el('label', {}, 'Photos'), th, el('div', { class: 'row' }, el('button', { class: 'btn sm', onclick: () => addPh(true) }, 'Camera'), el('button', { class: 'btn sm', onclick: () => addPh(false) }, 'Gallery')),
    isW ? [el('label', {}, 'Position (latitude, longitude)'), el('div', { class: 'row', style: 'flex-wrap:nowrap' }, lat, lon), el('div', { class: 'mut' }, fmtC(f.lat, f.lon)), addr,
      el('button', { class: 'btn sm', onclick: async () => { addr.textContent = 'Looking up…'; try { const r = await (await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat.value}&lon=${lon.value}`)).json(); addr.textContent = r.display_name || 'No address found'; } catch (e) { addr.textContent = 'Address lookup needs internet'; } } }, 'Find address')] : '',
    el('div', { class: 'row act' },
      el('button', { class: 'btn pri', onclick: () => {
        f.name = name.value.trim() || f.name; f.note = note.value; f.folder = folder.value.trim(); f.color = color; f.attrs = attrs;
        f.by = byInp.value.trim() || undefined;
        if (isW) { f.st = stVal || undefined; f.tu = Date.now(); }
        (f.photos || []).filter(id => !photos.includes(id)).forEach(id => kvDel('ph:' + id)); f.photos = photos;
        if (isW) { const la = +lat.value, lo = +lon.value; if (isFinite(la) && isFinite(lo) && Math.abs(la) <= 90 && Math.abs(lo) <= 180) { f.lat = la; f.lon = lo; } if (addr.textContent && !/Looking|needs|No address/.test(addr.textContent)) f.address = addr.textContent; }
        isW ? (save.wpts(), drawWpts()) : (save.tracks(), drawTracks()); closeModal(); render(); toast('Saved');
      } }, 'Save'),
      el('button', { class: 'btn', onclick: () => shareMenu(f, kind) }, 'Share'),
      el('button', { class: 'btn', onclick: closeModal }, 'Cancel'),
      el('button', { class: 'btn dng', onclick: () => { if (confirm('Delete "' + f.name + '"?')) { delFeature(f, kind); closeModal(); } } }, 'Delete')));
}
function delFeature(f, kind) {
  (f.photos || []).forEach(id => kvDel('ph:' + id));
  if (kind === 'wpt') { S.wpts = S.wpts.filter(x => x !== f); save.wpts(); drawWpts(); } else { S.tracks = S.tracks.filter(x => x !== f); save.tracks(); drawTracks(); }
  if (nav.t === f) stopNav(); render();
}

// ---------- GPS, compass & recording ----------
let watchId = null, me = null, acc = null, last = null, follow = false, wake = null, compass = null;
const rec = { on: false, paused: false, pts: [], t0: 0, pauseAcc: 0, pauseAt: 0, line: null, id: null };
const posHist = []; let derived = null, compassSeen = false; // derived: direction of travel worked out from the last positions
function updateDerived(ll, t, acc_) {
  posHist.push([ll[0], ll[1], t]); while (posHist.length > 15 || (posHist.length > 1 && t - posHist[0][2] > 60000)) posHist.shift();
  const need = Math.max(8, acc_ * 1.2); for (const q of posHist) if (t - q[2] < 45000 && hav(q, ll) >= need) { derived = { h: brg(q, ll), t }; break; }
}
const noCompass = () => !compassSeen && localStorage.getItem('noCompass') === '1';
const heading = () => compass ?? (last && last.hdg != null && !isNaN(last.hdg) && last.spd > .5 ? last.hdg : (derived && Date.now() - derived.t < 30000 ? derived.h : null));
function startCompass() {
  if (startCompass.on) return; startCompass.on = true;
  const h = e => {
    let hd = e.webkitCompassHeading != null ? e.webkitCompassHeading : (e.absolute || e.type === 'deviceorientationabsolute') && e.alpha != null ? 360 - e.alpha : null;
    if (hd == null) return; compassSeen = true; if (localStorage.getItem('noCompass')) localStorage.removeItem('noCompass'); compass = (hd + ((screen.orientation && screen.orientation.angle) || 0) + 360) % 360;
    if (!startCompass.raf) startCompass.raf = requestAnimationFrame(() => { startCompass.raf = 0; drawHeading(); navUpdate(); });
  };
  const go = () => addEventListener('ondeviceorientationabsolute' in window ? 'deviceorientationabsolute' : 'deviceorientation', h);
  go(); if (typeof DeviceOrientationEvent !== 'undefined' && DeviceOrientationEvent.requestPermission) DeviceOrientationEvent.requestPermission().then(go).catch(() => { });
  setTimeout(() => { if (!compassSeen) { localStorage.setItem('noCompass', '1'); if (tab === 'more') render(); } }, 4000); // no reading after 4 s: this phone has no compass
}
function drawHeading() { const c = me && me.getElement() && me.getElement().querySelector('.cone'), hd = heading(); if (c) { c.style.display = hd == null ? 'none' : 'block'; if (hd != null) c.style.transform = `rotate(${hd}deg)`; } }
function startGPS() {
  if (!navigator.geolocation) return toast('This device has no GPS');
  startCompass(); if (watchId !== null) return;
  watchId = navigator.geolocation.watchPosition(p => onPos(p), e => { if (e.code === 1) { toast('Location permission is off. Allow location for this site in the browser settings.', 6000); stopGPS(); } else toast('GPS signal weak, still trying…'); }, { enableHighAccuracy: true, maximumAge: 1000, timeout: 30000 });
  $('#fLoc').classList.add('on');
}
function stopGPS() {
  if (rec.on || nav.t) return;
  if (watchId !== null) navigator.geolocation.clearWatch(watchId); watchId = null; follow = false;
  if (me) { map.removeLayer(me); map.removeLayer(acc); me = acc = null; } $('#gps').hidden = true; $('#fLoc').classList.remove('on');
}
function onPos(p) {
  const c = p.coords, ll = [c.latitude, c.longitude];
  last = { lat: ll[0], lon: ll[1], ele: c.altitude, acc: c.accuracy, spd: c.speed, hdg: c.heading, t: p.timestamp };
  if (!me) { me = L.marker(ll, { icon: L.divIcon({ className: '', html: '<div class="me"><i class="cone"></i></div>', iconSize: [18, 18] }), interactive: false, zIndexOffset: 1000 }).addTo(map); acc = L.circle(ll, { radius: c.accuracy, weight: 1, color: '#1D6FB8', fillOpacity: .1, interactive: false }).addTo(map); map.setView(ll, Math.max(map.getZoom(), 16)); follow = true; }
  updateDerived(ll, p.timestamp, c.accuracy); me.setLatLng(ll); acc.setLatLng(ll).setRadius(c.accuracy); drawHeading();
  if (follow) map.panTo(ll, { animate: true });
  const hd = heading(), open = S.overlays.filter(o => !o.hidden), off = open.length && !open.some(o => onMapO(o, ll));
  const g = $('#gps'); g.hidden = false;
  g.innerHTML = `<b>GPS</b> ±${Math.round(c.accuracy)} m` + (c.altitude != null ? `, alt ${Math.round(c.altitude)} m` : '') + (c.speed != null ? `, ${fmtV(c.speed * 3.6)}` : '') + (hd != null ? `, heading ${fmtAng(hd)} ${card(hd)}` : '') + (off ? '<br><span style="color:var(--danger)">You are outside the open map</span>' : '');
  if (rec.on && !rec.paused && c.accuracy <= S.set.maxAcc) {
    const lp = rec.pts[rec.pts.length - 1];
    if (!lp || hav(lp, ll) >= S.set.minDist) {
      rec.pts.push([ll[0], ll[1], c.altitude, p.timestamp]); rec.line.addLatLng(ll);
      if (rec.pts.length % 5 === 0) kvSet('rec', { id: rec.id, pts: rec.pts, t0: rec.t0, pauseAcc: rec.pauseAcc });
    }
  }
  navUpdate();
}
function recBar() {
  const b = $('#recbar'); if (!rec.on) { b.hidden = true; return; } b.hidden = false;
  const el_ = (rec.paused ? rec.pauseAt : Date.now()) - rec.t0 - rec.pauseAcc, d = pathLen(rec.pts);
  b.innerHTML = `<b>${rec.paused ? '⏸ PAUSED' : '● REC'}</b> ${fmtT(el_)} · ${fmtD(d)} · ${rec.pts.length} pts `;
  b.append(el('button', { class: 'btn sm', onclick: pauseRec }, rec.paused ? 'Resume' : 'Pause'), ' ', el('button', { class: 'btn sm dng', onclick: stopRec }, 'Stop'));
}
setInterval(() => recBar(), 1000);
async function startRec(resume) {
  if (rec.on) return stopRec();
  startGPS();
  Object.assign(rec, { on: true, paused: false, pts: resume ? resume.pts : [], t0: resume ? resume.t0 : Date.now(), pauseAcc: resume ? resume.pauseAcc : 0, id: resume ? resume.id : uid() });
  rec.line = L.polyline(rec.pts.map(p => [p[0], p[1]]), { color: '#FF5B1A', weight: 5 }).addTo(map);
  $('#fRec').classList.add('on'); recBar();
  try { wake = await navigator.wakeLock.request('screen'); } catch (e) { /* not supported */ }
  toast('Recording started. Keep the screen on for best accuracy.');
}
function pauseRec() { rec.paused = !rec.paused; if (rec.paused) rec.pauseAt = Date.now(); else rec.pauseAcc += Date.now() - rec.pauseAt; recBar(); }
async function stopRec() {
  if (!rec.on) return; if (rec.paused) pauseRec();
  rec.on = false; map.removeLayer(rec.line); $('#fRec').classList.remove('on'); recBar(); try { wake && wake.release(); } catch (e) { }
  await kvDel('rec');
  if (rec.pts.length < 2) return toast('Track too short, not saved');
  const t = { id: rec.id, kind: 'track', name: 'Track ' + new Date().toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' }), color: COLORS[S.tracks.length % COLORS.length], pts: rec.pts, created: rec.t0, folder: '', attrs: {}, photos: [] };
  S.tracks.push(t); await save.tracks(); drawTracks(); stopGPS(); if (tab === 'tracks') render(); editFeature(t, 'track');
}
function trackStats(t) {
  const pts = t.pts, d = pathLen(pts), t0 = pts[0][3], t1 = pts[pts.length - 1][3];
  let up = 0, down = 0, mx = null, mn = null, prev = null, moving = 0, vmax = 0;
  for (let i = 0; i < pts.length; i++) {
    const p = pts[i];
    if (p[2] != null) { if (prev != null) { const dz = p[2] - prev; dz > 0 ? up += dz : down -= dz; } prev = p[2]; mx = mx == null ? p[2] : Math.max(mx, p[2]); mn = mn == null ? p[2] : Math.min(mn, p[2]); }
    if (i && p[3] && pts[i - 1][3]) { const dt = (p[3] - pts[i - 1][3]) / 1000, v = dt > 0 ? hav(pts[i - 1], p) / dt : 0; if (v > .5 && dt < 120) moving += dt; }
  }
  for (const [, v] of series(t, 'speed')) vmax = Math.max(vmax, v);
  return { d, dur: t0 && t1 ? t1 - t0 : null, moving: moving * 1000, up, down, mx, mn, avg: moving ? d / moving * 3.6 : null, vmax };
}
function series(t, mode) { // [distance m, value]
  const p = t.pts, cd = [0]; for (let i = 1; i < p.length; i++) cd.push(cd[i - 1] + hav(p[i - 1], p[i]));
  if (mode === 'ele') return p.map((q, i) => [cd[i], q[2]]).filter(x => x[1] != null);
  const out = [];
  for (let i = 0; i < p.length; i++) {
    const j = Math.max(0, i - 3), k = Math.min(p.length - 1, i + 3); if (!p[j][3] || !p[k][3]) continue;
    const dt = (p[k][3] - p[j][3]) / 1000; if (dt <= 0) continue; const v = (cd[k] - cd[j]) / dt;
    out.push([cd[i], mode === 'speed' ? v * 3.6 : v > .1 ? Math.min(60, 1000 / v / 60) : 60]);
  }
  return out;
}

// ---------- in-app navigation to a point (distance, bearing, arrow) ----------
const nav = { t: null, arrived: false, line: L.polyline([], { color: '#1D6FB8', weight: 3, dashArray: '8 8', interactive: false }) };
function startFollow(tr) { const p = tr.pts[tr.pts.length - 1]; startNav({ lat: p[0], lon: p[1], name: 'end of ' + tr.name, track: tr }); }
function startNav(t) { nav.t = t; nav.arrived = false; nav.off = false; nav.paused = false; nav.t0 = Date.now(); nav.line.addTo(map); startGPS(); setTab('map'); navUpdate(); }
function stopNav() { nav.t = null; map.removeLayer(nav.line); $('#navbar').hidden = true; }
function navUpdate() {
  if (!nav.t) return; const b = $('#navbar'); b.hidden = false; const stop = el('button', { class: 'btn sm dng', onclick: stopNav }, 'Stop');
  const pause = el('button', { class: 'btn sm', onclick: () => { nav.paused = !nav.paused; navUpdate(); } }, nav.paused ? 'Resume' : 'Pause');
  if (!last) { b.replaceChildren(el('div', { class: 'navtop' }, el('b', {}, nav.t.name)), el('div', { class: 'mut' }, 'Waiting for GPS…'), stop); return; }
  const a = [last.lat, last.lon], hd = heading(); let tg = [nav.t.lat, nav.t.lon], d = hav(a, tg), br = brg(a, tg), extra = '', more = '';
  if (nav.t.track) { // follow along a track: remaining distance, climb, off-route alert, ghost race
    const T = nav.t.track, P = T.pts, k = Math.cos(rad(a[0])), R0 = T.offRadius || 40; let bi = 0, bd = 1e12, bt = 0;
    for (let i = 0; i < P.length - 1; i++) { const ax = (P[i][1] - a[1]) * k, ay = P[i][0] - a[0], bx = (P[i + 1][1] - a[1]) * k, by = P[i + 1][0] - a[0], dx = bx - ax, dy = by - ay, L2 = dx * dx + dy * dy, u = L2 ? Math.max(0, Math.min(1, -(ax * dx + ay * dy) / L2)) : 0, dd = Math.hypot(ax + u * dx, ay + u * dy); if (dd < bd) { bd = dd; bi = i; bt = u; } }
    const offM = bd * 111195, near = [P[bi][0] + bt * (P[bi + 1][0] - P[bi][0]), P[bi][1] + bt * (P[bi + 1][1] - P[bi][1])], total = pathLen(P);
    d = hav(near, P[bi + 1]) + pathLen(P.slice(bi + 1)) + offM;
    let climb = 0; for (let i = bi + 1; i < P.length; i++) if (P[i][2] != null && P[i - 1][2] != null && P[i][2] > P[i - 1][2]) climb += P[i][2] - P[i - 1][2];
    more = `, ${Math.max(0, Math.round((1 - (d - offM) / (total || 1)) * 100))}% done` + (climb ? `, ${fmtD(climb).replace(' km', ' km')} climb left` : '');
    if (T.pts[0][3] && nav.t0) { const done = total - (d - offM); let gi = 0; for (let acc = 0; gi < P.length - 1 && acc + hav(P[gi], P[gi + 1]) < done; gi++) acc += hav(P[gi], P[gi + 1]); const ghost = P[gi][3] - P[0][3], mine = Date.now() - nav.t0, diff = Math.round((ghost - mine) / 1000); if (done > 20) more += diff >= 0 ? `, ${fmtT(diff * 1000)} ahead of ghost` : `, ${fmtT(-diff * 1000)} behind ghost`; }
    const BS = S.wpts.filter(w => w.bk && w.bk.track === T.id).sort((x, y) => x.bk.at - y.bk.at);
    if (BS.length > 1) { const dn = Math.max(0, total - (d - offM)); let k = 0; while (k < BS.length - 1 && BS[k + 1].bk.at <= dn) k++; const nx = BS[k + 1]; more += ` · ${BS[k].name}` + (nx ? ` → ${nx.name} in ${fmtD(Math.max(0, nx.bk.at - dn))}` : ''); }
    let ahead = bi + 1; while (ahead < P.length - 1 && hav(a, P[ahead]) < 25) ahead++; tg = [P[ahead][0], P[ahead][1]]; br = brg(a, tg);
    if (offM > R0) { extra = `<span style="color:var(--danger);font-weight:650">Off route by ${Math.round(offM)} m</span>`; if (!nav.off && !nav.paused) { nav.off = true; navigator.vibrate && navigator.vibrate(400); toast('You are off the route', 3000); } } else nav.off = false;
  }
  nav.line.setLatLngs([a, tg]);
  const eta = last.spd > .3 ? fmtT(d / last.spd * 1000) : null;
  const arrow = el('span', { class: 'arrow', style: `transform:rotate(${hd != null ? br - hd : br - (map.getBearing ? -map.getBearing() : 0)}deg)` }); arrow.innerHTML = '<svg width="44" height="44" viewBox="0 0 24 24"><path d="M12 2 19 21 12 17 5 21Z" fill="currentColor"/></svg>';
  b.replaceChildren(el('div', { class: 'navtop' }, arrow, el('div', {}, el('b', {}, fmtD(d) + (nav.t.track ? ' left' : '')), el('div', { class: 'mut' }, `to ${nav.t.name}`))),
    el('div', { class: 'mut' }, `Bearing ${fmtAng(br)} ${card(br)}` + (eta ? `, arriving in ${eta}` : '') + more + (nav.paused ? '. Alerts paused.' : '') + (hd == null ? (noCompass() ? `. No compass in this phone: head ${card(br)}; the arrow turns as you walk.` : '. Compass off: arrow points to map north.') : '')), el('div', { class: 'row', style: 'margin:4px 0 0' }, pause, stop));
  if (extra) b.insertBefore(el('div'), b.lastChild).innerHTML = extra;
  if (d < 15 && !nav.arrived && !nav.paused) { nav.arrived = true; navigator.vibrate && navigator.vibrate([200, 100, 200]); toast('Arrived at ' + nav.t.name, 4000); }
}

// ---------- measure / draw lines & areas / route planning ----------
const meas = { on: false, segs: [], roads: false, line: L.polyline([], { color: '#FF5B1A', weight: 3, dashArray: '7 6' }), poly: L.polygon([], { color: '#FF5B1A', weight: 1, fillOpacity: .12, interactive: false }), g: L.layerGroup() };
const measPts = () => meas.segs.flat();
function measUpdate() {
  const ll = measPts(); meas.line.setLatLngs(ll); meas.poly.setLatLngs(ll.length > 2 ? ll : []);
  meas.g.clearLayers(); meas.segs.forEach(s => s.length && L.marker(s[s.length - 1], { icon: L.divIcon({ className: '', html: '<div class="mp"></div>', iconSize: [10, 10] }), interactive: false }).addTo(meas.g));
  const b = $('#measbar'); b.hidden = !meas.on; if (!meas.on) return;
  b.innerHTML = `<b>${fmtD(pathLen(ll))}</b>` + (ll.length > 2 ? ` · area <b>${fmtA(areaOf(ll))}</b>` : ' <span class="mut">Tap the map to add points</span>') + (ll.length > 1 ? ` · ${fmtAng(brg(ll[ll.length - 2], ll[ll.length - 1]))}` : '') + '<br>';
  const sb = (t, f, cls = '') => el('button', { class: 'btn sm ' + cls, onclick: f }, t);
  b.append(sb('↩', () => { meas.segs.pop(); measUpdate(); }), ' ', sb('Clear', () => { meas.segs = []; meas.dur = 0; measUpdate(); }), ' ',
    sb(meas.roads ? 'Follow roads: on' : 'Follow roads', () => { meas.roads = !meas.roads; measUpdate(); toast(meas.roads ? 'New points follow roads (needs internet)' : 'Straight lines'); }, meas.roads ? 'pri' : ''), ' ',
    sb('Save route', () => saveMeas('line'), 'pri'), ' ', ll.length > 2 ? sb('Save area', () => saveMeas('area'), 'pri') : '', ' ', sb('Close', toggleMeas));
}
function toggleMeas() {
  meas.on = !meas.on; $('#fMeas').classList.toggle('on', meas.on);
  if (meas.on) { meas.line.addTo(map); meas.poly.addTo(map); meas.g.addTo(map); } else { meas.segs = []; map.removeLayer(meas.line); map.removeLayer(meas.poly); map.removeLayer(meas.g); }
  map.closePopup(); drawTracks(); drawWpts(); measUpdate();
}
function saveMeas(kind) {
  const ll = measPts(); if (ll.length < 2) return toast('Add at least 2 points');
  const n = S.tracks.filter(t => t.kind === kind).length + 1;
  const t = { id: uid(), kind, name: (kind === 'area' ? 'Area ' : 'Route ') + n, color: kind === 'area' ? '#ffd23f' : '#c77dff', pts: ll.map(p => [p[0], p[1], null, null]), created: Date.now(), folder: '', attrs: {}, photos: [] };
  if (meas.dur && kind === 'line') t.drive = Math.round(meas.dur); meas.dur = 0;
  S.tracks.push(t); save.tracks(); drawTracks(); toggleMeas(); editFeature(t, 'track');
}
async function routeSeg(a, b) {
  try { const r = await (await fetch(`https://router.project-osrm.org/route/v1/driving/${a[1]},${a[0]};${b[1]},${b[0]}?overview=full&geometries=geojson`)).json(); meas.dur = (meas.dur || 0) + r.routes[0].duration; return r.routes[0].geometry.coordinates.slice(1).map(c => [c[1], c[0]]).concat([b]); }
  catch (e) { toast('Road routing needs internet, straight line used'); return [b]; }
}
map.on('click', async e => {
  if (!meas.on) return; const p = [e.latlng.lat, e.latlng.lng], ll = measPts();
  meas.segs.push(meas.roads && ll.length ? await routeSeg(ll[ll.length - 1], p) : [p]); measUpdate();
});
map.on('contextmenu', e => {
  const { lat, lng } = e.latlng, txt = fmtC(lat, lng);
  L.popup().setLatLng(e.latlng).setContent(el('div', {},
    el('div', { class: 'mut' }, txt),
    el('button', { class: 'btn sm', onclick: () => { map.closePopup(); editFeature(addWpt(lat, lng), 'wpt'); } }, 'Drop waypoint here'),
    el('button', { class: 'btn sm', onclick: () => { map.closePopup(); startNav({ lat, lon: lng, name: 'selected point' }); } }, 'Go to here (compass)'),
    el('button', { class: 'btn sm', onclick: () => { navigator.clipboard && navigator.clipboard.writeText(txt); map.closePopup(); toast('Coordinates copied'); } }, 'Copy coordinates'),
    el('button', { class: 'btn sm', onclick: () => shareText('Location', `${txt}\nhttps://www.google.com/maps?q=${lat.toFixed(6)},${lng.toFixed(6)}`) }, 'Share location'))).openOn(map);
});

// ---------- zip (for KMZ) ----------
async function unzip(buf) {
  const v = new DataView(buf), out = {}; let e = -1;
  for (let i = buf.byteLength - 22; i >= Math.max(0, buf.byteLength - 65557); i--) if (v.getUint32(i, true) === 0x06054b50) { e = i; break; }
  if (e < 0) throw Error('not a zip/KMZ file');
  let p = v.getUint32(e + 16, true); const n = v.getUint16(e + 10, true);
  for (let k = 0; k < n; k++) {
    const meth = v.getUint16(p + 10, true), csz = v.getUint32(p + 20, true), nl = v.getUint16(p + 28, true), xl = v.getUint16(p + 30, true), cl = v.getUint16(p + 32, true), lo = v.getUint32(p + 42, true);
    const name = new TextDecoder().decode(new Uint8Array(buf, p + 46, nl)), ds = lo + 30 + v.getUint16(lo + 26, true) + v.getUint16(lo + 28, true), data = new Uint8Array(buf, ds, csz);
    out[name] = meth === 0 ? data.slice() : meth === 8 ? new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer()) : null;
    p += 46 + nl + xl + cl;
  }
  return out;
}

// ---------- import / export ----------
const kmlAttrs = pm => Object.fromEntries([...pm.getElementsByTagName('Data')].map(d => [d.getAttribute('name'), (d.getElementsByTagName('value')[0] || {}).textContent || '']).filter(x => x[0]));
const okLL = (la, lo) => Number.isFinite(la) && Number.isFinite(lo) && Math.abs(la) <= 90 && Math.abs(lo) <= 180; // import: buang koordinat rosak/luar julat
function parseGPX(d) {
  const o = { tracks: [], wpts: [] }, nm = e => (e.getElementsByTagName('name')[0] || {}).textContent || '';
  const pt = p => { const e = p.getElementsByTagName('ele')[0], t = p.getElementsByTagName('time')[0]; return [parseFloat(p.getAttribute('lat')), parseFloat(p.getAttribute('lon')), e ? +e.textContent : null, t ? Date.parse(t.textContent) : null]; };
  for (const [tag, ptTag, kind] of [['trk', 'trkpt', 'track'], ['rte', 'rtept', 'line']]) for (const t of d.getElementsByTagName(tag)) { const pts = [...t.getElementsByTagName(ptTag)].map(pt).filter(q => okLL(q[0], q[1])); if (pts.length > 1) o.tracks.push({ name: nm(t), pts, kind }); }
  for (const w of d.getElementsByTagName('wpt')) { const p = pt(w); if (okLL(p[0], p[1])) o.wpts.push({ name: nm(w), lat: p[0], lon: p[1], note: (w.getElementsByTagName('desc')[0] || {}).textContent || '' }); }
  return o;
}
function parseKML(d) {
  const o = { tracks: [], wpts: [], ground: [] };
  const coords = n => n.textContent.trim().split(/\s+/).map(s => s.split(',').map(Number)).filter(a => a.length >= 2 && !a.some(isNaN) && okLL(a[1], a[0]));
  for (const pm of d.getElementsByTagName('Placemark')) {
    const name = (pm.getElementsByTagName('name')[0] || {}).textContent || '', note = (pm.getElementsByTagName('description')[0] || {}).textContent || '', attrs = kmlAttrs(pm);
    for (const ls of pm.getElementsByTagName('LineString')) { const pts = coords(ls.getElementsByTagName('coordinates')[0]).map(a => [a[1], a[0], a[2] || null, null]); if (pts.length > 1) o.tracks.push({ name, pts, note, attrs, kind: 'line' }); }
    for (const pg of pm.getElementsByTagName('Polygon')) { const ob = pg.getElementsByTagName('outerBoundaryIs')[0] || pg; const pts = coords(ob.getElementsByTagName('coordinates')[0]).map(a => [a[1], a[0], null, null]); if (pts.length > 2) o.tracks.push({ name, pts, note, attrs, kind: 'area' }); }
    for (const pt of pm.getElementsByTagName('Point')) { const a = coords(pt.getElementsByTagName('coordinates')[0])[0]; if (a) o.wpts.push({ name, lat: a[1], lon: a[0], note, attrs }); }
  }
  for (const g of d.getElementsByTagName('GroundOverlay')) {
    const href = ((g.getElementsByTagName('Icon')[0] || g).getElementsByTagName('href')[0] || {}).textContent, name = (g.getElementsByTagName('name')[0] || {}).textContent || '';
    const q = g.getElementsByTagName('gx:LatLonQuad')[0] || g.getElementsByTagName('LatLonQuad')[0], bx = g.getElementsByTagName('LatLonBox')[0];
    let corners = null;
    if (q) { const c = coords(q.getElementsByTagName('coordinates')[0]).map(a => [a[1], a[0]]); if (c.length >= 4) corners = [c[3], c[2], c[0]]; }
    else if (bx) {
      const v = k => +((bx.getElementsByTagName(k)[0] || {}).textContent || 0), N = v('north'), Sx = v('south'), E = v('east'), W = v('west'), r = rad(v('rotation'));
      const cl = (N + Sx) / 2, cn = (E + W) / 2, k = Math.cos(rad(cl)), hx = (E - W) / 2 * k, hy = (N - Sx) / 2;
      const rot = (x, y) => [cl + x * Math.sin(r) + y * Math.cos(r), cn + (x * Math.cos(r) - y * Math.sin(r)) / k];
      corners = [rot(-hx, hy), rot(hx, hy), rot(-hx, -hy)];
    }
    if (href && corners) o.ground.push({ href, name, corners });
  }
  return o;
}
function parseGeoJSON(j) {
  const o = { tracks: [], wpts: [] };
  const props = p => { const a = {}; for (const k in p || {}) if (!['name', 'Name', 'description', 'stroke', 'fill', 'marker-color'].includes(k) && p[k] != null && typeof p[k] !== 'object') a[k] = String(p[k]); return a; };
  const line = (c, p, kind) => { if (!Array.isArray(c)) return; const pts = c.filter(a => Array.isArray(a) && okLL(a[1], a[0])).map(a => [a[1], a[0], a[2] ?? null, null]); if (pts.length > 1) o.tracks.push({ name: (p && (p.name || p.Name)) || '', pts, kind, attrs: props(p), note: (p && p.description) || '' }); };
  const geom = (g, p) => {
    if (!g) return;
    const gc = Array.isArray(g.coordinates) ? g.coordinates : [];
    if (g.type === 'LineString') line(gc, p, 'line'); else if (g.type === 'MultiLineString') gc.forEach(c => line(c, p, 'line'));
    else if (g.type === 'Polygon') line(gc[0], p, 'area'); else if (g.type === 'MultiPolygon') gc.forEach(c => line(Array.isArray(c) ? c[0] : null, p, 'area'));
    else if (g.type === 'Point') okLL(gc[1], gc[0]) && o.wpts.push({ name: (p && (p.name || p.Name)) || '', lat: gc[1], lon: gc[0], note: (p && p.description) || '', attrs: props(p) });
    else if (g.type === 'MultiPoint') gc.forEach(c => Array.isArray(c) && okLL(c[1], c[0]) && o.wpts.push({ name: (p && p.name) || '', lat: c[1], lon: c[0], note: '', attrs: props(p) }));
    else if (g.type === 'GeometryCollection') (g.geometries || []).forEach(x => geom(x, p));
  };
  if (j.type === 'FeatureCollection') (j.features || []).forEach(f => f && geom(f.geometry, f.properties)); else if (j.type === 'Feature') geom(j.geometry, j.properties); else geom(j);
  return o;
}
function mergeImport(o, fname) { // like Avenza: each imported file gets its own folder (layer)
  const base = fname.replace(/\.[^.]+$/, '');
  o.tracks.forEach((t, i) => S.tracks.push({ id: uid(), kind: t.kind || 'track', name: t.name || base + (o.tracks.length > 1 ? ' ' + (i + 1) : ''), color: t.kind === 'area' ? '#ffd23f' : COLORS[S.tracks.length % COLORS.length], pts: t.pts, created: t.pts[0][3] || Date.now(), folder: base, note: t.note || '', attrs: t.attrs || {}, photos: [] }));
  o.wpts.forEach((w, i) => S.wpts.push({ id: uid(), name: w.name || 'Waypoint ' + (i + 1), note: w.note || '', lat: w.lat, lon: w.lon, color: COLORS[S.wpts.length % COLORS.length], icon: '📍', folder: base, attrs: w.attrs || {}, photos: [], t: Date.now() }));
  save.tracks(); save.wpts(); drawTracks(); drawWpts();
  const all = [...o.tracks.flatMap(t => t.pts.map(p => [p[0], p[1]])), ...o.wpts.map(w => [w.lat, w.lon])];
  if (all.length) map.fitBounds(L.latLngBounds(all).pad(.1));
  toast(`Imported into folder "${base}": ${o.tracks.length} tracks/lines/areas, ${o.wpts.length} waypoints`, 4000); render();
}
async function importFile(f) {
  const ext = f.name.split('.').pop().toLowerCase();
  try {
    if (['png', 'jpg', 'jpeg', 'webp', 'heic'].includes(ext)) return await addOverlay(f);
    if (ext === 'pdf') return await addGeoPdf(f);
    if (ext === 'tif' || ext === 'tiff') return await addGeoTiff(f);
    if (ext === 'mbtiles') return await addMbtiles(f);
    if (ext === 'kmz') return await importKmz(f);
    if (ext === 'zip') return await importShpZip(f);
    if (ext === 'gpkg') return await importGpkg(f);
    if (ext === 'shp') return toast('Pick the .zip that contains the .shp, .dbf and .prj files', 5000);
    const txt = await f.text(), xml = () => new DOMParser().parseFromString(txt, 'application/xml');
    let o;
    if (ext === 'gpx') o = parseGPX(xml()); else if (ext === 'kml') o = parseKML(xml()); else if (ext === 'json' || ext === 'geojson') o = parseGeoJSON(JSON.parse(txt));
    else if (ext === 'csv') o = parseCSV(txt);
    else return toast('Unsupported format: .' + ext);
    if (!o.tracks.length && !o.wpts.length) return toast('No tracks or waypoints found in file');
    mergeImport(o, f.name);
  } catch (e) { toast('Could not read ' + f.name + ': ' + e.message, 5000); }
}
async function importKmz(f) {
  const files = await unzip(await f.arrayBuffer()), kmlName = Object.keys(files).find(n => /\.kml$/i.test(n));
  if (!kmlName) throw Error('no KML inside');
  const o = parseKML(new DOMParser().parseFromString(new TextDecoder().decode(files[kmlName]), 'application/xml')), base = f.name.replace(/\.[^.]+$/, '');
  for (const g of o.ground) {
    const key = Object.keys(files).find(n => n === g.href || n.endsWith('/' + g.href) || g.href.endsWith(n)); if (!key) continue;
    const blob = new Blob([files[key]], { type: /png$/i.test(key) ? 'image/png' : 'image/jpeg' });
    await newImageMap({ name: g.name || base, blob, corners: g.corners, opacity: 1 });
  }
  if (o.tracks.length || o.wpts.length) mergeImport(o, f.name); else if (!o.ground.length) toast('No map data found in KMZ');
}
function parseCSV(txt) { // name,lat,lon,... (header row required)
  const rows = txt.trim().split(/\r?\n/).map(r => r.match(/("([^"]|"")*"|[^,]*)(,|$)/g).map(c => c.replace(/,$/, '').replace(/^"|"$/g, '').replace(/""/g, '"'))).filter(r => r.length > 1);
  const h = rows.shift().map(x => x.trim().toLowerCase()), li = h.findIndex(x => /^(lat|latitude)$/.test(x)), oi = h.findIndex(x => /^(lon|lng|long|longitude)$/.test(x)), ni = h.findIndex(x => /^(name|title)$/.test(x));
  if (li < 0 || oi < 0) throw Error('CSV needs lat and lon columns');
  return { tracks: [], wpts: rows.map(r => ({ name: r[ni] || '', lat: parseFloat(r[li]), lon: parseFloat(r[oi]), note: '', attrs: Object.fromEntries(h.map((k, i) => [k, r[i]]).filter((x, i) => ![li, oi, ni].includes(i) && x[1])) })).filter(w => okLL(w.lat, w.lon)) };
}
const dl = (name, data, type) => { const a = el('a', { href: URL.createObjectURL(data instanceof Blob ? data : new Blob([data], { type })), download: name }); document.body.append(a); a.click(); a.remove(); };
async function shareFile(name, data, type) {
  const f = new File([data], name, { type });
  if (navigator.canShare && navigator.canShare({ files: [f] })) { try { await navigator.share({ files: [f], title: name }); return; } catch (e) { if (e.name === 'AbortError') return; } }
  dl(name, data, type);
}
async function shareText(title, text) { if (navigator.share) { try { await navigator.share({ title, text }); return; } catch (e) { if (e.name === 'AbortError') return; } } navigator.clipboard && navigator.clipboard.writeText(text); toast('Copied to clipboard'); }
const shareFeature = (f, kind) => shareFile(fname(f.name) + '.gpx', kind === 'wpt' ? toGPX([], [f]) : toGPX([f], []), 'application/gpx+xml');
const iso = t => t ? `<time>${new Date(t).toISOString()}</time>` : '';
function toGPX(tracks, wpts) {
  return `<?xml version="1.0" encoding="UTF-8"?>\n<gpx version="1.1" creator="Trail Atlas" xmlns="http://www.topografix.com/GPX/1/1">\n` +
    wpts.map(w => `<wpt lat="${w.lat}" lon="${w.lon}"><name>${esc(w.name)}</name>${w.note ? `<desc>${esc(w.note)}</desc>` : ''}${w.folder ? `<type>${esc(w.folder)}</type>` : ''}</wpt>`).join('\n') + '\n' +
    tracks.map(t => { const pts = t.kind === 'area' ? [...t.pts, t.pts[0]] : t.pts, tag = t.kind === 'line' ? 'rte' : 'trk', pt = t.kind === 'line' ? 'rtept' : 'trkpt';
      const body = pts.map(p => `<${pt} lat="${p[0]}" lon="${p[1]}">${p[2] != null ? `<ele>${p[2]}</ele>` : ''}${iso(p[3])}</${pt}>`).join('');
      return `<${tag}><name>${esc(t.name)}</name>${t.note ? `<desc>${esc(t.note)}</desc>` : ''}${tag === 'trk' ? `<trkseg>${body}</trkseg>` : body}</${tag}>`; }).join('\n') + '\n</gpx>';
}
const kmlData = f => { const a = { ...(f.attrs || {}) }; if (f.folder) a.folder = f.folder; const e = Object.entries(a); return e.length ? `<ExtendedData>${e.map(([k, v]) => `<Data name="${esc(k)}"><value>${esc(v)}</value></Data>`).join('')}</ExtendedData>` : ''; };
function toKML(tracks, wpts, withPhotos) {
  const desc = f => withPhotos && (f.photos || []).length ? `<![CDATA[${esc(f.note || '')}${f.photos.map(id => `<br><img src="files/${id}.jpg" width="400"/>`).join('')}]]>` : esc(f.note || '');
  const kc = c => { const h = (c || '#ff6b5b').replace('#', ''); return 'ff' + h.slice(4, 6) + h.slice(2, 4) + h.slice(0, 2); };
  return `<?xml version="1.0" encoding="UTF-8"?>\n<kml xmlns="http://www.opengis.net/kml/2.2"><Document><name>Trail Atlas</name>` +
    wpts.map(w => `<Placemark><name>${esc(w.name)}</name><description>${desc(w)}</description>${kmlData(w)}<Point><coordinates>${w.lon},${w.lat}</coordinates></Point></Placemark>`).join('') +
    tracks.map(t => `<Placemark><name>${esc(t.name)}</name><description>${desc(t)}</description><Style><LineStyle><color>${kc(t.color)}</color><width>3</width></LineStyle><PolyStyle><color>40${kc(t.color).slice(2)}</color></PolyStyle></Style>${kmlData(t)}` +
      (t.kind === 'area' ? `<Polygon><outerBoundaryIs><LinearRing><coordinates>${[...t.pts, t.pts[0]].map(p => `${p[1]},${p[0]}`).join(' ')}</coordinates></LinearRing></outerBoundaryIs></Polygon>` : `<LineString><coordinates>${t.pts.map(p => `${p[1]},${p[0]},${p[2] ?? 0}`).join(' ')}</coordinates></LineString>`) + '</Placemark>').join('') + '</Document></kml>';
}
const gjProps = f => ({ name: f.name, description: f.note || '', folder: f.folder || '', ...(f.st ? { status: f.st } : {}), ...(f.by ? { assigned: f.by } : {}), ...(f.attrs || {}), ...(f.icon ? { icon: f.icon } : {}), ...(f.kind === 'area' ? { area_m2: Math.round(areaOf(f.pts)) } : {}) });
const toGJ = (tracks, wpts) => JSON.stringify({ type: 'FeatureCollection', features: [
  ...tracks.map(t => ({ type: 'Feature', properties: gjProps(t), geometry: t.kind === 'area' ? { type: 'Polygon', coordinates: [[...t.pts, t.pts[0]].map(p => [p[1], p[0]])] } : { type: 'LineString', coordinates: t.pts.map(p => p[2] != null ? [p[1], p[0], p[2]] : [p[1], p[0]]) } })),
  ...wpts.map(w => ({ type: 'Feature', properties: gjProps(w), geometry: { type: 'Point', coordinates: [w.lon, w.lat] } }))] });
function toCSV(wpts) {
  const keys = [...new Set(wpts.flatMap(w => Object.keys(w.attrs || {})))], q = v => /[",\n]/.test(String(v ?? '')) ? `"${String(v).replace(/"/g, '""')}"` : String(v ?? '');
  return [['name', 'lat', 'lon', 'status', 'icon', 'folder', 'assigned', 'note', 'address', 'created', ...keys].map(q).join(','),
    ...wpts.map(w => [w.name, w.lat, w.lon, w.st ? (STATUS[w.st] || {}).n || w.st : '', ICONS[w.icon] || '', w.folder, w.by, w.note, w.address, new Date(w.t || Date.now()).toISOString(), ...keys.map(k => (w.attrs || {})[k])].map(q).join(','))].join('\n');
}
const fname = n => String(n).replace(/[^\w\- ]+/g, '_').trim() || 'trail';

// ---------- my maps (GeoPDF, GeoTIFF, KMZ, MBTiles, images) ----------
const ovLayers = {}; const handles = L.layerGroup().addTo(map); let editOv = null;
function showMap(o) { // like Avenza: opening a map hides the others, unless "several maps" is on
  if (!S.set.multi) S.overlays.forEach(x => { if (x !== o) x.hidden = true; });
  o.hidden = false; stopEditOv();
}
function migrateOv(o) { if (!o.type) o.type = 'image'; if (o.type === 'image' && !o.corners && o.bounds) { const [[s, w], [n, e]] = o.bounds; o.corners = [[n, w], [n, e], [s, w]]; delete o.bounds; } if (o.folder == null) o.folder = ''; if (!o.added) o.added = Date.now(); return o; }
function drawOverlays() {
  gOv.clearLayers(); for (const k in ovLayers) delete ovLayers[k];
  for (const o of S.overlays) {
    if (o.hidden) continue;
    ovLayers[o.id] = (o.type === 'tiles'
      ? new CacheTiles(`mbtiles/${o.id}/{z}/{x}/{y}`, { pane: 'maps', minNativeZoom: o.minz, maxNativeZoom: o.maxz, maxZoom: 22, bounds: o.bounds, opacity: o.opacity })
      : new AffineImage(o._url || (o._url = URL.createObjectURL(o.blob)), o.corners, { opacity: o.opacity })).addTo(gOv);
  }
}
async function newImageMap(p) {
  const o = migrateOv({ id: uid(), type: 'image', name: p.name, blob: p.blob, corners: p.corners, opacity: p.opacity ?? 1, hidden: false, folder: p.folder || '', added: Date.now() });
  S.overlays.push(o); showMap(o); await save.overlays(); drawOverlays(); map.fitBounds(ovBounds(o)); tab = ''; setTab('layers'); return o;
}
async function addOverlay(f) { // plain image / photo of a paper map: place in view, then align with handles
  const c = map.getBounds(), w = c.getEast() - c.getWest(), h = c.getNorth() - c.getSouth();
  const img = await createImageBitmap(f), ar = img.width / img.height, blob = img.width * img.height > 16e6 ? await resizeImg(f, 4000) : f;
  const ctr = map.getCenter(), k = Math.cos(rad(ctr.lat));
  let hw = w * .7, hh = hw * k / ar; if (hh > h * .7) { hh = h * .7; hw = hh * ar / k; }
  const o = await newImageMap({ name: f.name.replace(/\.[^.]+$/, ''), blob, opacity: .7, corners: [[ctr.lat + hh / 2, ctr.lng - hw / 2], [ctr.lat + hh / 2, ctr.lng + hw / 2], [ctr.lat - hh / 2, ctr.lng - hw / 2]] });
  startEditOv(o); toast('Align the map: drag ✥ to move, ↻ to rotate and resize, orange corners to stretch', 6000);
}
// GeoPDF: returns {box:[x0,y0,x1,y1] in PDF points, f:(x,y)=>[lat,lon], name} or {err}
function geoRefLGI(raw) {
  const i = raw.indexOf('/LGIDict'); if (i < 0) return null;
  const d = raw.slice(Math.max(0, i - 2000), i + 4000), pick = k => { const m = d.match(new RegExp('/' + k + '\\s*\\[([^\\]]+)\\]')); return m && nums(m[1]); };
  const ctm = pick('CTM'), nl = pick('Neatline'); if (!ctm || ctm.length < 6) return { err: 'GeoPDF has no CTM info, not supported yet' };
  const pt = (d.match(/ProjectionType\s*\((\w+)\)/) || [])[1] || '';
  const X = (x, y) => ctm[0] * x + ctm[2] * y + ctm[4], Y = (x, y) => ctm[1] * x + ctm[3] * y + ctm[5];
  let f;
  if (pt === 'GEODETIC') f = (x, y) => [Y(x, y), X(x, y)];
  else if (pt === 'UT') { const z = +((d.match(/\/Zone\s*\(?\s*(\d+)/) || [])[1]), s = /\/Hemisphere\s*\(\s*S/.test(d); if (!z) return { err: 'UTM GeoPDF without zone' }; f = (x, y) => utmInv(z, s, X(x, y), Y(x, y)); }
  else return { err: `GeoPDF projection "${pt}" not supported yet (degrees and UTM are)` };
  const ok = nl && nl.length >= 8, xs = ok ? nl.filter((_, k) => k % 2 === 0) : null, ys = ok ? nl.filter((_, k) => k % 2) : null;
  return { box: ok ? [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)] : null, name: (d.match(/\/Description\s*\(([^)]*)\)/) || [])[1], f };
}
async function geoRefOGC(raw) { // ISO 32000 /VP + /Measure /GEO (works for rotated and projected maps)
  const objAt = n => { const m = new RegExp('(?:^|[\\r\\n ])' + n + ' 0 obj').exec(raw); return m ? raw.slice(m.index, m.index + 3000) : ''; };
  let best = null;
  for (const m of raw.matchAll(/\/Type\s*\/Viewport/g)) {
    const w = raw.slice(Math.max(0, m.index - 300), m.index + 600), bb = w.match(/\/BBox\s*\[([^\]]+)\]/), mr = w.match(/\/Measure\s+(\d+)\s+0\s+R/);
    if (!bb || !mr) continue; const me_ = objAt(mr[1]), gp = me_.match(/\/GPTS\s*\[([^\]]+)\]/), lp = me_.match(/\/LPTS\s*\[([^\]]+)\]/), gc = me_.match(/\/GCS\s+(\d+)\s+0\s+R/);
    if (!gp || !lp || (gc && /LOCAL_CS/.test(objAt(gc[1]).slice(0, 700)))) continue;
    const B = nums(bb[1]), G = nums(gp[1]), Lp = nums(lp[1]); if (B.length < 4 || G.length < 6 || G.length !== Lp.length) continue;
    const area = Math.abs((B[2] - B[0]) * (B[3] - B[1])); if (best && area <= best.area) continue;
    const gtx = gc ? objAt(gc[1]) : ''; best = { area, B, G, Lp, gt: (gtx.match(/\/Type\s*\/(PROJCS|GEOGCS)/) || [])[1] || '', gtx };
  }
  if (!best) return null;
  const { B, G, Lp, gt, gtx } = best, pts = [];
  for (let k = 0; k < G.length / 2; k++) pts.push({ x: B[0] + Lp[2 * k] * (B[2] - B[0]), y: B[1] + Lp[2 * k + 1] * (B[3] - B[1]), lat: G[2 * k], lon: G[2 * k + 1] });
  const fa = fitAffine(pts, 'lat'), fo = fitAffine(pts, 'lon'); if (!fa || !fo) return { err: 'GeoPDF has too few reference points' };
  const ll = (x, y) => [fa[0] * x + fa[1] * y + fa[2], fo[0] * x + fo[1] * y + fo[2]];
  // Projected maps: lat/lon is not linear in page coordinates (error grows with sheet size: ~10 m at 50 km, ~35 m at 100 km), so fit in a local map plane
  // (transverse Mercator at the map centre). Exact for UTM, very close for RSO / Cassini. Geographic maps keep the lat/lon fit. Unknown type: the smaller residual wins.
  const cm = pts.reduce((s, p) => s + p.lon, 0) / pts.length, south = pts[0].lat < 0, P = pts.map(p => { const u = utmObj(p.lat, p.lon, 1, cm); return { ...p, E: u.E, N: u.N }; });
  const ea = fitAffine(P, 'E'), na = fitAffine(P, 'N'); let f = ll, exact = false;
  // Best case: the PDF names the map's own coordinate system (EPSG code). Fit in that system: exact for UTM, RSO and the state grids.
  const auth = [...(gtx || '').matchAll(/AUTHORITY\["EPSG",\s*"?(\d+)"?\s*\]/g)].map(m => +m[1]), em = (gtx || '').match(/\/EPSG\s+(\d+)/), code = em ? +em[1] : auth[auth.length - 1];
  if (gt !== 'GEOGCS' && code && typeof projBoth === 'function' && ((EPSG[code] && !/\+proj=longlat/.test(EPSG[code])) || (code >= 32601 && code <= 32760))) { // a geographic code (e.g. the 4326 inside a PROJCS) must not be taken for the map's own system
    try {
      const pj = await projBoth(code), P2 = pts.map(p => { const [X, Y] = pj.fwd(p.lat, p.lon); return { ...p, X, Y }; }), xa = fitAffine(P2, 'X'), ya = fitAffine(P2, 'Y');
      if (xa && ya) { f = (x, y) => pj.inv(xa[0] * x + xa[1] * y + xa[2], ya[0] * x + ya[1] * y + ya[2]); exact = true; }
    } catch (err) { }
  }
  if (ea && na) {
    const pl = (x, y) => utmInv(1, south, ea[0] * x + ea[1] * y + ea[2], na[0] * x + na[1] * y + na[2], cm);
    const rms = g => Math.sqrt(pts.reduce((s, p) => { const [la, lo] = g(p.x, p.y), dy = (la - p.lat) * 111320, dx = (lo - p.lon) * 111320 * Math.cos(rad(p.lat)); return s + dx * dx + dy * dy; }, 0) / pts.length);
    if (!exact && (gt === 'PROJCS' || (gt !== 'GEOGCS' && rms(pl) < rms(ll)))) f = pl;
  }
  return { box: [Math.min(B[0], B[2]), Math.min(B[1], B[3]), Math.max(B[0], B[2]), Math.max(B[1], B[3])], f };
}
async function addGeoPdf(f) {
  const buf = await f.arrayBuffer(), raw = new TextDecoder('latin1').decode(buf), g = geoRefLGI(raw) || await geoRefOGC(raw);
  if (!g) { toast('This PDF has no coordinates: it was added as a plain image, align it with the handles.', 6000); return addPdfAsImage(buf, f.name); }
  if (g.err) return toast(g.err, 5000);
  for (const m of raw.matchAll(/\/Subtype\s*\/Image/g)) { // huge images would crash the browser
    const w = raw.slice(Math.max(0, m.index - 500), m.index + 500), W = +(w.match(/\/Width\s+(\d+)/) || [])[1], H = +(w.match(/\/Height\s+(\d+)/) || [])[1];
    if (W * H > 40e6) return toast(`Image inside the PDF is too large (${W}×${H}) for a phone. Shrink it first with tools/shrink_geopdf.py.`, 8000);
  }
  toast('Processing GeoPDF…', 8000);
  const { page, v0 } = await pdfPage(buf), box = g.box || [0, 0, v0.width, v0.height];
  const blob = await renderPdf(page, v0, box);
  await newImageMap({ name: g.name || f.name.replace(/\.[^.]+$/, ''), blob, corners: [g.f(box[0], box[3]), g.f(box[2], box[3]), g.f(box[0], box[1])] });
  toast('GeoPDF ready (auto-positioned)');
}
async function pdfPage(buf) {
  if (!window.pdfjsLib) await loadScript('lib/pdf.min.js');
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'lib/pdf.worker.min.js';
  const page = await (await pdfjsLib.getDocument({ data: buf }).promise).getPage(1); return { page, v0: page.getViewport({ scale: 1 }) };
}
async function renderPdf(page, v0, box) {
  const sc = Math.min(4, 3500 / Math.max(box[2] - box[0], box[3] - box[1])), cv = el('canvas');
  cv.width = Math.round((box[2] - box[0]) * sc); cv.height = Math.round((box[3] - box[1]) * sc);
  await page.render({ canvasContext: cv.getContext('2d'), viewport: page.getViewport({ scale: sc, offsetX: -box[0] * sc, offsetY: -(v0.height - box[3]) * sc }) }).promise;
  return new Promise(r => cv.toBlob(r, 'image/jpeg', .92));
}
async function addPdfAsImage(buf, name) { const { page, v0 } = await pdfPage(buf); const b = await renderPdf(page, v0, [0, 0, v0.width, v0.height]); await addOverlay(new File([b], name.replace(/\.pdf$/i, '.jpg'), { type: 'image/jpeg' })); }
async function addGeoTiff(f) {
  toast('Processing GeoTIFF…', 8000);
  await loadScript('lib/geotiff.js');
  const img = await (await GeoTIFF.fromBlob(f)).getImage(), W = img.getWidth(), H = img.getHeight(), gk = img.getGeoKeys() || {}, fd = img.getFileDirectory();
  const epsg = gk.ProjectedCSTypeGeoKey || gk.GeographicTypeGeoKey || 4326;
  let toLL;
  if ([4326, 4269, 4258, 4742].includes(epsg) || (!gk.ProjectedCSTypeGeoKey && gk.GTModelTypeGeoKey === 2)) toLL = (x, y) => [y, x];
  else if ([3857, 900913, 3785, 102100].includes(epsg)) toLL = mercInv;
  else if (epsg >= 32601 && epsg <= 32660) toLL = (x, y) => utmInv(epsg - 32600, false, x, y);
  else if (epsg >= 32701 && epsg <= 32760) toLL = (x, y) => utmInv(epsg - 32700, true, x, y);
  else return toast(`GeoTIFF coordinate system EPSG:${epsg} not supported yet (WGS84 degrees, Web Mercator and UTM are)`, 7000);
  let gt;
  if (fd.ModelTransformation) { const m = fd.ModelTransformation; gt = (px, py) => [m[0] * px + m[1] * py + m[3], m[4] * px + m[5] * py + m[7]]; }
  else { const o = img.getOrigin(), r = img.getResolution(); gt = (px, py) => [o[0] + px * r[0], o[1] + py * r[1]]; }
  const s = Math.min(1, 4096 / Math.max(W, H)), w = Math.round(W * s), h = Math.round(H * s);
  const rgb = await img.readRGB({ width: w, height: h, interleave: true }), cv = el('canvas'); cv.width = w; cv.height = h;
  const ctx = cv.getContext('2d'), id = ctx.createImageData(w, h), ch = rgb.length / (w * h);
  for (let i = 0, j = 0; i < w * h; i++, j += ch) { id.data[i * 4] = rgb[j]; id.data[i * 4 + 1] = rgb[j + 1]; id.data[i * 4 + 2] = rgb[j + 2]; id.data[i * 4 + 3] = ch === 4 ? rgb[j + 3] : 255; }
  ctx.putImageData(id, 0, 0);
  const blob = await new Promise(r => cv.toBlob(r, ch === 4 ? 'image/png' : 'image/jpeg', .9));
  await newImageMap({ name: f.name.replace(/\.[^.]+$/, ''), blob, corners: [toLL(...gt(0, 0)), toLL(...gt(W, 0)), toLL(...gt(0, H))] });
  toast('GeoTIFF ready (auto-positioned)');
}
async function addMbtiles(f) {
  if (f.size > 400e6) return toast('MBTiles file too large for the browser (max 400 MB)', 6000);
  try { // the browser's own quota is often smaller than 400 MB — check before doing the work
    const e = await navigator.storage.estimate(), free = (e.quota || 0) - (e.usage || 0);
    if (free && f.size * 1.15 > free) return toast(`Not enough room on this device: the file needs about ${Math.round(f.size * 1.15 / 1048576)} MB and only ${Math.round(free / 1048576)} MB is free. Free up space or use a smaller MBTiles.`, 9000);
  } catch (e) { }
  toast('Reading MBTiles…', 10000); await loadScript('lib/sql-wasm.js');
  const SQL = await initSqlJs({ locateFile: x => 'lib/' + x }), d = new SQL.Database(new Uint8Array(await f.arrayBuffer()));
  const meta = {}; try { const r = d.exec('SELECT name, value FROM metadata')[0]; (r ? r.values : []).forEach(([k, v]) => meta[k] = v); } catch (e) { }
  const id = uid(), cache = await caches.open(MBT_CACHE), st = d.prepare('SELECT zoom_level, tile_column, tile_row, tile_data FROM tiles');
  let n = 0, minz = 99, maxz = 0; const type = (meta.format || 'png') === 'jpg' ? 'image/jpeg' : 'image/' + (meta.format || 'png');
  while (st.step()) {
    const [z, x, y, data] = st.get(); minz = Math.min(minz, z); maxz = Math.max(maxz, z);
    await cache.put(`mbtiles/${id}/${z}/${x}/${(1 << z) - 1 - y}`, new Response(new Blob([data], { type }), { headers: { 'Content-Type': type } }));
    if (++n % 200 === 0) toast(`Reading MBTiles… ${n} tiles`, 10000);
  }
  st.free(); d.close(); if (!n) return toast('No tiles in this MBTiles file');
  const b = (meta.bounds || '-180,-85,180,85').split(',').map(Number);
  const o = migrateOv({ id, type: 'tiles', name: meta.name || f.name.replace(/\.[^.]+$/, ''), bounds: [[b[1], b[0]], [b[3], b[2]]], minz, maxz, opacity: 1, hidden: false });
  S.overlays.push(o); showMap(o); await save.overlays(); drawOverlays(); map.fitBounds(o.bounds); tab = ''; setTab('layers'); toast(`MBTiles ready: ${n} tiles, zoom ${minz}–${maxz}`);
}
async function delMap(o) {
  if (o.type === 'tiles') { const c = await caches.open(MBT_CACHE); for (const r of await c.keys()) if (r.url.includes(`/mbtiles/${o.id}/`)) await c.delete(r); }
  S.overlays = S.overlays.filter(x => x !== o); stopEditOv(); save.overlays(); drawOverlays(); render();
}
// align a map: ✥ move, ↻ rotate + resize (keeps shape), orange corners stretch freely
function startEditOv(o) {
  stopEditOv(); editOv = o; const lay = () => ovLayers[o.id];
  const ctr = () => { const b = brOf(o.corners); return [(o.corners[1][0] + o.corners[2][0]) / 2, (o.corners[1][1] + o.corners[2][1]) / 2, b]; };
  const hs = [];
  const icon = (cls, t) => L.divIcon({ className: '', html: `<div class="handle ${cls}">${t}</div>`, iconSize: [24, 24] });
  const place = () => { const c = ctr(); hs[0].setLatLng(o.corners[0]); hs[1].setLatLng(o.corners[1]); hs[2].setLatLng(o.corners[2]); hs[3].setLatLng(c[2]); hs[4].setLatLng([c[0], c[1]]); };
  const upd = () => { lay() && lay().setCorners(o.corners); };
  [0, 1, 2].forEach(i => hs.push(L.marker(o.corners[i], { draggable: true, icon: icon('', '') }).addTo(handles).on('drag', e => { const p = e.target.getLatLng(); o.corners[i] = [p.lat, p.lng]; upd(); place(); })));
  let start = null;
  hs.push(L.marker(brOf(o.corners), { draggable: true, icon: icon('rot', '↻') }).addTo(handles)
    .on('dragstart', () => { const c = ctr(); start = { c, k: Math.cos(rad(c[0])), corners: o.corners.map(x => [...x]), br: c[2] }; })
    .on('drag', e => {
      const p = e.target.getLatLng(), { c, k, corners, br } = start, v0 = [(br[1] - c[1]) * k, br[0] - c[0]], v1 = [(p.lng - c[1]) * k, p.lat - c[0]];
      const s = Math.hypot(...v1) / (Math.hypot(...v0) || 1), a = Math.atan2(v1[1], v1[0]) - Math.atan2(v0[1], v0[0]);
      o.corners = corners.map(q => { const x = (q[1] - c[1]) * k, y = q[0] - c[0]; return [c[0] + s * (x * Math.sin(a) + y * Math.cos(a)), c[1] + s * (x * Math.cos(a) - y * Math.sin(a)) / k]; });
      upd(); [0, 1, 2].forEach(i => hs[i].setLatLng(o.corners[i])); hs[4].setLatLng([c[0], c[1]]);
    }));
  hs.push(L.marker([ctr()[0], ctr()[1]], { draggable: true, icon: icon('mv', '✥') }).addTo(handles)
    .on('dragstart', () => { start = { c: ctr(), corners: o.corners.map(x => [...x]) }; })
    .on('drag', e => { const p = e.target.getLatLng(), dy = p.lat - start.c[0], dx = p.lng - start.c[1]; o.corners = start.corners.map(q => [q[0] + dy, q[1] + dx]); upd(); place(); }));
  hs.forEach(h => h.on('dragend', () => save.overlays()));
  const b = $('#alignbar'); b.hidden = false;
  b.replaceChildren('Aligning ', el('b', {}, o.name), el('div', { class: 'mut' }, 'Drag ✥ to move, ↻ to rotate and resize, orange corners to stretch.' + (o.rms ? ` Fit ± ${o.rms} m.` : '')),
    el('div', { class: 'row', style: 'margin-top:6px' },
      el('button', { class: 'btn sm', onclick: () => accUI(o) }, 'Accuracy (RMS)…'),
      el('button', { class: 'btn sm pri', onclick: () => { stopEditOv(); toast('Map position saved'); if (tab === 'layers') render(); } }, 'Done')));
}
function stopEditOv() { handles.clearLayers(); editOv = null; const b = $('#alignbar'); if (b) b.hidden = true; }
async function exportGeoPdf(o) { // map image + visible tracks/waypoints -> shareable GeoPDF (ISO 32000)
  toast('Building GeoPDF…');
  const bm = await createImageBitmap(o.blob), s = Math.min(1, 4000 / Math.max(bm.width, bm.height)), W = Math.round(bm.width * s), H = Math.round(bm.height * s);
  const cv = el('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d'); g.drawImage(bm, 0, 0, W, H);
  const px = ll => { const [u, v] = toUV(o.corners, ll); return [u * W, v * H]; }, lw = Math.max(2, W / 600);
  for (const t of S.tracks.filter(t => !t.hidden && t.pts.some(p => onMapO(o, p)))) {
    g.beginPath(); t.pts.forEach((p, i) => { const [x, y] = px(p); i ? g.lineTo(x, y) : g.moveTo(x, y); }); if (t.kind === 'area') { g.closePath(); g.fillStyle = t.color + '33'; g.fill(); }
    g.strokeStyle = t.color; g.lineWidth = lw; g.stroke();
  }
  g.font = `bold ${Math.round(lw * 7)}px sans-serif`;
  for (const w of S.wpts.filter(w => !w.hidden && onMapO(o, [w.lat, w.lon]))) { const [x, y] = px([w.lat, w.lon]); g.fillStyle = w.color; g.beginPath(); g.arc(x, y, lw * 3, 0, 7); g.fill(); g.strokeStyle = '#fff'; g.lineWidth = lw; g.stroke(); g.fillStyle = '#000'; g.fillText(w.name, x + lw * 4, y + lw * 2); g.fillStyle = '#fff'; g.fillText(w.name, x + lw * 4 - 1, y + lw * 2 - 1); }
  await shareFile(fname(o.name) + '_geo.pdf', await geoPdf(cv, [0, 0, W, H], o.corners, o.name), 'application/pdf');
}
// one-page PDF from a canvas (150 dpi); the map rectangle [x,y,w,h] in canvas px is georeferenced (ISO 32000 GeoPDF)
async function geoPdf(cv, rect, corners, name) {
  const W = cv.width, H = cv.height, jpg = new Uint8Array(await (await new Promise(r => cv.toBlob(r, 'image/jpeg', .9))).arrayBuffer());
  const k = 72 / 150, pw = +(W * k).toFixed(2), ph = +(H * k).toFixed(2);
  const bb = [rect[0] * k, (H - rect[1] - rect[3]) * k, (rect[0] + rect[2]) * k, (H - rect[1]) * k].map(v => +v.toFixed(3));
  const [tl, tr, bl] = corners, br = brOf(corners);
  const gpts = [bl, tl, tr, br].map(p => `${p[0].toFixed(8)} ${p[1].toFixed(8)}`).join(' '), content = `q ${pw} 0 0 ${ph} 0 0 cm /Im0 Do Q`;
  const objs = [`<</Type/Catalog/Pages 2 0 R>>`, `<</Type/Pages/Kids[3 0 R]/Count 1>>`,
    `<</Type/Page/Parent 2 0 R/MediaBox[0 0 ${pw} ${ph}]/Resources<</XObject<</Im0 4 0 R>>>>/Contents 5 0 R/VP[6 0 R]>>`, null,
    `<</Length ${content.length}>>\nstream\n${content}\nendstream`, `<</Type/Viewport/BBox[${bb.join(' ')}]/Name(${String(name).replace(/[^\x20-\x7e]|[()\\]/g, '')})/Measure 7 0 R>>`,
    `<</Type/Measure/Subtype/GEO/Bounds[0 0 0 1 1 1 1 0]/GCS 8 0 R/GPTS[${gpts}]/LPTS[0 0 0 1 1 1 1 0]>>`,
    `<</Type/GEOGCS/EPSG 4326/WKT(GEOGCS["WGS 84",DATUM["WGS_1984",SPHEROID["WGS 84",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["degree",0.0174532925199433]])>>`];
  const enc = s => Uint8Array.from(s, c => c.charCodeAt(0) & 255), parts = [enc('%PDF-1.7\n%\xE2\xE3\xCF\xD3\n')], offs = []; let pos = parts[0].length;
  objs.forEach((ob, i) => {
    offs.push(pos); const chunk = ob === null ? [enc(`4 0 obj\n<</Type/XObject/Subtype/Image/Width ${W}/Height ${H}/ColorSpace/DeviceRGB/BitsPerComponent 8/Filter/DCTDecode/Length ${jpg.length}>>\nstream\n`), jpg, enc('\nendstream\nendobj\n')] : [enc(`${i + 1} 0 obj\n${ob}\nendobj\n`)];
    chunk.forEach(c => { parts.push(c); pos += c.length; });
  });
  parts.push(enc(`xref\n0 ${objs.length + 1}\n0000000000 65535 f \n${offs.map(x => String(x).padStart(10, '0') + ' 00000 n \n').join('')}trailer\n<</Size ${objs.length + 1}/Root 1 0 R>>\nstartxref\n${pos}\n%%EOF\n`));
  return new Blob(parts, { type: 'application/pdf' });
}

// ---------- share outputs: map PDF / image, feature reports, KMZ with photos ----------
const INK = '#15241C', INK2 = '#56665C', PAPER = '#FBFCFA', RULE = '#CFD8CE', FLAG = '#FF5B1A';
function drawFeatures(g, px, s, extra) {
  const list = S.tracks.filter(t => !t.hidden || t === extra);
  for (const t of list) {
    if (t.pts.length < 2) continue; const path = () => { g.beginPath(); t.pts.forEach((p, i) => { const [x, y] = px(p); i ? g.lineTo(x, y) : g.moveTo(x, y); }); if (t.kind === 'area') g.closePath(); };
    g.lineJoin = g.lineCap = 'round'; g.setLineDash([]);
    if (t.kind === 'area') { path(); g.fillStyle = t.color + '40'; g.fill(); }
    path(); g.strokeStyle = 'rgba(255,255,255,.85)'; g.lineWidth = (t === extra ? 8 : 6) * s; g.stroke();
    path(); g.strokeStyle = t.color; g.lineWidth = (t === extra ? 5 : 3.5) * s; g.setLineDash(t.kind === 'line' ? [9 * s, 7 * s] : []); g.stroke(); g.setLineDash([]);
  }
  g.font = `650 ${12.5 * s}px Archivo, sans-serif`;
  for (const w of S.wpts.filter(w => !w.hidden || w === extra)) {
    const [x, y] = px([w.lat, w.lon]), r = (w === extra ? 10 : 7.5) * s;
    g.beginPath(); g.arc(x, y, r, 0, 7); g.fillStyle = w.color; g.fill(); g.lineWidth = 2.5 * s; g.strokeStyle = '#fff'; g.stroke();
    if (S.set.labels || w === extra) { g.lineWidth = 4 * s; g.strokeStyle = 'rgba(255,255,255,.95)'; g.strokeText(w.name, x + r + 4 * s, y + 4 * s); g.fillStyle = INK; g.fillText(w.name, x + r + 4 * s, y + 4 * s); }
  }
}
function scaleNorth(g, x, y, w, h, mpp, s) { // scale bar bottom-left, north arrow top-right (map is always north-up)
  const target = mpp * w * .28, nice = [1, 2, 5].flatMap(m => [1, 10, 100, 1000, 1e4, 1e5].map(e => m * e)).sort((a, b) => a - b).filter(v => v <= target).pop() || 1, len = nice / mpp;
  g.fillStyle = 'rgba(251,252,250,.92)'; g.fillRect(x + 12 * s, y + h - 46 * s, len + 24 * s, 34 * s);
  g.fillStyle = INK; g.fillRect(x + 24 * s, y + h - 22 * s, len, 5 * s); g.fillStyle = '#fff'; g.fillRect(x + 24 * s + len / 2, y + h - 21 * s, len / 2 - 1 * s, 3 * s);
  g.fillStyle = INK; g.font = `650 ${11 * s}px Archivo, sans-serif`; g.fillText(nice >= 1000 ? nice / 1000 + ' km' : nice + ' m', x + 24 * s, y + h - 28 * s);
  const cx = x + w - 30 * s, cy = y + 34 * s; g.fillStyle = 'rgba(251,252,250,.92)'; g.beginPath(); g.arc(cx, cy, 20 * s, 0, 7); g.fill();
  g.fillStyle = INK; g.beginPath(); g.moveTo(cx, cy - 14 * s); g.lineTo(cx + 8 * s, cy + 9 * s); g.lineTo(cx, cy + 4 * s); g.lineTo(cx - 8 * s, cy + 9 * s); g.closePath(); g.fill();
  g.font = `700 ${10 * s}px Archivo, sans-serif`; g.textAlign = 'center'; g.fillText('N', cx, cy - 16 * s + 0); g.textAlign = 'left';
}
async function snapshotMap(extra, s = 2) {
  const box = map.getContainer().getBoundingClientRect(), sz = map.getSize(), cv = el('canvas'); cv.width = sz.x * s; cv.height = sz.y * s;
  const g = cv.getContext('2d'); let tainted = false;
  const paint = withTiles => {
    g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.fillStyle = '#EDF1EB'; g.fillRect(0, 0, cv.width, cv.height);
    if (withTiles) for (const sel of ['.leaflet-tile-pane img.leaflet-tile', '.leaflet-maps-pane img.leaflet-tile']) document.querySelectorAll(sel).forEach(img => {
      if (!img.complete || !img.naturalWidth) return; const r = img.getBoundingClientRect(), lay = img.closest('.leaflet-layer');
      g.globalAlpha = (lay ? +getComputedStyle(lay).opacity : 1) * (+getComputedStyle(img).opacity || 1); g.drawImage(img, (r.left - box.left) * s, (r.top - box.top) * s, r.width * s, r.height * s);
    });
    for (const o of S.overlays) {
      const l = ovLayers[o.id]; if (o.hidden || o.type !== 'image' || !l || !l._img || !l._img.naturalWidth) continue;
      const i = l._img, W = i.naturalWidth, H = i.naturalHeight, [a, b, c] = o.corners.map(q => map.latLngToContainerPoint(q));
      g.globalAlpha = o.opacity; g.setTransform(s * (b.x - a.x) / W, s * (b.y - a.y) / W, s * (c.x - a.x) / H, s * (c.y - a.y) / H, s * a.x, s * a.y); g.drawImage(i, 0, 0); g.setTransform(1, 0, 0, 1, 0, 0);
    }
    g.globalAlpha = 1;
  };
  paint(true); try { g.getImageData(0, 0, 1, 1); } catch (e) { tainted = true; paint(false); }
  drawFeatures(g, ll => { const p = map.latLngToContainerPoint([ll[0], ll[1]]); return [p.x * s, p.y * s]; }, s, extra);
  if (last) { const p = map.latLngToContainerPoint([last.lat, last.lon]); g.beginPath(); g.arc(p.x * s, p.y * s, 8 * s, 0, 7); g.fillStyle = '#1D6FB8'; g.fill(); g.lineWidth = 3 * s; g.strokeStyle = '#fff'; g.stroke(); }
  const c0 = map.getCenter(), c1 = map.containerPointToLatLng([sz.x / 2 + 100, sz.y / 2]), mpp = hav([c0.lat, c0.lng], [c1.lat, c1.lng]) / 100 / s;
  const ll = p => { const q = map.containerPointToLatLng(p); return [q.lat, q.lng]; };
  return { cv, s, mpp, corners: [ll([0, 0]), ll([sz.x, 0]), ll([0, sz.y])], tainted };
}
async function waitMap() { // let tiles and maps finish drawing
  await new Promise(r => { let done = false; const fin = () => { if (!done) { done = true; r(); } }; if (baseLayer && baseLayer.isLoading && baseLayer.isLoading()) baseLayer.once('load', fin); else setTimeout(fin, 150); setTimeout(fin, 4000); });
  await new Promise(r => setTimeout(r, 350));
}
async function withView(bounds, fn, fw = 1100, fh = 780) { // briefly render the live map in a print-shaped frame (north up), then restore the user's view
  const box = map.getContainer(), old = box.getAttribute('style'), c = map.getCenter(), z = map.getZoom(), bear = map.getBearing ? map.getBearing() : 0;
  if (bear && map.setBearing) map.setBearing(0);
  Object.assign(box.style, { right: 'auto', bottom: 'auto', width: fw + 'px', height: fh + 'px' }); map.invalidateSize({ animate: false });
  if (bounds) map.fitBounds(bounds, { animate: false, padding: [40, 40], maxZoom: 18 }); else map.setView(c, z, { animate: false });
  await waitMap();
  try { return await fn(); } finally { if (old) box.setAttribute('style', old); else box.removeAttribute('style'); map.invalidateSize({ animate: false }); map.setView(c, z, { animate: false }); if (bear && map.setBearing) map.setBearing(bear); }
}
async function loadImg(u) { const i = new Image(); i.src = u; await i.decode(); return i; }
const PAPER_PX = { a4p: [1240, 1754], a4l: [1754, 1240], a3p: [1754, 2480], a3l: [2480, 1754] };
async function reportPage({ title, sub, snap, rows, chartT, photos, legend, paper = 'a4p' }) { // 150 dpi
  const [W, H] = PAPER_PX[paper] || PAPER_PX.a4p, cv = el('canvas'); cv.width = W; cv.height = H; const g = cv.getContext('2d'), M = 70;
  try { await document.fonts.load('650 20px Archivo'); } catch (e) { }
  g.fillStyle = PAPER; g.fillRect(0, 0, W, H);
  g.fillStyle = INK; g.fillRect(0, 0, W, 170); g.fillStyle = FLAG; g.fillRect(0, 170, W, 8);
  g.fillStyle = '#F1F5EF'; g.font = '680 50px Archivo, sans-serif'; if ('fontStretch' in g) g.fontStretch = 'semi-expanded';
  let t = title; while (g.measureText(t).width > W - 2 * M && t.length > 4) t = t.slice(0, -2) + '…'; g.fillText(t, M, 90);
  if ('fontStretch' in g) g.fontStretch = 'normal'; g.font = '500 25px Archivo, sans-serif'; g.fillStyle = 'rgba(241,245,239,.8)'; g.fillText(sub, M, 135);
  let y = 214; const mw = W - 2 * M, ar = snap.cv.height / snap.cv.width, maxH = Math.round((H - 214 - 120) * (rows.length > 6 || photos.length || legend ? .62 : .72));
  let dw = mw, dh = mw * ar; if (dh > maxH) { dh = maxH; dw = dh / ar; } const dx = M + (mw - dw) / 2;
  g.drawImage(snap.cv, dx, y, dw, dh); const k = dw / snap.cv.width; scaleNorth(g, dx, y, dw, dh, snap.mpp / k, 1.6);
  g.strokeStyle = INK; g.lineWidth = 2; g.strokeRect(dx, y, dw, dh); const mapRect = [dx, y, dw, dh]; y += dh + 44;
  const col = (W - 2 * M - 40) / 2; g.font = '500 23px Archivo, sans-serif';
  rows.slice(0, 14).forEach(([k2, v], i) => {
    const cx = M + (i % 2) * (col + 40), cy = y + Math.floor(i / 2) * 64;
    g.fillStyle = INK2; g.font = '560 19px Archivo, sans-serif'; g.fillText(k2, cx, cy);
    g.fillStyle = INK; g.font = '620 25px Archivo, sans-serif'; let vv = String(v); while (g.measureText(vv).width > col && vv.length > 4) vv = vv.slice(0, -2) + '…'; g.fillText(vv, cx, cy + 30);
    g.fillStyle = RULE; g.fillRect(cx, cy + 44, col, 1.5);
  });
  y += Math.ceil(Math.min(rows.length, 14) / 2) * 64 + 20;
  if (chartT) {
    const mode = chartT.pts.some(p => p[2] != null) ? 'ele' : 'speed', pts = series(chartT, mode), ch = 190;
    if (pts.length > 1 && y + ch + 40 < H - 90) {
      g.fillStyle = INK2; g.font = '560 19px Archivo, sans-serif'; g.fillText(mode === 'ele' ? 'Elevation profile (m)' : 'Speed (km/h)', M, y); y += 14;
      const vs = pts.map(p => p[1]), mn = Math.min(...vs), mx = Math.max(...vs), rg = Math.max(mx - mn, 1e-6), D = pts[pts.length - 1][0] || 1, X = d => M + d / D * mw, Y = v => y + ch - (v - mn) / rg * (ch - 20);
      g.beginPath(); pts.forEach(([d, v], i) => i ? g.lineTo(X(d), Y(v)) : g.moveTo(X(d), Y(v))); g.lineTo(X(D), y + ch); g.lineTo(M, y + ch); g.closePath(); g.fillStyle = chartT.color + '33'; g.fill();
      g.beginPath(); pts.forEach(([d, v], i) => i ? g.lineTo(X(d), Y(v)) : g.moveTo(X(d), Y(v))); g.strokeStyle = chartT.color; g.lineWidth = 3.5; g.stroke();
      g.fillStyle = INK2; g.font = '500 18px Archivo, sans-serif'; g.fillText(Math.round(mx) + '', M + 6, y + 18); g.fillText(Math.round(mn) + '', M + 6, y + ch - 6); g.textAlign = 'right'; g.fillText(fmtD(D), M + mw, y + ch + 24); g.textAlign = 'left';
      y += ch + 50;
    }
  }
  if (legend && legend.length && y < H - 160) {
    g.fillStyle = INK2; g.font = '560 19px Archivo, sans-serif'; g.fillText('On this map', M, y); y += 20;
    legend.slice(0, Math.floor((H - 120 - y) / 40)).forEach(f => {
      g.fillStyle = f.color; if (f.lat != null) { g.beginPath(); g.arc(M + 14, y + 16, 9, 0, 7); g.fill(); } else if (f.kind === 'area') { g.globalAlpha = .35; g.fillRect(M, y + 6, 30, 20); g.globalAlpha = 1; g.strokeStyle = f.color; g.lineWidth = 3; g.strokeRect(M, y + 6, 30, 20); } else { g.fillRect(M, y + 13, 30, 6); }
      g.fillStyle = INK; g.font = '600 21px Archivo, sans-serif'; g.fillText(f.name, M + 46, y + 23); const nw = g.measureText(f.name).width;
      g.fillStyle = INK2; g.font = '500 19px Archivo, sans-serif'; g.fillText(f.lat != null ? fmtC(f.lat, f.lon) : featSummary(f), M + 60 + nw, y + 23); y += 40;
    });
  }
  if (photos.length && y < H - 300) {
    const pw = (mw - 40) / 3, ph = Math.min(pw * .75, H - 110 - y);
    for (let i = 0; i < Math.min(3, photos.length); i++) { const u = await photoURL(photos[i]); if (!u) continue; const im = await loadImg(u), x = M + i * (pw + 20), sc = Math.max(pw / im.width, ph / im.height), sw = pw / sc, sh = ph / sc;
      g.save(); g.beginPath(); g.roundRect ? g.roundRect(x, y, pw, ph, 12) : g.rect(x, y, pw, ph); g.clip(); g.drawImage(im, (im.width - sw) / 2, (im.height - sh) / 2, sw, sh, x, y, pw, ph); g.restore(); }
  }
  g.fillStyle = RULE; g.fillRect(M, H - 86, mw, 1.5); g.fillStyle = INK2; g.font = '500 18px Archivo, sans-serif';
  g.fillText(`Trail Atlas · WGS 84 · ${new Date().toLocaleString('en-GB')}` + (snap.tainted ? ' · base map omitted' : ''), M, H - 50);
  return { cv, mapRect, corners: snap.corners };
}
const visibleIn = b => [...S.tracks.filter(t => !t.hidden && t.pts.some(p => b.contains([p[0], p[1]]))), ...S.wpts.filter(w => !w.hidden && b.contains([w.lat, w.lon]))];
async function mapReport(o = {}) {
  const [PW, PH] = PAPER_PX[o.paper] || PAPER_PX.a4p, fw = PW - 140, fh = Math.round((PH - 334) * .62);
  const snap = await withView(null, () => snapshotMap(null, 1), fw, fh), c = map.getCenter(), sz = { x: fw }, denom = Math.round(snap.mpp * snap.s * sz.x / (fw / 150 * .0254) / 100) * 100;
  const open = S.overlays.filter(o => !o.hidden).map(o => o.name).join(', '), fb = L.latLngBounds([...snap.corners, brOf(snap.corners)]);
  return reportPage({ paper: o.paper, title: o.title || open || 'Map', sub: `${fmtC(c.lat, c.lng)} · scale about 1:${denom.toLocaleString('en-GB')}`, snap,
    rows: [['Centre', fmtC(c.lat, c.lng)], [`Scale (${(o.paper || 'a4p').slice(0, 2).toUpperCase()} print)`, '1 : ' + denom.toLocaleString('en-GB')], ['Base map', BASES[S.set.base].n], ['Items shown', visibleIn(fb).length + '']], chartT: null, photos: [], legend: visibleIn(fb) });
}
function featRows(f, kind) {
  const r = [];
  if (kind === 'wpt') { r.push(['Lat, lon', `${f.lat.toFixed(6)}, ${f.lon.toFixed(6)}`], ['UTM', utm(f.lat, f.lon)], ['MGRS', mgrs(f.lat, f.lon)], ['DMS', `${dms(f.lat, 'N', 'S')} ${dms(f.lon, 'E', 'W')}`]); if (f.address) r.push(['Address', f.address]); r.push(['Category', ICONS[f.icon] || 'Pin'], ['Created', new Date(f.t || Date.now()).toLocaleString('en-GB')]); }
  else if (f.kind === 'area') { const a = areaOf(f.pts); r.push(['Area', `${(a / 1e4).toFixed(3)} ha`], ['Area (m²)', Math.round(a).toLocaleString('en-GB')], ['Perimeter', fmtD(pathLen([...f.pts, f.pts[0]]))], ['Corner points', f.pts.length + '']); }
  else if (f.kind === 'line') { r.push(['Distance', fmtD(pathLen(f.pts))], ['Estimate', featSummary(f).split(' · ').slice(1).join(', ') || '—']); }
  else { const st = trackStats(f); r.push(['Distance', fmtD(st.d)], ['Duration', st.dur ? fmtT(st.dur) : '—'], ['Moving time', st.moving ? fmtT(st.moving) : '—'], ['Average speed', st.avg ? fmtV(st.avg) : '—'], ['Climb / descent', st.mx != null ? `${Math.round(st.up)} m / ${Math.round(st.down)} m` : '—'], ['Elevation', st.mx != null ? `${Math.round(st.mn)}–${Math.round(st.mx)} m` : '—']); if (f.pts[0][3]) r.push(['Started', new Date(f.pts[0][3]).toLocaleString('en-GB')]); }
  if (f.folder) r.push(['Layer', f.folder]);
  for (const [k, v] of Object.entries(f.attrs || {})) if (v !== '') r.push([k, v]);
  if (f.note) r.push(['Notes', f.note]);
  return r;
}
async function featReport(f, kind) {
  const b = kind === 'wpt' ? L.latLng(f.lat, f.lon).toBounds(300) : L.latLngBounds(feat(f));
  const snap = await withView(b, () => snapshotMap(f, 1));
  const type = kind === 'wpt' ? (ICONS[f.icon] || 'Waypoint') : { area: 'Area', line: 'Planned route' }[f.kind] || 'Recorded track';
  return reportPage({ title: f.name, sub: kind === 'wpt' ? `${type} · ${fmtC(f.lat, f.lon)}` : f.kind === 'area' ? featSummary(f) : `${type} · ${featSummary(f)}`, snap, rows: featRows(f, kind), chartT: kind !== 'wpt' && f.kind !== 'area' ? f : null, photos: f.photos || [], legend: null });
}
const jpgBlob = cv => new Promise(r => cv.toBlob(r, 'image/jpeg', .9));
async function toKMZ(tracks, wpts) {
  const files = {}, enc = new TextEncoder();
  for (const id of [...tracks, ...wpts].flatMap(x => x.photos || [])) { const b = await kvGet('ph:' + id); if (b) files[`files/${id}.jpg`] = new Uint8Array(await b.arrayBuffer()); }
  files['doc.kml'] = enc.encode(toKML(tracks, wpts, true));
  return zip(Object.fromEntries([['doc.kml', files['doc.kml']], ...Object.entries(files).filter(([k]) => k !== 'doc.kml')]));
}
async function shareMenu(f, kind) {
  const busy = async (btn, fn) => { const t = btn.textContent; btn.disabled = true; btn.textContent = 'Preparing…'; try { await fn(); } catch (e) { toast('Could not create the file: ' + e.message, 5000); } finally { btn.disabled = false; btn.textContent = t; } };
  const opt = (title, desc, fn) => { const b = el('button', { class: 'btn', style: 'width:100%;justify-content:flex-start;text-align:left;flex-direction:column;align-items:flex-start;gap:2px;padding:12px 14px;margin:6px 0' }, el('b', {}, title), el('span', { class: 'mut' }, desc)); b.onclick = () => busy(b.firstChild, fn); return b; };
  const base = f ? fname(f.name) : 'map-' + new Date().toISOString().slice(0, 10);
  const items = f ? [f] : null, T = items ? (kind === 'wpt' ? [] : items) : S.tracks.filter(t => !t.hidden), Wp = items ? (kind === 'wpt' ? items : []) : S.wpts.filter(w => !w.hidden);
  const ttl = el('input', { type: 'text', placeholder: 'Title (optional)', value: S.overlays.filter(o => !o.hidden).map(o => o.name).join(', ') }), pap = el('select'); [['a4p', 'A4 portrait'], ['a4l', 'A4 landscape'], ['a3p', 'A3 portrait'], ['a3l', 'A3 landscape']].forEach(([v, n]) => pap.append(el('option', { value: v }, n))); pap.value = S.set.paper || 'a4p'; pap.onchange = () => { S.set.paper = pap.value; save.set(); };
  const mo = () => ({ paper: pap.value, title: ttl.value.trim() });
  modal(f ? 'Share ' + f.name : 'Share this map', f ? '' : el('div', { class: 'row', style: 'flex-wrap:nowrap' }, ttl, pap),
    opt('PDF ' + (f ? 'report' : 'map'), f ? 'One page with a map, measurements, fields and photos. It opens in Avenza and other GeoPDF apps.' : 'The current view as a GeoPDF (choose paper above) with scale, north arrow and legend.', async () => { const r = f ? await featReport(f, kind) : await mapReport(mo()); await shareFile(base + '.pdf', await geoPdf(r.cv, r.mapRect, r.corners, f ? f.name : 'Map'), 'application/pdf'); }),
    opt('Image', 'The same page as a picture, easy to send on WhatsApp.', async () => { const r = f ? await featReport(f, kind) : await mapReport(mo()); await shareFile(base + '.jpg', await jpgBlob(r.cv), 'image/jpeg'); }),
    opt('KMZ with photos', 'For Google Earth, Avenza and GIS software.', async () => shareFile(base + '.kmz', await toKMZ(T, Wp), 'application/vnd.google-earth.kmz')),
    opt('GPX', 'For GPS devices and other tracking apps.', async () => shareFile(base + '.gpx', toGPX(T, Wp), 'application/gpx+xml')),
    (!f || kind === 'wpt') ? opt('Location link', 'A Google Maps link to ' + (f ? 'this point' : 'the crosshair') + '.', async () => { const p = f ? [f.lat, f.lon] : [map.getCenter().lat, map.getCenter().lng]; await shareText(f ? f.name : 'Location', `${f ? f.name + '\n' : ''}${fmtC(p[0], p[1])}\nhttps://www.google.com/maps?q=${p[0].toFixed(6)},${p[1].toFixed(6)}`); }) : '',
    el('div', { class: 'row act' }, el('button', { class: 'btn', onclick: closeModal }, 'Close')));
}


// ---------- Pro: Shapefile, GeoPackage, elevation, layers & schemas ----------
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = u => { let c = 0xFFFFFFFF; for (let i = 0; i < u.length; i++) c = CRC[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function zip(files) { // {name: Uint8Array} -> Blob (stored, no compression)
  const parts = [], cen = []; let off = 0;
  for (const [name, data] of Object.entries(files)) {
    const nb = new TextEncoder().encode(name), crc = crc32(data), h = new DataView(new ArrayBuffer(30));
    h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint32(14, crc, true); h.setUint32(18, data.length, true); h.setUint32(22, data.length, true); h.setUint16(26, nb.length, true);
    parts.push(new Uint8Array(h.buffer), nb, data);
    const c = new DataView(new ArrayBuffer(46)); c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint32(16, crc, true); c.setUint32(20, data.length, true); c.setUint32(24, data.length, true); c.setUint16(28, nb.length, true); c.setUint32(42, off, true);
    cen.push(new Uint8Array(c.buffer), nb); off += 30 + nb.length + data.length;
  }
  const cs = cen.reduce((n, x) => n + x.length, 0), e = new DataView(new ArrayBuffer(22)), n = Object.keys(files).length;
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, n, true); e.setUint16(10, n, true); e.setUint32(12, cs, true); e.setUint32(16, off, true);
  return new Blob([...parts, ...cen, new Uint8Array(e.buffer)], { type: 'application/zip' });
}
const PRJ = 'GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137.0,298.257223563]],PRIMEM["Greenwich",0.0],UNIT["Degree",0.0174532925199433]]';
function fieldsOf(items) { // attribute columns: name, folder, note + custom (max 10 chars, unique)
  const keys = ['name', 'folder', 'note', ...new Set(items.flatMap(x => Object.keys(x.attrs || {})))], used = new Set(), map_ = [];
  for (const k of keys) { let f = k.replace(/[^\w]/g, '_').slice(0, 10) || 'field', i = 1; while (used.has(f.toLowerCase())) f = f.slice(0, 8) + '_' + i++; used.add(f.toLowerCase()); map_.push([k, f]); }
  return map_;
}
const valOf = (x, k) => k === 'name' || k === 'folder' || k === 'note' ? (x[k] || '') : ((x.attrs || {})[k] ?? '');
function dbf(items, cols) {
  const enc = new TextEncoder(), rows = items.map(x => cols.map(([k]) => enc.encode(String(valOf(x, k))).slice(0, 254)));
  const w = cols.map((_, i) => Math.max(1, ...rows.map(r => r[i].length))), rl = 1 + w.reduce((a, b) => a + b, 0), hl = 32 + cols.length * 32 + 1;
  const b = new Uint8Array(hl + rl * items.length + 1), v = new DataView(b.buffer), d = new Date();
  b[0] = 3; b[1] = d.getFullYear() - 1900; b[2] = d.getMonth() + 1; b[3] = d.getDate(); v.setUint32(4, items.length, true); v.setUint16(8, hl, true); v.setUint16(10, rl, true);
  cols.forEach(([, f], i) => { const o = 32 + i * 32; for (let j = 0; j < f.length; j++) b[o + j] = f.charCodeAt(j); b[o + 11] = 67; b[o + 16] = w[i]; });
  b[hl - 1] = 13; let o = hl;
  rows.forEach(r => { b[o++] = 32; r.forEach((c, i) => { b.fill(32, o, o + w[i]); b.set(c, o); o += w[i]; }); });
  b[o] = 26; return b;
}
function shp(type, geoms) { // type 1 point, 3 polyline, 5 polygon; geoms: [[ [lat,lon]... ]] (one part each)
  const cl = g => type === 1 ? 20 : 44 + 4 + g.length * 16, tot = 100 + geoms.reduce((n, g) => n + 8 + cl(g), 0);
  const sb = new DataView(new ArrayBuffer(tot)), xb = new DataView(new ArrayBuffer(100 + geoms.length * 8));
  const all = geoms.flat(), bb = [Math.min(...all.map(p => p[1])), Math.min(...all.map(p => p[0])), Math.max(...all.map(p => p[1])), Math.max(...all.map(p => p[0]))];
  for (const [v, len] of [[sb, tot], [xb, 100 + geoms.length * 8]]) { v.setInt32(0, 9994); v.setInt32(24, len / 2); v.setInt32(28, 1000, true); v.setInt32(32, type, true); bb.forEach((x, i) => v.setFloat64(36 + i * 8, x, true)); }
  let o = 100;
  geoms.forEach((g, i) => {
    const c = cl(g); xb.setInt32(100 + i * 8, o / 2); xb.setInt32(104 + i * 8, c / 2); sb.setInt32(o, i + 1); sb.setInt32(o + 4, c / 2); sb.setInt32(o + 8, type, true);
    if (type === 1) { sb.setFloat64(o + 12, g[0][1], true); sb.setFloat64(o + 20, g[0][0], true); }
    else { const xs = g.map(p => p[1]), ys = g.map(p => p[0]); [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)].forEach((x, k) => sb.setFloat64(o + 12 + k * 8, x, true));
      sb.setInt32(o + 44, 1, true); sb.setInt32(o + 48, g.length, true); sb.setInt32(o + 52, 0, true); g.forEach((p, k) => { sb.setFloat64(o + 56 + k * 16, p[1], true); sb.setFloat64(o + 64 + k * 16, p[0], true); }); }
    o += 8 + c;
  });
  return [new Uint8Array(sb.buffer), new Uint8Array(xb.buffer)];
}
function toShapefileZip(tracks, wpts) {
  const files = {}, enc = s => new TextEncoder().encode(s);
  const ring = t => { let r = [...t.pts.map(p => [p[0], p[1]])]; if (hav(r[0], r[r.length - 1]) > 0) r.push(r[0]); let s2 = 0; for (let i = 0; i < r.length - 1; i++) s2 += (r[i + 1][1] - r[i][1]) * (r[i + 1][0] + r[i][0]); return s2 < 0 ? r.reverse() : r; }; // outer ring clockwise
  const layer = (nm, type, items, geom) => { if (!items.length) return; const cols = fieldsOf(items), [a, b] = shp(type, items.map(geom)); Object.assign(files, { [nm + '.shp']: a, [nm + '.shx']: b, [nm + '.dbf']: dbf(items, cols), [nm + '.prj']: enc(PRJ), [nm + '.cpg']: enc('UTF-8') }); };
  layer('waypoints', 1, wpts, w => [[w.lat, w.lon]]);
  layer('lines', 3, tracks.filter(t => t.kind !== 'area'), t => t.pts.map(p => [p[0], p[1]]));
  layer('areas', 5, tracks.filter(t => t.kind === 'area'), ring);
  return zip(files);
}
function readShp(buf, toLL) { // -> [{type:'point'|'line'|'area', parts:[[lat,lon]...]}]
  const v = new DataView(buf), out = []; let o = 100;
  while (o + 8 <= buf.byteLength) {
    const len = v.getInt32(o + 4) * 2, t = v.getInt32(o + 8, true), b = o + 12, base = t % 10;
    if (base === 1) out.push({ type: 'point', parts: [[toLL(v.getFloat64(b, true), v.getFloat64(b + 8, true))]] });
    else if (base === 8) { const n = v.getInt32(b + 32, true); for (let i = 0; i < n; i++) out.push({ type: 'point', parts: [[toLL(v.getFloat64(b + 36 + i * 16, true), v.getFloat64(b + 44 + i * 16, true))]] }); }
    else if (base === 3 || base === 5) {
      const np = v.getInt32(b + 32, true), n = v.getInt32(b + 36, true), ps = [...Array(np)].map((_, i) => v.getInt32(b + 40 + i * 4, true)), p0 = b + 40 + np * 4, parts = [];
      for (let i = 0; i < np; i++) { const a = []; for (let k = ps[i]; k < (i + 1 < np ? ps[i + 1] : n); k++) a.push(toLL(v.getFloat64(p0 + k * 16, true), v.getFloat64(p0 + k * 16 + 8, true))); parts.push(a); }
      out.push({ type: base === 5 ? 'area' : 'line', parts });
    } else out.push(null);
    o += 8 + len;
  }
  return out;
}
function readDbf(u) {
  const v = new DataView(u.buffer, u.byteOffset), n = v.getUint32(4, true), hl = v.getUint16(8, true), rl = v.getUint16(10, true), cols = [], dec = new TextDecoder();
  for (let o = 32; u[o] !== 13 && o < hl; o += 32) cols.push({ name: dec.decode(u.slice(o, o + 11)).replace(/\0.*$/, '').trim(), len: u[o + 16] });
  return [...Array(n)].map((_, r) => { let o = hl + r * rl + 1; const rec = {}; cols.forEach(c => { rec[c.name] = dec.decode(u.slice(o, o + c.len)).trim(); o += c.len; }); return rec; });
}
function prjToLL(prj) {
  if (!prj || !/PROJCS/i.test(prj)) return (x, y) => [y, x];
  const m = prj.match(/UTM[_ ]zone[_ ](\d+)\s*([NS])/i); if (m) return (x, y) => utmInv(+m[1], m[2].toUpperCase() === 'S', x, y);
  if (/Mercator_Auxiliary_Sphere|Pseudo.Mercator|3857/i.test(prj)) return mercInv;
  throw Error('Shapefile projection not supported yet (WGS84 degrees, UTM and Web Mercator are)');
}
async function importShpZip(f) {
  const files = await unzip(await f.arrayBuffer()), o = { tracks: [], wpts: [] }, dec = new TextDecoder(); let found = 0;
  for (const n of Object.keys(files).filter(n => /\.shp$/i.test(n))) {
    const base = n.slice(0, -4), get = ext => files[Object.keys(files).find(k => k.toLowerCase() === (base + ext).toLowerCase())];
    const toLL = prjToLL(get('.prj') ? dec.decode(get('.prj')) : ''), sh = readShp(files[n].slice().buffer, toLL), recs = get('.dbf') ? readDbf(get('.dbf')) : [];
    sh.forEach((g, i) => {
      if (!g) return; const r = recs[i] || {}, nk = Object.keys(r).find(k => /^(name|nama|title|label)$/i.test(k)), name = nk ? r[nk] : '', attrs = Object.fromEntries(Object.entries(r).filter(([k, v]) => k !== nk && v !== '' && !/^(folder|note)$/i.test(k))), note = r.note || r.NOTE || '';
      if (g.type === 'point') o.wpts.push({ name, lat: g.parts[0][0][0], lon: g.parts[0][0][1], note, attrs });
      else g.parts.forEach(p => p.length > 1 && o.tracks.push({ name, pts: p.map(q => [q[0], q[1], null, null]), kind: g.type === 'area' ? 'area' : 'line', note, attrs }));
      found++;
    });
  }
  if (!found) throw Error('no Shapefile (.shp) inside the zip');
  mergeImport(o, f.name);
}
async function sqljs() { await loadScript('lib/sql-wasm.js'); return initSqlJs({ locateFile: x => 'lib/' + x }); }
function gpGeom(type, pts) { // GeoPackage binary: header + little-endian WKB
  const n = type === 1 ? 21 : type === 2 ? 9 + pts.length * 16 : 13 + pts.length * 16, b = new DataView(new ArrayBuffer(8 + n));
  b.setUint8(0, 0x47); b.setUint8(1, 0x50); b.setUint8(2, 0); b.setUint8(3, 1); b.setInt32(4, 4326, true); b.setUint8(8, 1); b.setUint32(9, type, true);
  let o = 13; if (type === 2) { b.setUint32(o, pts.length, true); o += 4; } if (type === 3) { b.setUint32(o, 1, true); b.setUint32(o + 4, pts.length, true); o += 8; }
  pts.forEach(p => { b.setFloat64(o, p[1], true); b.setFloat64(o + 8, p[0], true); o += 16; }); return new Uint8Array(b.buffer);
}
async function toGeoPackage(tracks, wpts) {
  const SQL = await sqljs(), d = new SQL.Database();
  d.run(`PRAGMA application_id=1196444487; PRAGMA user_version=10300;
    CREATE TABLE gpkg_spatial_ref_sys (srs_name TEXT NOT NULL, srs_id INTEGER PRIMARY KEY, organization TEXT NOT NULL, organization_coordsys_id INTEGER NOT NULL, definition TEXT NOT NULL, description TEXT);
    CREATE TABLE gpkg_contents (table_name TEXT NOT NULL PRIMARY KEY, data_type TEXT NOT NULL, identifier TEXT UNIQUE, description TEXT DEFAULT '', last_change DATETIME NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')), min_x DOUBLE, min_y DOUBLE, max_x DOUBLE, max_y DOUBLE, srs_id INTEGER);
    CREATE TABLE gpkg_geometry_columns (table_name TEXT NOT NULL, column_name TEXT NOT NULL, geometry_type_name TEXT NOT NULL, srs_id INTEGER NOT NULL, z TINYINT NOT NULL, m TINYINT NOT NULL, CONSTRAINT pk_geom_cols PRIMARY KEY (table_name, column_name));`);
  d.run(`INSERT INTO gpkg_spatial_ref_sys VALUES ('Undefined cartesian SRS',-1,'NONE',-1,'undefined',NULL),('Undefined geographic SRS',0,'NONE',0,'undefined',NULL),('WGS 84 geodetic',4326,'EPSG',4326,?,NULL)`, [PRJ]);
  const layer = (tn, gt, gname, items, geom) => {
    if (!items.length) return; const cols = fieldsOf(items), all = items.flatMap(geom);
    d.run(`CREATE TABLE "${tn}" (fid INTEGER PRIMARY KEY AUTOINCREMENT, geom ${gname}, ${cols.map(([, f]) => `"${f}" TEXT`).join(', ')})`);
    d.run(`INSERT INTO gpkg_contents (table_name, data_type, identifier, min_x, min_y, max_x, max_y, srs_id) VALUES (?, 'features', ?, ?, ?, ?, ?, 4326)`, [tn, tn, Math.min(...all.map(p => p[1])), Math.min(...all.map(p => p[0])), Math.max(...all.map(p => p[1])), Math.max(...all.map(p => p[0]))]);
    d.run(`INSERT INTO gpkg_geometry_columns VALUES (?, 'geom', ?, 4326, 0, 0)`, [tn, gname]);
    const st = d.prepare(`INSERT INTO "${tn}" (geom, ${cols.map(([, f]) => `"${f}"`).join(', ')}) VALUES (?, ${cols.map(() => '?').join(', ')})`);
    items.forEach(x => st.run([gpGeom(gt, geom(x)), ...cols.map(([k]) => String(valOf(x, k)))])); st.free();
  };
  layer('waypoints', 1, 'POINT', wpts, w => [[w.lat, w.lon]]);
  layer('lines', 2, 'LINESTRING', tracks.filter(t => t.kind !== 'area'), t => t.pts.map(p => [p[0], p[1]]));
  layer('areas', 3, 'POLYGON', tracks.filter(t => t.kind === 'area'), t => [...t.pts, t.pts[0]].map(p => [p[0], p[1]]));
  const out = d.export(); d.close(); return new Blob([out], { type: 'application/geopackage+sqlite3' });
}
function readWKB(u, toLL) { // -> [{type, parts}] (points, lines, polygons and multi-*)
  const v = new DataView(u.buffer, u.byteOffset, u.byteLength), out = []; let o = 0;
  const rd = () => {
    const le = v.getUint8(o) === 1; o++; const t = v.getUint32(o, le) % 1000; o += 4;
    const pt = () => { const x = v.getFloat64(o, le), y = v.getFloat64(o + 8, le); o += 16; return toLL(x, y); };
    const ln = () => { const n = v.getUint32(o, le); o += 4; return [...Array(n)].map(pt); };
    if (t === 1) out.push({ type: 'point', parts: [[pt()]] }); else if (t === 2) out.push({ type: 'line', parts: [ln()] });
    else if (t === 3) { const n = v.getUint32(o, le); o += 4; const rings = [...Array(n)].map(ln); out.push({ type: 'area', parts: [rings[0]] }); }
    else if (t >= 4 && t <= 7) { const n = v.getUint32(o, le); o += 4; for (let i = 0; i < n; i++) rd(); }
    else throw Error('unsupported geometry type ' + t);
  };
  rd(); return out;
}
async function importGpkg(f) {
  const SQL = await sqljs(), d = new SQL.Database(new Uint8Array(await f.arrayBuffer())), o = { tracks: [], wpts: [] };
  const gc = d.exec('SELECT table_name, column_name, srs_id FROM gpkg_geometry_columns')[0]; if (!gc) throw Error('no feature tables');
  for (const [tn, col, srs] of gc.values) {
    const toLL = srs === 4326 || srs === 0 ? (x, y) => [y, x] : srs >= 32601 && srs <= 32660 ? (x, y) => utmInv(srs - 32600, false, x, y) : srs >= 32701 && srs <= 32760 ? (x, y) => utmInv(srs - 32700, true, x, y) : srs === 3857 ? mercInv : null;
    if (!toLL) { toast(`Table ${tn}: coordinate system ${srs} not supported, skipped`); continue; }
    const r = d.exec(`SELECT * FROM "${tn}"`)[0]; if (!r) continue; const gi = r.columns.indexOf(col);
    for (const row of r.values) {
      const g = row[gi]; if (!g) continue; const fl = g[3], env = [0, 32, 48, 48, 64][(fl >> 1) & 7] || 0;
      const attrs = {}; r.columns.forEach((c, i) => { if (i !== gi && c !== 'fid' && row[i] != null && row[i] !== '') attrs[c] = String(row[i]); });
      const nk = Object.keys(attrs).find(k => /^(name|nama|title)$/i.test(k)), name = nk ? attrs[nk] : '', note = attrs.note || ''; if (nk) delete attrs[nk]; delete attrs.note; delete attrs.folder;
      for (const gg of readWKB(g.subarray(8 + env), toLL)) gg.type === 'point' ? o.wpts.push({ name, lat: gg.parts[0][0][0], lon: gg.parts[0][0][1], note, attrs }) : o.tracks.push({ name, pts: gg.parts[0].map(q => [q[0], q[1], null, null]), kind: gg.type, note, attrs });
    }
  }
  d.close(); if (!o.tracks.length && !o.wpts.length) throw Error('no features found'); mergeImport(o, f.name);
}
async function fetchElevation(t) { // fill missing elevations for planned routes / areas (Open-Meteo, free)
  const idx = t.pts.map((p, i) => i).filter((_, i, a) => a.length <= 300 || i % Math.ceil(a.length / 300) === 0 || i === a.length - 1);
  toast('Getting elevation…', 6000);
  try {
    for (let i = 0; i < idx.length; i += 100) {
      const ch = idx.slice(i, i + 100), r = await (await fetch(`https://api.open-meteo.com/v1/elevation?latitude=${ch.map(k => t.pts[k][0].toFixed(5)).join(',')}&longitude=${ch.map(k => t.pts[k][1].toFixed(5)).join(',')}`)).json();
      ch.forEach((k, j) => t.pts[k][2] = r.elevation[j]);
    }
    save.tracks(); render(); toast('Elevation added');
  } catch (e) { toast('Elevation lookup needs internet'); }
}
function manageLayers() { // folders as layers/projects: visibility, rename, attribute schema with picklists
  const box = el('div'), draw = () => {
    box.replaceChildren(...folders().map(fo => {
      const items = [...S.tracks, ...S.wpts, ...S.overlays].filter(x => x.folder === fo), hid = items.every(x => x.hidden), sc = S.schemas[fo] || [];
      return el('div', { class: 'item' }, el('div', { class: 't' }, '' + fo, el('span', { class: 'mut' }, ` ${items.length} items · ${sc.length} fields`)),
        el('div', { class: 'row' },
          el('button', { class: 'btn sm', onclick: () => { items.forEach(x => x.hidden = !hid); save.tracks(); save.wpts(); save.overlays(); drawTracks(); drawWpts(); drawOverlays(); draw(); } }, hid ? 'Show' : 'Hide'),
          el('button', { class: 'btn sm', onclick: () => { const n = prompt('Rename layer:', fo); if (n && n.trim() && n !== fo) { items.forEach(x => x.folder = n.trim()); if (S.schemas[fo]) { S.schemas[n.trim()] = S.schemas[fo]; delete S.schemas[fo]; } save.tracks(); save.wpts(); save.overlays(); save.schemas(); draw(); } } }, 'Rename'),
          el('button', { class: 'btn sm', onclick: () => editSchema(fo, draw) }, 'Fields'),
          el('button', { class: 'btn sm', onclick: async () => shareFile(fname(fo) + '.kmz', await toKMZ(S.tracks.filter(x => x.folder === fo), S.wpts.filter(x => x.folder === fo)), 'application/vnd.google-earth.kmz') }, 'Share KMZ'),
          el('button', { class: 'btn sm dng', onclick: () => { if (confirm(`Remove layer "${fo}"? Items stay, they just leave the folder.`)) { items.forEach(x => x.folder = ''); delete S.schemas[fo]; save.tracks(); save.wpts(); save.overlays(); save.schemas(); draw(); } } }, '✕')));
    }));
    if (!folders().length) box.append(el('p', { class: 'mut' }, 'No layers yet. Type a folder name when editing a waypoint or track, or import a file (it gets its own layer).'));
  };
  draw();
  const nl = el('input', { type: 'text', placeholder: 'New layer name' });
  modal('Layers (folders / projects)', box, el('div', { class: 'row', style: 'flex-wrap:nowrap' }, nl, el('button', { class: 'btn', onclick: () => { const n = nl.value.trim(); if (!n) return; S.schemas[n] = S.schemas[n] || []; save.schemas(); editSchema(n, () => manageLayers()); } }, '+ Add')),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: () => dl('trail-atlas-schemas.json', JSON.stringify(S.schemas, null, 1), 'application/json') }, 'Export schemas'),
      fileBtn('Import schemas', '.json', async f => { try { Object.assign(S.schemas, JSON.parse(await f.text())); save.schemas(); toast('Schemas imported'); draw(); } catch (e) { toast('Bad schema file'); } }),
      el('button', { class: 'btn', onclick: () => { closeModal(); render(); } }, 'Close')));
}
function editSchema(fo, back) {
  const sc = (S.schemas[fo] || []).map(x => ({ ...x, options: [...(x.options || [])] })), box = el('div');
  const draw = () => box.replaceChildren(...sc.map((fd, i) => el('div', { class: 'item' },
    el('div', { class: 'row', style: 'flex-wrap:nowrap' }, el('input', { type: 'text', value: fd.name, placeholder: 'Field name', oninput: e => fd.name = e.target.value }),
      (() => { const s2 = el('select', { style: 'width:auto', onchange: e => { fd.type = e.target.value; draw(); } }, [['text', 'Text'], ['number', 'Number'], ['date', 'Date'], ['yesno', 'Yes / No'], ['picklist', 'Pick list']].map(([v, n]) => el('option', { value: v }, n))); s2.value = fd.type; return s2; })(),
      el('button', { class: 'btn sm dng', onclick: () => { sc.splice(i, 1); draw(); } }, '✕')),
    fd.type === 'picklist' ? el('input', { type: 'text', value: fd.options.join(', '), placeholder: 'Choices, separated by commas', oninput: e => fd.options = e.target.value.split(',').map(x => x.trim()).filter(Boolean) }) : '')));
  draw();
  modal('🧾 Fields for "' + fo + '"', el('p', { class: 'mut' }, 'Every item in this layer gets these fields in its details form, like an Avenza attribute schema.'), box,
    el('button', { class: 'btn sm', onclick: () => { sc.push({ name: 'Field ' + (sc.length + 1), type: 'text', options: [] }); draw(); } }, '+ Add field'),
    el('div', { class: 'row', style: 'margin-top:14px' }, el('button', { class: 'btn pri', onclick: () => { S.schemas[fo] = sc.filter(x => x.name.trim()).map(x => ({ ...x, name: x.name.trim() })); save.schemas(); toast('Fields saved'); back ? back() : closeModal(); if (back === undefined) render(); } }, 'Save'),
      el('button', { class: 'btn', onclick: () => back ? manageLayers() : closeModal() }, 'Back')));
}

// ---------- offline: download tiles ----------
const TILE_CACHE = 'tiles-v1';      // everything you look at, trimmed automatically
const NO_BULK_HOSTS = ['tile.openstreetmap.org', 'tile.opentopomap.org', 'tile-cyclosm.openstreetmap.fr', 'tile.openstreetmap.fr']; // their usage policies forbid saving areas for offline use
const bulkBlocked = base => { const b = BASES[base]; if (!b || !b.u) return false; try { return NO_BULK_HOSTS.some(h => new URL(b.u.replace(/\{[a-z]+\}/g, '0')).hostname.endsWith(h)); } catch (e) { return false; } };
const offlineBase = () => nightOn() && NIGHT[S.set.base] ? NIGHT[S.set.base] : S.set.base;
const mbPerTile = () => (BASES[offlineBase()] || {}).vec ? .08 : .025; // rough size of one tile: vector tiles are bigger than picture tiles
const OFF_CACHE = 'offline-v1';     // areas you downloaded on purpose, never trimmed
const lon2x = (lon, z) => Math.floor((lon + 180) / 360 * 2 ** z);
const lat2y = (lat, z) => Math.floor((1 - Math.log(Math.tan(rad(lat)) + 1 / Math.cos(rad(lat))) / Math.PI) / 2 * 2 ** z);
function tileList(bounds, z0, z1, base) {
  const out = []; if (!BASES[base].u) return out;
  for (let z = z0; z <= z1; z++) {
    const x0 = lon2x(bounds.getWest(), z), x1 = lon2x(bounds.getEast(), z), y0 = lat2y(bounds.getNorth(), z), y1 = lat2y(bounds.getSouth(), z);
    for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (const u of [BASES[base].u, BASES[base].over].filter(Boolean)) out.push(u.replace('{z}', z).replace('{x}', x).replace('{y}', y));
  }
  return out;
}
let dlAbort = false;
async function downloadTiles(list, bar, label) { // explicit downloads go to their own cache so automatic trimming never eats them
  const cache = await caches.open(OFF_CACHE), auto = await caches.open(TILE_CACHE); let done = 0, fail = 0; dlAbort = false;
  const q = [...list];
  await Promise.all(Array.from({ length: 6 }, async () => {
    while (q.length && !dlAbort) {
      const u = q.pop();
      try {
        if (!await cache.match(u)) {
          const hit = await auto.match(u);                       // already looked at it: copy, do not download twice
          const r = hit || await fetch(u, { mode: 'cors' });
          if (hit || (r && r.ok)) await cache.put(u, hit || r.clone()); else fail++;
        }
      } catch (e) { fail++; }
      done++; bar.style.width = (done / list.length * 100) + '%'; label.textContent = `${done}/${list.length}` + (fail ? ` (${fail} failed)` : '');
    }
  }));
  try { for (const u of list) { if (await auto.match(u)) await auto.delete(u); } } catch (e) { } // keep one copy only
  toast(dlAbort ? 'Stopped' : fail ? `Done, ${fail} tiles failed (retry when online)` : 'Offline map ready ✔');
  render();
}
async function cacheInfo() {
  if (!('caches' in window)) return { n: 0, off: 0, mb: 0, quota: 0 };
  let n = 0, off = 0, mb = 0, quota = 0;
  try { n = (await (await caches.open(TILE_CACHE)).keys()).length; } catch (e) { }
  try { off = (await (await caches.open(OFF_CACHE)).keys()).length; } catch (e) { }
  try { const e = await navigator.storage.estimate(); mb = (e.usage || 0) / 1048576; quota = (e.quota || 0) / 1048576; } catch (e) { }
  return { n, off, mb, quota };
}

// ---------- search place / coordinates ----------
async function search(q) {
  const m = q.match(/^\s*(-?\d+(\.\d+)?)\s*[, ]\s*(-?\d+(\.\d+)?)\s*$/);
  if (m && Math.abs(+m[1]) <= 90 && Math.abs(+m[3]) <= 180) { map.setView([+m[1], +m[3]], 16); return toast('Going to coordinates'); }
  const u = q.trim().match(/^(\d{1,2})\s*([NS])\s+(\d+(?:\.\d+)?)\s*E?\s+(\d+(?:\.\d+)?)\s*N?$/i);
  if (u) { const p = utmInv(+u[1], u[2].toUpperCase() === 'S', +u[3], +u[4]); map.setView(p, 16); return toast('Going to UTM position'); }
  try {
    const r = await (await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=5&q=' + encodeURIComponent(q))).json();
    if (!r.length) return toast('No results');
    return r;
  } catch (e) { toast('Search needs internet'); }
}

// ---------- panels ----------
let tab = 'map';
const listQ = {}, listSort = {}, collapsed = {}, listLimit = {};
function setTab(t) {
  tab = tab === t && t !== 'map' ? 'map' : t;
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.tab === tab)); render();
}
function render() {
  const s = $('#sheet'); s.classList.toggle('open', tab !== 'map'); s.replaceChildren(el('div', { class: 'sheethead' }, el('div', { class: 'grab' }), xBtn('Close panel', () => setTab('map'))));
  ({ tracks: viewTracks, wpts: viewWpts, layers: viewLayers, more: viewMore }[tab] || (() => { }))(s);
}
function fileBtn(label, accept, fn, multiple, cls = 'btn') {
  const i = el('input', { type: 'file', accept, hidden: '' }); if (multiple) i.multiple = true;
  i.onchange = async () => { for (const f of i.files) await fn(f); i.value = ''; };
  return el('button', { class: cls, onclick: () => i.click() }, label, i);
}
// dropdown action menu (⋯) used by list rows
const MORE_SVG = '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>';
const GO_SVG = '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor"><path d="M12 2 19 21 12 17 5 21Z"/></svg>';
function closeMenu() { const m = $('.menu'); if (m) { m.remove(); removeEventListener('pointerdown', closeMenu.out, true); removeEventListener('keydown', closeMenu.key); $('#sheet').removeEventListener('scroll', closeMenu); } }
function actionMenu(anchor, items, title) {
  closeMenu(); const m = el('div', { class: 'menu', role: 'menu' }); if (title) m.append(el('div', { class: 'menu-t' }, title));
  items.filter(Boolean).forEach(it => { if (it === '-') return m.append(el('hr')); const [label, fn, cls] = it; m.append(el('button', { class: 'btn mi ' + (cls || ''), role: 'menuitem', onclick: () => { closeMenu(); fn(); } }, label)); });
  document.body.append(m); const r = anchor.getBoundingClientRect(), h = m.offsetHeight, below = r.bottom + 6 + h < innerHeight - 90;
  m.style.left = Math.max(8, Math.min(innerWidth - m.offsetWidth - 8, r.right - m.offsetWidth)) + 'px'; m.style.top = (below ? r.bottom + 6 : Math.max(8, r.top - h - 6)) + 'px'; m.style.transformOrigin = below ? 'top right' : 'bottom right';
  closeMenu.out = e => { if (!m.contains(e.target) && e.target !== anchor && !anchor.contains(e.target)) { closeMenu(); const swallow = ev => { ev.stopPropagation(); ev.preventDefault(); }; addEventListener('click', swallow, { capture: true, once: true }); setTimeout(() => removeEventListener('click', swallow, true), 600); } }; closeMenu.key = e => { if (e.key === 'Escape') { closeMenu(); anchor.focus(); } };
  setTimeout(() => { addEventListener('pointerdown', closeMenu.out, true); addEventListener('keydown', closeMenu.key); $('#sheet').addEventListener('scroll', closeMenu, { once: true }); }, 0);
  m.querySelector('button').focus({ preventScroll: true });
}
function rowShell(main, onMain, goLabel, onGo, menuItems, menuTitle) { // compact list row: tap the name, quick "go" button, and a ⋯ dropdown
  const it = el('div', { class: 'item irow' }), m = el('div', { class: 'imain', role: 'button', tabindex: '0', onclick: onMain, onkeydown: e => { if (e.key === 'Enter') onMain(); } }, ...main), act = el('div', { class: 'iact' });
  if (onGo) { const g = el('button', { class: 'ibtn go', 'aria-label': goLabel, title: goLabel, onclick: e => { e.stopPropagation(); onGo(); } }); g.innerHTML = GO_SVG; act.append(g); }
  const more = el('button', { class: 'ibtn', 'aria-label': 'More actions for ' + menuTitle, 'aria-haspopup': 'menu', title: 'More actions', onclick: e => { e.stopPropagation(); $('.menu') ? closeMenu() : actionMenu(more, menuItems(), menuTitle); } }); more.innerHTML = MORE_SVG; act.append(more);
  it.append(m, act); return it;
}
const X_SVG = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>';
function xBtn(label, fn) { const b = el('button', { class: 'xbtn', 'aria-label': label, title: label, onclick: fn }); b.innerHTML = X_SVG; return b; }
const refPt = () => last ? [last.lat, last.lon] : [map.getCenter().lat, map.getCenter().lng];
// grouped, searchable, sortable list (folders = Avenza layers / NomadTracks folders)
function groupedList(s, kind, items, row, posOf, onVis) {
  const q = el('input', { type: 'search', placeholder: 'Search…', value: listQ[kind] || '' }), so = el('select', { style: 'width:auto' }), out = el('div');
  [['new', 'Newest'], ['name', 'Name'], ['near', 'Nearest']].forEach(([v, n]) => so.append(el('option', { value: v }, n))); so.value = listSort[kind] || 'new';
  const draw = () => {
    listQ[kind] = q.value; listSort[kind] = so.value; const ql = q.value.toLowerCase(), rp = refPt();
    let list = items().filter(x => !ql || (x.name + ' ' + (x.note || '') + ' ' + (x.folder || '') + ' ' + Object.values(x.attrs || {}).join(' ')).toLowerCase().includes(ql));
    const dist = x => { const p = posOf(x); return p ? hav(rp, p) : 1e12; };
    list.sort(so.value === 'name' ? (a, b) => a.name.localeCompare(b.name) : so.value === 'near' ? (a, b) => dist(a) - dist(b) : (a, b) => (b.t || b.created || b.added || 0) - (a.t || a.created || a.added || 0));
    const groups = {}; list.forEach(x => (groups[x.folder || ''] = groups[x.folder || ''] || []).push(x));
    out.replaceChildren(); const names = Object.keys(groups).sort((a, b) => a === '' ? -1 : b === '' ? 1 : a.localeCompare(b));
    const limit = ql ? 120 : (listLimit[kind] || 60); let shown = 0, hidden_ = 0;
    for (const f of names) {
      const g = groups[f], key = kind + ':' + f, allHidden = g.every(x => x.hidden);
      if (names.length > 1 || f) out.append(el('div', { class: 'fold' },
        el('span', { onclick: () => { collapsed[key] = !collapsed[key]; draw(); } }, (collapsed[key] ? '▸ ' : '▾ ') + (f || 'No folder') + ` (${g.length})`),
        onVis ? el('button', { class: 'btn sm', onclick: () => { g.forEach(x => x.hidden = !allHidden); onVis(); draw(); } }, allHidden ? 'Show all' : 'Hide all') : ''));
      if (!collapsed[key]) g.forEach(x => { if (shown < limit) { out.append(row(x)); shown++; } else hidden_++; });
    }
    if (hidden_) out.append(el('button', { class: 'btn', style: 'width:100%;margin:10px 0', onclick: () => { listLimit[kind] = (listLimit[kind] || 60) + 100; draw(); } }, `Show more (${hidden_} more${ql ? ' — refine the search to narrow down' : ''})`));
    if (!list.length) out.append(el('p', { class: 'mut' }, items().length ? 'Nothing matches the search.' : 'Nothing here yet.'));
  };
  q.oninput = () => { listLimit[kind] = 0; draw(); }; so.onchange = draw;
  s.append(items().length > 2 ? el('div', { class: 'row', style: 'flex-wrap:nowrap' }, q, so) : '', out); draw();
}
function viewTracks(s) {
  s.append(el('h3', {}, 'Tracks, routes & areas', el('span', { class: 'mut', style: 'font-size:12.5px;font-weight:660;letter-spacing:.02em;white-space:nowrap;background:var(--fill);border-radius:999px;padding:2px 8px;margin-left:8px;vertical-align:middle' }, `${S.tracks.length}`)), el('div', { class: 'row' },
    el('button', { class: 'btn go', onclick: () => { startRec(); setTab('map'); } }, rec.on ? 'Stop recording' : 'Record track'),
    el('button', { class: 'btn', onclick: () => startDraw('area') }, 'Draw area / route'),
    fileBtn('Import', '.gpx,.kml,.kmz,.geojson,.json,.csv,.zip,.gpkg', importFile, true), el('button', { class: 'btn', onclick: manageLayers }, 'Layers')));
  groupedList(s, 'tracks', () => S.tracks, t => {
    const st = t.kind === 'track' || !t.kind ? trackStats(t) : null, zoom = () => { t.hidden = false; drawTracks(); map.fitBounds(L.latLngBounds(feat(t)).pad(.1)); setTab('map'); };
    const meta = ({ area: 'Area', line: 'Planned route' }[t.kind] || 'Recorded track') + ' — ' + (st ? `${fmtD(st.d)}` + (st.dur ? ` · ${fmtT(st.dur)}` : '') + (st.avg ? ` · avg ${fmtV(st.avg)}` : '') + (st.mx != null ? ` · ↗ ${Math.round(st.up)} m` : '') : featSummary(t)) + ((t.photos || []).length ? ` — ${t.photos.length} photo${t.photos.length > 1 ? 's' : ''}` : '');
    const it = rowShell([el('div', { class: 't' }, legendSym(t), el('span', { class: 'nm' }, t.name)), el('div', { class: 'mut' }, meta)], zoom, 'Follow ' + t.name, t.kind !== 'area' ? () => startFollow(t) : null, () => [
      t.kind !== 'area' ? ['Follow', () => startFollow(t)] : null, ['Zoom to', zoom], [t.hidden ? 'Show on map' : 'Hide from map', () => { t.hidden = !t.hidden; save.tracks(); drawTracks(); render(); }],
      t.kind !== 'area' ? ['Elevation profile', () => profileUI(t)] : null,
      t.kind !== 'area' ? ['Beacons (numbered checkpoints)…', () => beaconUI(t)] : null,
      t.kind !== 'area' ? ['Reverse direction', () => reverseTrack(t)] : null,
      t.kind !== 'area' ? ['Join with another line…', () => joinTrack(t)] : null,
      t.kind !== 'area' ? ['Charts', () => { const c = it.querySelector('.charts'); c ? c.remove() : it.append(charts(t)); }] : null, '-',
      ['Details & tools', () => editFeature(t, 'track')], ['Share…', () => shareMenu(t, 'track')],
      ['Move to layer…', () => { const fo = prompt('Move to layer (folder):', t.folder || ''); if (fo != null) { t.folder = fo.trim(); save.tracks(); render(); } }], '-',
      ['Delete', () => { if (confirm('Delete "' + t.name + '"?')) delFeature(t, 'track'); }, 'dng']], t.name);
    return it;
  }, t => t.pts[0], () => { save.tracks(); drawTracks(); });
}

// ---------- tidy up a recorded line: reverse it, or join two pieces ----------
function reverseTrack(t) {
  const P = t.pts; if (!P || P.length < 2) return toast('Nothing to reverse');
  const t0 = P[0][3] || Date.now(), tN = P[P.length - 1][3] || t0, off = P.map(p => (p[3] || t0) - t0);
  const rev = P.slice().reverse();
  rev.forEach((p, i) => { p[3] = t0 + ((tN - t0) - off[P.length - 1 - i]); });
  t.pts = rev;
  if (!/ \(reversed\)$/.test(t.name)) t.name += ' (reversed)';
  save.tracks(); drawTracks(); render(); toast('Direction reversed — the start is now the end');
}
function joinWith(a, b) {
  const segs = [a.pts, b.pts].sort((p, q) => ((p[0] && p[0][3]) || 0) - ((q[0] && q[0][3]) || 0));
  const merged = { ...a, id: uid(), name: (a.name + ' + ' + b.name).slice(0, 70), pts: [...segs[0], ...segs[1]], photos: [...(a.photos || []), ...(b.photos || [])], created: Math.min(a.created || Date.now(), b.created || Date.now()), folder: a.folder || b.folder || '' };
  S.tracks.push(merged); save.tracks(); drawTracks(); render(); setTab('tracks');
  toast(`Joined into "${merged.name}" (${fmtD(pathLen(merged.pts))}). The two originals are still in the list.`, 6000);
}
function joinTrack(t) {
  const others = S.tracks.filter(x => x !== t && x.pts && x.pts.length > 1 && (x.kind === 'track' || x.kind === 'line' || !x.kind)).sort((a, b) => (b.created || 0) - (a.created || 0));
  if (!others.length) return toast('There is no other track or route to join with yet');
  modal('Join with another line', el('p', { class: 'mut', style: 'margin-top:0' }, 'Pick the other piece. The one that starts first comes first, and both originals stay in your list so nothing is lost.'),
    ...others.slice(0, 40).map(o => el('button', { class: 'btn', style: 'width:100%;justify-content:flex-start;margin:5px 0;text-align:left', onclick: () => { closeModal(); joinWith(t, o); } },
      el('span', {}, o.name), el('span', { class: 'mut', style: 'margin-left:auto;padding-left:10px;white-space:nowrap' }, fmtD(pathLen(o.pts))))));
}
function charts(t) {
  const box = el('div', { class: 'charts' }), sel = el('select', { style: 'margin-top:6px' }), c = el('canvas');
  [['ele', 'Elevation (m)'], ['speed', 'Speed (km/h)'], ['pace', 'Pace (min/km)']].forEach(([v, n]) => sel.append(el('option', { value: v }, n)));
  const draw = () => {
    c.width = (c.clientWidth || 300) * 2; c.height = 220; const g = c.getContext('2d'), mode = sel.value, pts = series(t, mode);
    g.clearRect(0, 0, c.width, c.height); g.fillStyle = '#8ea2bf'; g.font = '22px sans-serif';
    if (pts.length < 2) { g.fillText(mode === 'ele' ? 'No elevation data in this track' : 'No time data in this track', 14, 110); return; }
    const vs = pts.map(p => p[1]), mn = Math.min(...vs), mx = Math.max(...vs), rg = Math.max(mx - mn, 1e-6), D = pts[pts.length - 1][0] || 1;
    g.beginPath(); pts.forEach(([d, v], i) => { const x = d / D * (c.width - 20) + 10, y = c.height - 30 - (v - mn) / rg * (c.height - 60); i ? g.lineTo(x, y) : g.moveTo(x, y); });
    g.strokeStyle = t.color; g.lineWidth = 3; g.stroke(); const f = v => mode === 'ele' ? Math.round(v) + ' m' : v.toFixed(1);
    g.fillText(f(mx), 10, 22); g.fillText(f(mn), 10, c.height - 6); g.fillText(fmtD(D), c.width - 120, c.height - 6);
  };
  sel.onchange = draw; box.append(sel, c); requestAnimationFrame(draw); return box;
}

// ---------- elevation profile: stats, climb, walking time, scrubable chart ----------
function smoothEle(P) { // 5-point average: GPS altitude is noisy and inflates climb
  return P.map((_, i) => {
    let s = 0, n = 0;
    for (let k = Math.max(0, i - 2); k <= Math.min(P.length - 1, i + 2); k++) { const v = P[k][2]; if (Number.isFinite(v)) { s += v; n++; } }
    return n ? s / n : null;
  });
}
function walkMin(dM, upM, dnM, kmh) { // Naismith with a descent allowance
  return dM / 1000 / (kmh || 4) * 60 + upM / 600 * 60 + dnM / 1200 * 60;
}
function profileData(t) {
  const P = t.pts, cum = [0]; let d = 0;
  for (let i = 1; i < P.length; i++) { d += hav(P[i - 1], P[i]); cum.push(d); }
  const ele = smoothEle(P);
  let up = 0, dn = 0, mx = -Infinity, mn = Infinity, mxi = 0, mni = 0;
  ele.forEach((e, i) => { if (e == null) return; if (e > mx) { mx = e; mxi = i; } if (e < mn) { mn = e; mni = i; } });
  for (let i = 1; i < P.length; i++) { const a = ele[i - 1], b = ele[i]; if (a == null || b == null) continue; const dz = b - a; if (dz > 0) up += dz; else dn -= dz; }
  return { cum, ele, total: d, up, dn, mx, mn, mxi, mni, has: Number.isFinite(mx) && Number.isFinite(mn) && mx - mn > 1 };
}
function profileSvg(d) {
  const W = 1000, H = 300, pad = 16, bot = 30, span = Math.max(20, d.mx - d.mn);
  const X = i => d.total ? (d.cum[i] / d.total) * W : 0;
  const Y = e => bot + (1 - (e - d.mn) / span) * (H - pad - bot);
  const pts = []; d.ele.forEach((e, i) => { if (e != null) pts.push([X(i), Y(e), i]); });
  if (pts.length < 2) return '';
  const line = 'M' + pts.map(p => p[0].toFixed(1) + ' ' + p[1].toFixed(1)).join(' L');
  let grid = '';
  for (let k = 0; k <= 3; k++) { const y = (bot + (H - pad - bot) * k / 3).toFixed(1); grid += `<line x1="0" x2="${W}" y1="${y}" y2="${y}" stroke="currentColor" stroke-opacity=".14" stroke-width="1" vector-effect="non-scaling-stroke"/>`; }
  const hi = [X(d.mxi), Y(d.mx)], lo = [X(d.mni), Y(d.mn)];
  return `<svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-label="Elevation profile" role="img">
    <defs><linearGradient id="pg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="var(--flag)" stop-opacity=".38"/><stop offset="1" stop-color="var(--flag)" stop-opacity="0"/>
    </linearGradient></defs>
    ${grid}
    <path d="${line} L${W} ${H - bot} L0 ${H - bot} Z" fill="url(#pg)"/>
    <path d="${line}" fill="none" stroke="var(--flag)" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>
    <circle cx="${hi[0].toFixed(1)}" cy="${hi[1].toFixed(1)}" r="4" fill="var(--flag)" stroke="var(--sheet)" stroke-width="2" vector-effect="non-scaling-stroke"/>
    <circle cx="${lo[0].toFixed(1)}" cy="${lo[1].toFixed(1)}" r="4" fill="var(--water)" stroke="var(--sheet)" stroke-width="2" vector-effect="non-scaling-stroke"/>
    <line class="scrub" x1="0" x2="0" y1="0" y2="${H - bot}" stroke="var(--ink)" stroke-opacity=".45" stroke-width="1.5" vector-effect="non-scaling-stroke" visibility="hidden"/>
    <circle class="knob" r="6" fill="var(--ink)" stroke="var(--sheet)" stroke-width="2" vector-effect="non-scaling-stroke" visibility="hidden"/>
  </svg>`;
}
const fmtDur = m => m >= 60 ? `${Math.floor(m / 60)} h ${String(Math.round(m % 60)).padStart(2, '0')} min` : `${Math.round(m)} min`;
function profileUI(t) {
  if (!t.pts || t.pts.length < 2) return toast('This item has no line to profile');
  const d = profileData(t), kind = ({ area: 'Area', line: 'Planned route' }[t.kind] || 'Recorded track');
  const cell = (label, value) => el('div', { class: 'stat' }, el('span', {}, label), el('b', {}, value));
  const head = el('div', { class: 'profhead' },
    cell('Distance', fmtD(d.total)), cell('Climb', d.has ? '+' + Math.round(d.up) + ' m' : '—'), cell('Descent', d.has ? '−' + Math.round(d.dn) + ' m' : '—'),
    cell('High point', d.has ? Math.round(d.mx) + ' m' : '—'), cell('Low point', d.has ? Math.round(d.mn) + ' m' : '—'), cell('Walk time', fmtDur(walkMin(d.total, d.up, d.dn, 4))));
  const box = el('div', { class: 'profbox' });
  const sum = () => `${t.name} (${kind.toLowerCase()}) — ${fmtD(d.total)}`
    + (d.has ? `, climb ${Math.round(d.up)} m, descent ${Math.round(d.dn)} m, ${Math.round(d.mn)}–${Math.round(d.mx)} m` : '')
    + `, walking time about ${fmtT(walkMin(d.total, d.up, d.dn, 4) * 60000)} at 4 km/h with climb allowance.`;
  const actions = el('div', { class: 'row act', style: 'margin-top:12px' },
    d.has ? el('button', { class: 'btn', onclick: () => shareText(t.name + ' — elevation', sum()) }, 'Share summary') : '',
    d.has ? el('button', { class: 'btn', onclick: () => { closeModal(); map.setView([t.pts[d.mxi][0], t.pts[d.mxi][1]], Math.max(map.getZoom(), 15)); toast('High point ' + Math.round(d.mx) + ' m', 3000); } }, 'Go to high point') : '');
  if (!d.has) {
    box.append(el('p', { class: 'mut', style: 'margin:4px 2px 8px' }, 'This line has no altitude in its points yet. Getting elevation fills it in for the whole line (needs internet, about a second).'));
    const get = el('button', { class: 'btn pri', onclick: async () => { get.disabled = true; await fetchElevation(t); closeModal(); profileUI(t); } }, 'Get elevation');
    modal('Elevation profile', el('p', { class: 'mut', style: 'margin-top:0' }, t.name + ' · ' + kind), head, box, get, actions);
    return;
  }
  box.innerHTML = profileSvg(d);
  const svg = box.firstChild, scrub = svg.querySelector('.scrub'), knob = svg.querySelector('.knob'), tip = el('div', { class: 'tip', hidden: '' });
  box.append(tip);
  const W = 1000, H = 300, bot = 30, span = Math.max(20, d.mx - d.mn), Y = e => bot + (1 - (e - d.mn) / span) * (H - 16 - bot);
  const show = ev => {
    const r = svg.getBoundingClientRect(), f = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width)), at = f * d.total;
    let i = 0; while (i < d.cum.length - 1 && d.cum[i + 1] < at) i++;
    const e = d.ele[i];
    if (e == null) { tip.hidden = true; scrub.setAttribute('visibility', 'hidden'); knob.setAttribute('visibility', 'hidden'); return; }
    const x = f * W, y = Y(e);
    scrub.setAttribute('x1', x); scrub.setAttribute('x2', x); scrub.setAttribute('visibility', 'visible');
    knob.setAttribute('cx', x); knob.setAttribute('cy', y); knob.setAttribute('visibility', 'visible');
    const j = Math.min(i + 2, d.ele.length - 1), slope = (d.ele[j] != null && d.cum[j] > d.cum[i]) ? Math.round((d.ele[j] - e) / (d.cum[j] - d.cum[i]) * 100) : 0;
    tip.hidden = false; tip.style.left = (f * 100) + '%';
    tip.textContent = `${fmtD(at)} · ${Math.round(e)} m · ${slope >= 0 ? '+' : ''}${slope}%`;
  };
  ['pointerdown', 'pointermove'].forEach(k => box.addEventListener(k, show));
  box.addEventListener('pointerleave', () => { tip.hidden = true; scrub.setAttribute('visibility', 'hidden'); knob.setAttribute('visibility', 'hidden'); });
  const mid = Math.round((d.mx + d.mn) / 2);
  [['10px', Math.round(d.mx) + ' m'], ['46%', mid + ' m'], ['calc(100% - 58px)', Math.round(d.mn) + ' m']].forEach(([top, txt]) => {
    const lab = el('span', { class: 'paxis' }, txt); lab.style.top = top; box.append(lab);
  });
  const legend = el('div', { class: 'proflegend' }, el('span', {}, '0'), el('span', {}, 'distance along the line'), el('span', {}, fmtD(d.total)));
  modal('Elevation profile', el('p', { class: 'mut', style: 'margin-top:0' }, t.name + ' · ' + kind), head, box, legend,
    el('p', { class: 'mut', style: 'margin:8px 2px 0' }, 'Walk time uses 4 km/h on the flat plus 1 h per 600 m of climb (Naismith). Drag across the chart to read the height and grade at any point.'), actions);
}
function viewWpts(s) {
  const dst = typeof statsOf !== 'undefined' ? statsOf(S.wpts.filter(w => !w.hidden)) : null;
  if (dst && dst.total) s.append(el('div', { class: 'dcard', onclick: dashUI },
    typeof ring !== 'undefined' ? ring(Math.round(dst.done / dst.total * 100), 54) : '',
    el('div', { class: 't' }, el('b', {}, `Work status · ${Math.round(dst.done / dst.total * 100)}% done`),
      el('div', { class: 'mut' }, `${dst.all.pending} pending · ${dst.all.progress} in progress · ${dst.layers.length} layer${dst.layers.length > 1 ? 's' : ''}`)),
    el('span', { class: 'open' }, 'Open ›')));
  s.append(el('h3', {}, `Waypoints (${S.wpts.length})`), el('div', { class: 'segs', style: 'margin-bottom:6px' },
    [['all', 'All'], ...Object.entries(typeof STATUS !== 'undefined' ? STATUS : {}).map(([k, v]) => [k, v.n])].map(([k, n]) => el('button', {
      class: stFilter === k ? 'on' : '', title: n,
      onclick: () => { stFilter = k; render(); }
    }, `${k === 'all' ? S.wpts.length : S.wpts.filter(w => w.st === k).length} ${n}`))), el('div', { class: 'row' },
    el('button', { class: 'btn pri', onclick: () => newWaypoint() }, '+ New waypoint'),
    el('button', { class: 'btn', onclick: () => $('#camIn').click() }, 'Photo point'),
    fileBtn('Import', '.gpx,.kml,.kmz,.geojson,.json,.csv,.zip,.gpkg', importFile, true), el('button', { class: 'btn', onclick: manageLayers }, 'Layers')));
  if (!S.wpts.length) s.append(el('p', { class: 'mut' }, 'Tip: long-press the map to drop a waypoint.'));
  groupedList(s, 'wpts', () => S.wpts.filter(w => stFilter === 'all' || w.st === stFilter), w => {
    const show = () => { w.hidden = false; drawWpts(); map.setView([w.lat, w.lon], Math.max(map.getZoom(), 16)); setTab('map'); };
    return rowShell([el('div', { class: 't' }, pinSym(w), el('span', { class: 'nm' }, w.name), stChip(w.st)), el('div', { class: 'mut' }, fmtC(w.lat, w.lon) + (last ? `, ${fmtD(hav([last.lat, last.lon], [w.lat, w.lon]))} away` : '') + ((w.photos || []).length ? `, ${w.photos.length} photo${w.photos.length > 1 ? 's' : ''}` : '') + (w.note ? ' — ' + w.note : ''))],
      show, 'Go to ' + w.name, () => startNav(w), () => [
        ['Show on map', show], ['Go to (compass)', () => startNav(w)], ['Directions (Google Maps)', () => gmaps(w)],
        ['Work status…', () => statusUI(w)], '-',
        ['Edit details & photos', () => editFeature(w, 'wpt')], ['Share…', () => shareMenu(w, 'wpt')], ['Copy coordinates', () => { navigator.clipboard && navigator.clipboard.writeText(fmtC(w.lat, w.lon)); toast('Coordinates copied'); }],
        ['Move to layer…', () => { const fo = prompt('Move to layer (folder):', w.folder || ''); if (fo != null) { w.folder = fo.trim(); save.wpts(); render(); } }],
        [w.hidden ? 'Show on map list' : 'Hide from map', () => { w.hidden = !w.hidden; save.wpts(); drawWpts(); render(); }], '-',
        ['Delete', () => { if (confirm('Delete "' + w.name + '"?')) delFeature(w, 'wpt'); }, 'dng']], w.name);
  }, w => [w.lat, w.lon], () => { save.wpts(); drawWpts(); });
}
function viewLayers(s) {
  s.append(el('h3', {}, 'Base map'));
  const sel = el('select', { onchange: () => setBase(sel.value) }); for (const k in BASES) sel.append(el('option', { value: k }, BASES[k].n)); sel.value = S.set.base; s.append(sel);
  s.append(el('h3', { style: 'margin-top:16px' }, `My maps (${S.overlays.length})`),
    el('p', { class: 'mut' }, 'GeoPDF, GeoTIFF, KMZ and MBTiles position themselves. A photo of a paper map or any image can be aligned by hand. Each map is kept separately, works offline, and opening one hides the others.'),
    el('div', { class: 'row' }, fileBtn('Import map', '.pdf,.tif,.tiff,.kmz,.mbtiles,image/*', importFile, true, 'btn pri'),
      el('button', { class: 'btn', onclick: () => { const i = el('input', { type: 'file', accept: 'image/*', capture: 'environment', hidden: '' }); i.onchange = () => i.files[0] && addOverlay(i.files[0]); document.body.append(i); i.click(); } }, 'Photograph paper map')));
  groupedList(s, 'maps', () => S.overlays, o => {
    const sl = el('input', { type: 'range', min: 10, max: 100, value: Math.round(o.opacity * 100) });
    sl.oninput = () => { o.opacity = sl.value / 100; ovLayers[o.id] && ovLayers[o.id].setOpacity(o.opacity); }; sl.onchange = () => save.overlays();
    const open = () => { showMap(o); save.overlays(); drawOverlays(); map.fitBounds(ovBounds(o)); render(); };
    const here = last && onMapO(o, [last.lat, last.lon]), dist = last && !here ? fmtD(hav([last.lat, last.lon], [ovBounds(o).getCenter().lat, ovBounds(o).getCenter().lng])) + ' away' : '';
    const thumb = o.type === 'tiles' ? el('div', { style: 'width:56px;height:56px;border-radius:8px;flex:none;background:var(--line);display:grid;place-items:center;font-size:26px' }, '🗺') : el('img', { src: o._url || (o._url = URL.createObjectURL(o.blob)), style: 'width:56px;height:56px;object-fit:cover;border-radius:8px;flex:none', alt: '' });
    return el('div', { class: 'item' + (o.hidden ? '' : ' on') },
      el('div', { class: 'row', style: 'flex-wrap:nowrap;margin:0' }, thumb,
        el('div', {}, el('div', { class: 't' }, o.name), el('div', { class: 'mut' }, (o.hidden ? 'Hidden' : 'Showing') + (here ? ', you are on this map' : dist ? ', ' + dist : '') + (o.type === 'tiles' ? `, MBTiles zoom ${o.minz}–${o.maxz}` : '')))),
      sl, el('div', { class: 'row' },
        o.hidden ? el('button', { class: 'btn sm pri', onclick: open }, 'Open') : el('button', { class: 'btn sm', onclick: () => { o.hidden = true; save.overlays(); drawOverlays(); render(); } }, 'Hide'),
        el('button', { class: 'btn sm', onclick: () => map.fitBounds(ovBounds(o)) }, 'Zoom'),
        o.type === 'image' ? el('button', { class: 'btn sm', onclick: () => { showMap(o); drawOverlays(); startEditOv(o); map.fitBounds(ovBounds(o)); toast('Drag ✥ to move, ↻ to rotate and resize, orange corners to stretch', 5000); } }, 'Align') : '',
        editOv === o ? el('button', { class: 'btn sm', onclick: () => { stopEditOv(); toast('Saved'); render(); } }, 'Done') : '',
        o.type === 'image' ? el('button', { class: 'btn sm', onclick: () => exportGeoPdf(o) }, 'GeoPDF') : '',
        el('button', { class: 'btn sm', onclick: () => { const n = el('input', { type: 'text', value: o.name }), fo = el('input', { type: 'text', value: o.folder || '', list: 'dlF' });
          modal('Map details', el('label', {}, 'Name'), n, el('label', {}, 'Folder'), fo, el('datalist', { id: 'dlF' }, folders().map(x => el('option', { value: x }))),
            el('div', { class: 'row', style: 'margin-top:14px' }, el('button', { class: 'btn pri', onclick: () => { o.name = n.value.trim() || o.name; o.folder = fo.value.trim(); save.overlays(); closeModal(); render(); } }, 'Save'), el('button', { class: 'btn', onclick: closeModal }, 'Cancel'))); } }, 'Rename'),
        el('button', { class: 'btn sm dng', onclick: () => { if (confirm('Delete map "' + o.name + '"?')) delMap(o); } }, 'Delete')));
  }, o => { const c = ovBounds(o).getCenter(); return [c.lat, c.lng]; }, null);
  const multi = el('input', { type: 'checkbox', checked: !!S.set.multi });
  multi.onchange = () => { S.set.multi = multi.checked; save.set(); };
  if (S.overlays.length > 1) s.append(el('label', { class: 'mut', style: 'display:block;margin:8px 0' }, multi, ' Allow several maps at once (overlay)'));

  s.append(el('h3', { style: 'margin-top:16px' }, 'Offline maps'));
  const info = el('p', { class: 'mut' }, 'Checking…');
  const showInfo = () => cacheInfo().then(i => {
    info.textContent = `Kept offline: ${i.off} tiles · browse cache: ${i.n} tiles · ${i.mb.toFixed(1)} MB` + (i.quota ? ` of about ${Math.round(i.quota)} MB used` : '') + '. Downloads are kept until you delete them; the browse cache drops its oldest tiles when it fills up.';
  });
  showInfo();
  const z0 = Math.round(map.getZoom()), zs = el('select');
  for (let z = z0; z <= Math.min(z0 + 5, (BASES[offlineBase()] || {}).vec ? 15 : 17); z++) zs.append(el('option', { value: z }, 'Up to zoom ' + z));
  zs.value = Math.min(z0 + 3, 16); if (!zs.value) zs.value = z0;
  const est = el('div', { class: 'mut' }), bar = el('div', { class: 'bar', hidden: '' }, el('i')), lab = el('div', { class: 'mut' });
  const freeMB = () => cacheInfo().then(i => ({ free: i.quota ? Math.max(0, i.quota - i.mb) : Infinity }));
  const calc = () => { if (bulkBlocked(offlineBase())) { est.textContent = 'Saving areas offline is not allowed for this base map. Choose an Esri map or add your own base map.'; return 0; } const n = tileList(map.getBounds(), z0, +zs.value, nightOn() && NIGHT[S.set.base] ? NIGHT[S.set.base] : S.set.base).length; est.textContent = `Current view ≈ ${n} tiles (~${(n * mbPerTile()).toFixed(1)} MB)` + (n > 3000 ? ' — too many, zoom in or lower the max zoom' : ''); return n; };
  zs.onchange = calc; calc();
  const stopBtn = el('button', { class: 'btn', hidden: '', onclick: () => dlAbort = true }, 'Stop');
  const dlBtn = el('button', { class: 'btn pri', onclick: async () => {
    if (bulkBlocked(offlineBase())) return toast('OpenStreetMap, OpenTopoMap and CyclOSM do not allow saving areas for offline use. Pick an Esri map, or add your own base map under Maps.', 9000);
    const n = calc(); if (!n) return toast('Choose a base map first');
    if (n > 3000) return toast('Too many tiles (limit 3000) — zoom in or lower the max zoom', 5000);
    const { free } = await freeMB();
    if (n * mbPerTile() > free - 8) return toast(`This area needs about ${(n * mbPerTile()).toFixed(0)} MB and only ${Math.round(free)} MB is free on this device. Free up space first, or lower the max zoom.`, 9000);
    stopBtn.hidden = false; bar.hidden = false; lab.textContent = 'Starting…';
    await downloadTiles(tileList(map.getBounds(), z0, +zs.value, nightOn() && NIGHT[S.set.base] ? NIGHT[S.set.base] : S.set.base), bar.firstChild, lab);
    stopBtn.hidden = true; showInfo();
  } }, 'Download for offline use');
  s.append(info, el('div', { class: 'mut' }, 'Zoom to the area you need first, then download it. Night mode downloads the night tiles, so download again in day mode if you also want the daytime map.'), zs, est,
    el('div', { class: 'row' }, dlBtn, stopBtn),
    bar, lab,
    el('div', { class: 'row', style: 'margin-top:10px' },
      el('button', { class: 'btn sm', onclick: async () => { if (confirm('Clear the tiles saved while browsing? Your downloaded areas are kept.')) { await caches.delete(TILE_CACHE); toast('Browse cache cleared'); render(); } } }, 'Clear browse cache'),
      el('button', { class: 'btn sm dng', onclick: async () => { if (confirm('Delete the areas you downloaded for offline use?')) { await caches.delete(OFF_CACHE); toast('Offline areas deleted'); render(); } } }, 'Delete offline areas')),
    el('p', { class: 'mut' }, 'OpenStreetMap, OpenTopoMap and CyclOSM tiles are for viewing only: their policies forbid saving areas for offline use. Offline areas can be saved from Esri maps or from a base map you add yourself (check that provider\'s terms).'));
}
function viewMore(s) {
  const q = el('input', { type: 'search', placeholder: 'Search a place, or type 4.21, 101.97 / UTM' }), res = el('div');
  q.onkeydown = async e => {
    if (e.key !== 'Enter') return; const r = await search(q.value); res.replaceChildren(); if (!r) return;
    r.forEach(x => res.append(el('div', { class: 'item' }, x.display_name, el('div', { class: 'row' }, el('button', { class: 'btn sm', onclick: () => { map.setView([+x.lat, +x.lon], 15); setTab('map'); } }, 'Show on map'), el('button', { class: 'btn sm', onclick: () => editFeature(addWpt(+x.lat, +x.lon, { name: x.display_name.split(',')[0] }), 'wpt') }, 'Save as point')))));
  };
  const cs = el('select', { onchange: () => { S.set.coord = cs.value; save.set(); onMove(); } });
  [['dd', 'Decimal degrees (4.12345, 101.12345)'], ['dms', 'Degrees-minutes-seconds (DMS)'], ['utm', 'UTM'], ['mgrs', 'MGRS']].forEach(([v, n]) => cs.append(el('option', { value: v }, n))); cs.value = S.set.coord;
  const num = (k, label, min, max) => { const i = el('input', { type: 'number', min, max, value: S.set[k], style: 'width:90px' }); i.onchange = () => { const v = +i.value; if (v >= min && v <= max) { S.set[k] = v; save.set(); toast('Saved'); } }; return el('div', { class: 'row' }, i, el('span', { class: 'mut' }, label)); };
  const th = el('select', { onchange: () => { localStorage.setItem('theme', th.value); applyTheme(); } });
  [['auto', 'Match phone setting'], ['light', 'Day (best in sunlight)'], ['dark', 'Night']].forEach(([v, n]) => th.append(el('option', { value: v }, n))); th.value = themePref();
  const nm = el('input', { type: 'checkbox', checked: S.set.nightMap !== false });
  nm.onchange = () => { S.set.nightMap = nm.checked; save.set(); applyTheme(); toast(nm.checked ? 'Night mode uses a night base map' : 'Base map stays the same day and night'); };
  const lab = el('input', { type: 'checkbox', checked: !!S.set.labels }); lab.onchange = () => { S.set.labels = lab.checked; save.set(); drawWpts(); };
  const vis = () => ({ t: S.tracks.filter(x => !x.hidden), w: S.wpts.filter(x => !x.hidden) });
  const inclMaps = el('input', { type: 'checkbox' });
  s.append(el('h3', {}, 'Settings & tools'), el('h3', { style: 'margin-top:16px;font-size:15px' }, 'Search / go to'), q, res,
    el('h3', { style: 'margin-top:16px' }, 'Coordinate format'), cs,
    el('h3', { style: 'margin-top:16px' }, 'Appearance'), th,
    el('label', { class: 'mut', style: 'display:block;margin:8px 0 0' }, nm, ' Use a night base map when the app is dark'),
    el('h3', { style: 'margin-top:16px' }, 'Recording & display'), num('minDist', 'metres between recorded points', 1, 100), num('maxAcc', 'ignore GPS fixes less accurate than (metres)', 5, 500),
    el('label', { class: 'mut', style: 'display:block' }, lab, ' Show waypoint names on map'),
    el('h3', { style: 'margin-top:16px' }, 'Export (visible items)'),
    el('div', { class: 'row' },
      el('button', { class: 'btn', onclick: () => shareFile('trail-atlas.gpx', toGPX(vis().t, vis().w), 'application/gpx+xml') }, 'GPX'),
      el('button', { class: 'btn', onclick: () => shareFile('trail-atlas.kml', toKML(vis().t, vis().w), 'application/vnd.google-earth.kml+xml') }, 'KML'),
      el('button', { class: 'btn', onclick: () => shareFile('trail-atlas.geojson', toGJ(vis().t, vis().w), 'application/geo+json') }, 'GeoJSON'),
      el('button', { class: 'btn', onclick: () => shareFile('trail-atlas-waypoints.csv', toCSV(vis().w), 'text/csv') }, 'CSV'),
      el('button', { class: 'btn', onclick: () => shareFile('trail-atlas-shapefile.zip', toShapefileZip(vis().t, vis().w), 'application/zip') }, 'Shapefile'),
      el('button', { class: 'btn', onclick: async () => shareFile('trail-atlas.gpkg', await toGeoPackage(vis().t, vis().w), 'application/geopackage+sqlite3') }, 'GeoPackage')),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: manageLayers }, 'Layers, fields & schemas')),
    el('h3', { style: 'margin-top:16px' }, 'Import'), el('div', { class: 'row' }, fileBtn('GPX / KML / KMZ / GeoJSON / CSV / Shapefile / GeoPackage / maps', '.gpx,.kml,.kmz,.geojson,.json,.csv,.zip,.gpkg,.pdf,.tif,.tiff,.mbtiles,image/*', importFile, true)),
    el('h3', { style: 'margin-top:16px' }, 'Team'), el('div', { class: 'row' },
      el('button', { class: 'btn pri', onclick: dashUI }, 'Status dashboard'),
      el('button', { class: 'btn', onclick: statusReport }, 'Status report (PDF)')),
    el('h3', { style: 'margin-top:16px' }, 'Project handover'),
    el('p', { class: 'mut' }, 'One file with layers, points, work statuses, fields and beacons — send it on WhatsApp, the other phone merges it in. Nothing goes through a server.'),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: shareProjectUI }, 'Give project to the crew'), fileBtn('Receive project file', '.json', mergeProject)),
    el('h3', { style: 'margin-top:16px' }, 'Backup (everything incl. photos)'),
    el('label', { class: 'mut', style: 'display:block' }, inclMaps, ' Include my maps (bigger file)'),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: () => backup(inclMaps.checked) }, 'Save backup'),
      fileBtn('Restore backup', '.json', restore)),
    el('div', { class: 'row' }, el('button', { class: 'btn', onclick: snapUI }, 'Automatic snapshots'), el('button', { class: 'btn', onclick: installApp }, 'Install app')),
    el('div', { class: 'row' }, el('button', { class: 'btn', id: 'errReport', onclick: () => { const t = taErrLog.report(); navigator.clipboard && navigator.clipboard.writeText ? navigator.clipboard.writeText(t).then(() => toast('Error report copied'), () => prompt('Copy this report:', t)) : prompt('Copy this report:', t); } }, `Copy error report (${taErrLog.get().length})`)),
    el('p', { class: 'mut' }, 'Trail Atlas v2 · all data stays on your device. Maps © OpenStreetMap, OpenTopoMap, Esri. Routing © OSRM.'));
}
async function backup(withMaps) {
  toast('Preparing backup…'); S.set.backupAt = Date.now(); save.set();
  const photos = {}; for (const id of [...S.wpts, ...S.tracks].flatMap(x => x.photos || [])) { const b = await kvGet('ph:' + id); if (b) photos[id] = await blobToURL(b); }
  const maps = withMaps ? await Promise.all(S.overlays.filter(o => o.type === 'image').map(async o => ({ ...o, _url: undefined, blob: await blobToURL(o.blob) }))) : [];
  await shareFile('trail-atlas-backup.json', JSON.stringify({ v: 2, tracks: S.tracks, wpts: S.wpts, photos, maps, set: S.set, schemas: S.schemas }), 'application/json');
}
async function restore(f) {
  try {
    const j = JSON.parse(await f.text()); if (j.v !== 1 && j.v !== 2) throw Error('not a Trail Atlas backup'); if (j.schemas) { S.schemas = j.schemas; save.schemas(); }
    if (!confirm('Restore will replace your tracks and waypoints. Continue?')) return;
    S.tracks = j.tracks || []; S.wpts = j.wpts || [];
    for (const [id, u] of Object.entries(j.photos || {})) await kvSet('ph:' + id, await (await fetch(u)).blob());
    for (const m of j.maps || []) if (!S.overlays.some(o => o.id === m.id)) S.overlays.push(migrateOv({ ...m, blob: await (await fetch(m.blob)).blob(), hidden: true }));
    await save.tracks(); await save.wpts(); await save.overlays(); drawTracks(); drawWpts(); drawOverlays(); toast('Restored'); render();
  } catch (e) { toast('Failed: ' + e.message); }
}

// ---------- start ----------
$('#fLoc').onclick = () => { if (watchId === null) startGPS(); else if (last) { follow = true; map.setView([last.lat, last.lon], Math.max(map.getZoom(), 16)); } };
$('#fLoc').oncontextmenu = e => { e.preventDefault(); stopGPS(); };
$('#fRec').onclick = () => startRec();
$('#fWpt').onclick = () => newWaypoint();
$('#fMeas').onclick = toggleMeas;
$('#fPhoto').onclick = () => $('#camIn').click();
$('#fShare').onclick = () => shareMenu();
$('#camIn').onchange = async e => { const f = e.target.files[0]; e.target.value = ''; if (f) await photoWpt(f); };
map.on('dragstart', () => follow = false);
document.querySelectorAll('nav button').forEach(b => b.onclick = () => setTab(b.dataset.tab));
(async () => {
  await migrateStore();
  S.tracks = (await kvGet('tracks') || []).map(t => ({ kind: 'track', folder: '', attrs: {}, photos: [], ...t }));
  S.wpts = (await kvGet('wpts') || []).map(w => ({ icon: '📍', folder: '', attrs: {}, photos: [], ...w }));
  S.overlays = (await kvGet('overlays') || []).map(migrateOv); S.schemas = await kvGet('schemas') || {};
  Object.assign(S.set, await kvGet('set') || {}); for (const b of S.set.userBases || []) BASES[b.id] = b; setBase(S.set.base); drawTracks(); drawWpts(); drawOverlays(); onMove();
  const r = await kvGet('rec');
  if (r && r.pts && r.pts.length > 1) { if (confirm('An interrupted recording was found (' + r.pts.length + ' points). Resume it?')) startRec(r); else { S.tracks.push({ id: r.id, kind: 'track', name: 'Recovered track', color: COLORS[0], pts: r.pts, created: r.t0, folder: '', attrs: {}, photos: [] }); save.tracks(); drawTracks(); await kvDel('rec'); } }
  try { navigator.storage && navigator.storage.persist && navigator.storage.persist(); } catch (e) { }
  setTimeout(() => {
    if (!S.set.backupAt) return;                     // never backed up: no nag on a fresh install
    const days = Math.floor((Date.now() - S.set.backupAt) / 864e5);
    if ((S.tracks.length + S.wpts.length) > 5 && days >= 14) toast(`Last file backup: ${days} days ago — More → Save backup keeps your work safe`, 6000);
  }, 6000);
  if ('serviceWorker' in navigator && location.protocol !== 'file:') {
    // Versi baharu menunggu (SW tidak skipWaiting sendiri): halaman ini kekal pada satu versi yang konsisten
    // sehingga pengguna bersetuju; barulah SW baharu diaktifkan dan halaman dimuat semula.
    let reloading = false, asked = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (reloading || !sessionStorage.getItem('ta-upd')) return; reloading = true; location.reload(); });
    const offer = w => {
      if (asked || !navigator.serviceWorker.controller) return; asked = true; // pemasangan pertama tidak mengganggu
      if (confirm('A new version of Trail Atlas is ready. Reload now?')) { sessionStorage.setItem('ta-upd', '1'); w.postMessage({ type: 'skip-waiting' }); }
    };
    navigator.serviceWorker.register('sw.js').then(reg => {
      if (reg.waiting) offer(reg.waiting);
      reg.addEventListener('updatefound', () => { const n = reg.installing; n && n.addEventListener('statechange', () => { if (n.state === 'installed') offer(n); }); });
    }).catch(e => taErrLog.add('sw', e && e.message));
  }
})();
window.__jejak = { shareMenu, mapReport, featReport, geoPdf, toKMZ, snapshotMap, toShapefileZip, readShp, readDbf, toGeoPackage, importGpkg, readWKB, startFollow, fetchElevation, manageLayers, S, map, parseGPX, parseKML, parseGeoJSON, parseCSV, toGPX, toKML, toGJ, toCSV, utm, utmInv, mgrs, areaOf, hav, brg, exifGPS, unzip, startNav, stopNav, nav, geoRefOGC, geoRefLGI, exportGeoPdf, onMapO, ovLayers, profileUI, profileData, walkMin, applyTheme, setBase, cacheInfo, cycleCoord, reverseTrack, joinTrack, joinWith, addWpt, drawWpts, editFeature, drawTracks };
